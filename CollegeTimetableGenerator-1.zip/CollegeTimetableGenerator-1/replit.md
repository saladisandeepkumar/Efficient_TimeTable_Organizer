# SmartScheduler - College Timetable Generator

## Overview

SmartScheduler is a comprehensive college timetable management system designed to automate faculty allocation, subject management, and timetable generation for educational institutions. The application provides an intelligent scheduling solution that handles complex constraints including faculty availability, subject requirements, and academic schedules.

## System Architecture

### Frontend Architecture
- **Framework**: React 19.1.0 with vanilla JavaScript fallback
- **Styling**: CSS3 with custom design system
- **Build Tool**: Babel standalone for in-browser compilation
- **Deployment**: Static file server on port 5000

### Backend Architecture
- **Runtime**: Node.js 20
- **Framework**: Express.js 5.1.0
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (PostgreSQL-compatible)
- **Authentication**: JWT-based with bcrypt password hashing
- **API Design**: RESTful architecture

### Database Schema
The system uses PostgreSQL with the following core entities:
- **Users**: Authentication and user management
- **Faculty**: Staff information and constraints
- **Subjects**: Course definitions with department/year mapping
- **Allocations**: Faculty-to-subject assignments
- **Timetables**: Generated schedules
- **Sessions**: Session storage for authentication

## Key Components

### Authentication System
- JWT token-based authentication
- Role-based access control (Admin/Faculty)
- Session management with PostgreSQL storage
- Password hashing with bcryptjs

### Faculty Management
- Faculty registration and profile management
- Department-based organization
- Employee ID tracking
- Maximum daily lecture constraints

### Subject Management
- Course catalog with department/year/semester organization
- Credit and period allocation
- Subject type classification (theory/lab/practical)

### Allocation Engine
- Faculty-to-subject assignment system
- Department and class-specific allocations
- Constraint validation

### Timetable Generator
- Automated schedule generation with constraint solving
- Conflict detection and resolution
- Multiple generation attempts with retry logic
- PDF export capabilities

### API Layer
- Comprehensive REST API endpoints
- CORS-enabled for cross-origin requests
- Error handling and validation
- Health check endpoints

## Data Flow

1. **Authentication Flow**: User login → JWT generation → Session storage
2. **Faculty Management**: Admin creates faculty → Faculty profiles stored → Available for allocation
3. **Subject Management**: Admin defines subjects → Organized by department/year/semester
4. **Allocation Process**: Admin assigns faculty to subjects → Stored as allocation records
5. **Timetable Generation**: System processes allocations → Generates optimized schedules → Stores results
6. **Export/Display**: Generated timetables displayed in web interface → PDF export available

## External Dependencies

### Database
- **Neon Database**: Serverless PostgreSQL provider
- **Connection**: WebSocket-based connection pooling
- **Environment**: Requires `DATABASE_URL` environment variable

### Authentication
- **JWT**: JSON Web Token for stateless authentication
- **BCrypt**: Password hashing and verification

### PDF Generation
- **PDFKit**: Server-side PDF generation for timetable exports

### WebSocket Support
- **ws**: WebSocket library for real-time features

## Deployment Strategy

### Development Environment
- **Frontend**: Simple HTTP server on port 5000
- **Backend**: Express server on port 8000
- **Database**: Neon PostgreSQL instance

### Production Configuration
- **Parallel Workflow**: Frontend and backend run simultaneously
- **Port Mapping**: External port 80 maps to backend port 8000
- **Static Assets**: Frontend served from client/public directory
- **Environment Variables**: Database URL and JWT secrets configured

### Database Migration
- **Drizzle Kit**: Database schema management and migrations
- **Schema Location**: Shared TypeScript schema definitions
- **Migration Output**: Generated SQL in drizzle directory

## Changelog

- June 16, 2025: Initial setup with PostgreSQL database and React/Express architecture
- June 16, 2025: Enhanced admin panel with dynamic CRUD operations for faculty and subjects
- June 16, 2025: Implemented comprehensive allocation management system
- June 16, 2025: Upgraded timetable generator with constraints-based scheduling
- June 16, 2025: Added weekly timetable structure with randomized lunch breaks (periods 4-5)
- June 16, 2025: Integrated live database connectivity for all operations

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### Admin Panel Features (June 16, 2025)
- Dynamic faculty management with full CRUD operations
- Subject catalog with department/year/semester organization
- Faculty-subject allocation system with visual mapping interface
- Real-time data updates from PostgreSQL database

### Timetable Generator Enhancements (June 16, 2025)
- Weekly structure: Monday-Saturday with 7 periods per day
- Constraint-based scheduling for theory and lab subjects
- Random lunch break assignment (4th or 5th period daily)
- Faculty workload validation and conflict detection
- Lab sessions require 3 consecutive periods
- Theory subjects distributed across available slots
- Live data integration from allocations and faculty constraints

### Faculty Dashboard Enhancements (June 17, 2025)
- Added complete button suite to faculty dashboard subjects tab (Statistics, Export CSV, Bulk Upload, Add Subject)
- Enhanced filtering system with department, year, semester, and type filters
- Consistent interface between admin and faculty dashboards for subject management

### Timetable Display Improvements (June 17, 2025)
- Enhanced timetable visualization with detailed weekly schedule table
- Color-coded subject types (theory: blue, lab: green, practical: pink)
- Period time slots display (9:00-10:00 through 3:30-4:30)
- Interactive "View Schedule" and "Export PDF" buttons for each timetable
- Faculty and subject information displayed in schedule slots
- Lunch break periods clearly marked in schedule
- Real-time toggle functionality for showing/hiding detailed schedules

### Random Lunch Break Implementation (June 19, 2025)
- Improved timetable layout: Days as rows, Periods as columns for traditional view
- Implemented randomized lunch breaks between Period 4 (12:15-1:15) and Period 5 (1:15-2:15)
- Each day independently randomizes lunch timing instead of fixed schedule
- Enhanced timetable generation algorithm with random lunch break assignment
- Updated metadata to reflect randomization constraints and algorithm details
- Comprehensive CRUD API endpoints for faculty and subject management (POST, PUT, DELETE)

### Balanced Lab Distribution (June 19, 2025)
- Implemented balanced lab scheduling between morning and afternoon sessions
- For 4 labs: 2 scheduled in morning (periods 0-2) and 2 in afternoon (after lunch)
- Labs maintain 3 consecutive periods requirement
- Morning labs: periods 1-3 (9:00-12:15), Afternoon labs: periods after lunch
- Enhanced algorithm ensures even distribution across time slots
- Updated metadata to show lab distribution balance (morning/afternoon)

### Faculty and Subject Management Fix (June 24, 2025)
- Fixed faculty management add, edit, and delete operations with proper error handling
- Enhanced faculty modal to support both create and update modes with pre-filled form values
- Fixed subject management add, edit, and delete operations with comprehensive validation
- Improved error handling across all CRUD operations to prevent unhandled promise rejections
- Application successfully loads with authentication and data management (28 faculty, 3 subjects)
- All backend API endpoints verified working: POST, PUT, DELETE for both faculty and subjects
- Modal forms now properly populate existing data for edit operations
- Delete confirmation dialogs implemented with proper cleanup and UI updates

### Faculty-Subject Allocation System Implementation (June 24, 2025)
- Implemented complete faculty-subject allocation management system with CRUD operations
- Created allocation endpoints in backend server with in-memory storage (GET, POST, PUT, DELETE)
- Added comprehensive allocation creation modal with dynamic faculty-subject assignment rows
- Faculty and subject data from management modules now available for allocation assignment
- Enhanced allocation display with detailed faculty-subject mapping visualization
- Fixed timetable management delete button functionality with proper API integration
- Allocation system connects faculty management and subject management data seamlessly
- Users can now create allocations by selecting faculty members and subjects from existing data

### Timetable Management PDF Export and Delete Fix (June 24, 2025)
- Fixed timetable delete functionality with proper error handling and UI updates
- Corrected PDF export feature with working backend PDF generation using PDFKit
- Timetable delete operations now properly remove data and refresh the interface
- PDF export generates proper downloadable files with formatted timetable content
- Both features now work correctly with proper authentication and data validation
- Enhanced error messages and user feedback for both delete and export operations
- Removed duplicate delete function that was causing conflicts and replaced with enhanced version
- Added comprehensive logging and blob validation for PDF export operations
- Implemented proper data reload after delete operations to ensure UI consistency

### Allocation System Complete Implementation (June 24, 2025)
- Fixed JavaScript function scope issues by creating dedicated allocation-functions.js file
- Implemented complete allocation creation modal with proper form handling and validation
- Added dynamic faculty-subject assignment rows with department filtering
- Created comprehensive form validation and submission logic for both create and edit operations
- Removed duplicate backend endpoints and cleaned up conflicting function definitions
- Enhanced error handling with comprehensive logging and user feedback
- Verified backend API endpoints working correctly with proper authentication
- All allocation functionality now properly accessible: Create, Edit, Delete operations
- Users can successfully create and edit allocations with faculty-subject mappings
- Modal functions properly reset between create and edit modes

### Faculty-Subject Assignment Data Loading Fix (June 24, 2025)
- Resolved JavaScript syntax errors causing "Unexpected token 'else'" issues
- Fixed faculty and subject dropdown population in allocation creation modal
- Enhanced data filtering with proper null checks and case-insensitive matching
- Improved error handling for department-based faculty and subject filtering
- Added detailed console logging to debug data loading issues
- Faculty and subject dropdowns now properly populate when department is selected
- Users can now successfully assign faculty to subjects in allocation creation process

### Faculty-Specific Login and Individual Timetable System Complete (June 24, 2025)
- Successfully implemented dual login system supporting both email (admin) and employee ID (faculty) authentication
- Enhanced login form with dynamic field switching between admin and faculty login modes
- Created faculty-specific timetable viewing system showing only individual faculty schedules
- Added comprehensive faculty dashboard with personal teaching schedule display
- Implemented faculty-specific API endpoints for retrieving individual timetables with role-based security
- Added faculty timetable export functionality with personalized PDF generation
- Enhanced security with role-based access control for faculty timetable data
- Faculty members can now view only their assigned classes, subjects, and teaching periods
- Individual faculty schedules show detailed class information, periods, and subject assignments
- Added visual schedule grid with color-coded subject types (theory=blue, lab=green, practical=yellow)
- Fixed all JavaScript syntax errors including loadingBtn undefined issues in delete/export functions
- Tested authentication flow: Admin (admin@college.edu/admin123) and Faculty (FAC001/faculty123)
- Application fully functional with complete CRUD operations for faculty, subjects, allocations, and timetables
- Enhanced error handling and button state management for all operations

### Faculty Dashboard Simplification (June 24, 2025)
- Removed Subjects and Faculty management tabs from faculty dashboard
- Faculty dashboard now contains only Overview and Timetables sections
- Simplified navigation for faculty users focusing on their core needs
- Overview tab shows system statistics relevant to faculty
- Timetables tab displays individual faculty teaching schedules

### Login Interface Simplification (June 24, 2025)
- Reverted to clean, simple dropdown-based login type selection
- Restored straightforward form layout with clear labels and standard inputs
- Simplified user interface focusing on functionality over visual complexity
- Maintained dual login support for Admin (email) and Faculty (employee ID)
- Kept essential form validation and field switching logic

### Faculty-Subject Allocation System Complete Fix (June 24, 2025)
- Fixed allocation modal data loading issue where faculty and subject dropdowns were empty
- Enhanced global data access by making window.appData properly available to allocation functions
- Improved authentication token handling for allocation save operations
- Added comprehensive error logging and validation for allocation creation
- Made loadData and renderApp functions globally accessible for proper data refresh after operations
- Fixed "Failed to fetch" error in allocation save functionality with proper API endpoint configuration
- Enhanced department filtering logic with case-insensitive matching for faculty and subject selection
- Application now successfully creates allocations with faculty-subject assignments

### Timetable Operations Authentication Fix (June 24, 2025)
- Fixed "auth.getToken is not a function" error in timetable delete and export operations
- Updated authentication token access to use localStorage.getItem('authToken') consistently
- Enhanced error handling for missing authentication tokens with clear user feedback
- Verified PDF export functionality working correctly (generating 2KB+ PDF files)
- Confirmed delete functionality working with proper authentication headers
- Both timetable export and delete operations now function without errors