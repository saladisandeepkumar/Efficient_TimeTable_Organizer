import {
  users,
  faculty,
  subjects,
  allocations,
  timetables,
  type User,
  type UpsertUser,
  type Faculty,
  type Subject,
  type Allocation,
  type Timetable,
  type InsertFaculty,
  type InsertSubject,
  type InsertAllocation,
  type InsertTimetable,
} from "../shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Faculty operations
  getFaculty(): Promise<Faculty[]>;
  getFacultyById(id: number): Promise<Faculty | undefined>;
  getFacultyByEmployeeId(employeeId: string): Promise<Faculty | undefined>;
  createFaculty(facultyData: InsertFaculty): Promise<Faculty>;
  updateFaculty(id: number, facultyData: Partial<InsertFaculty>): Promise<Faculty>;
  deleteFaculty(id: number): Promise<void>;
  
  // Subject operations
  getSubjects(): Promise<Subject[]>;
  getSubjectById(id: number): Promise<Subject | undefined>;
  getSubjectsByDepartment(department: string, year: number, semester: number): Promise<Subject[]>;
  createSubject(subjectData: InsertSubject): Promise<Subject>;
  updateSubject(id: number, subjectData: Partial<InsertSubject>): Promise<Subject>;
  deleteSubject(id: number): Promise<void>;
  
  // Allocation operations
  getAllocations(): Promise<Allocation[]>;
  getAllocationById(id: number): Promise<Allocation | undefined>;
  getAllocationByClass(department: string, year: number, semester: number, section: string): Promise<Allocation | undefined>;
  createAllocation(allocationData: InsertAllocation): Promise<Allocation>;
  updateAllocation(id: number, allocationData: Partial<InsertAllocation>): Promise<Allocation>;
  deleteAllocation(id: number): Promise<void>;
  
  // Timetable operations
  getTimetables(): Promise<Timetable[]>;
  getTimetableById(id: number): Promise<Timetable | undefined>;
  getTimetableByClass(department: string, year: number, semester: number, section: string): Promise<Timetable | undefined>;
  createTimetable(timetableData: InsertTimetable): Promise<Timetable>;
  updateTimetable(id: number, timetableData: Partial<InsertTimetable>): Promise<Timetable>;
  deleteTimetable(id: number): Promise<void>;
  replaceExistingTimetable(department: string, year: number, semester: number, section: string, timetableData: InsertTimetable): Promise<Timetable>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Faculty operations
  async getFaculty(): Promise<Faculty[]> {
    return await db.select().from(faculty).where(eq(faculty.isActive, true)).orderBy(faculty.name);
  }

  async getFacultyById(id: number): Promise<Faculty | undefined> {
    const [result] = await db.select().from(faculty).where(eq(faculty.id, id));
    return result;
  }

  async getFacultyByEmployeeId(employeeId: string): Promise<Faculty | undefined> {
    const [result] = await db.select().from(faculty).where(eq(faculty.employeeId, employeeId));
    return result;
  }

  async createFaculty(facultyData: InsertFaculty): Promise<Faculty> {
    const [result] = await db.insert(faculty).values(facultyData).returning();
    return result;
  }

  async updateFaculty(id: number, facultyData: Partial<InsertFaculty>): Promise<Faculty> {
    const [result] = await db
      .update(faculty)
      .set({ ...facultyData, updatedAt: new Date() })
      .where(eq(faculty.id, id))
      .returning();
    return result;
  }

  async deleteFaculty(id: number): Promise<void> {
    await db.update(faculty).set({ isActive: false }).where(eq(faculty.id, id));
  }

  // Subject operations
  async getSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects).where(eq(subjects.isActive, true)).orderBy(subjects.name);
  }

  async getSubjectById(id: number): Promise<Subject | undefined> {
    const [result] = await db.select().from(subjects).where(eq(subjects.id, id));
    return result;
  }

  async getSubjectsByDepartment(department: string, year: number, semester: number): Promise<Subject[]> {
    return await db
      .select()
      .from(subjects)
      .where(
        and(
          eq(subjects.department, department),
          eq(subjects.year, year),
          eq(subjects.semester, semester),
          eq(subjects.isActive, true)
        )
      )
      .orderBy(subjects.name);
  }

  async createSubject(subjectData: InsertSubject): Promise<Subject> {
    const [result] = await db.insert(subjects).values(subjectData).returning();
    return result;
  }

  async updateSubject(id: number, subjectData: Partial<InsertSubject>): Promise<Subject> {
    const [result] = await db
      .update(subjects)
      .set({ ...subjectData, updatedAt: new Date() })
      .where(eq(subjects.id, id))
      .returning();
    return result;
  }

  async deleteSubject(id: number): Promise<void> {
    await db.update(subjects).set({ isActive: false }).where(eq(subjects.id, id));
  }

  // Allocation operations
  async getAllocations(): Promise<Allocation[]> {
    return await db.select().from(allocations).where(eq(allocations.isActive, true)).orderBy(desc(allocations.createdAt));
  }

  async getAllocationById(id: number): Promise<Allocation | undefined> {
    const [result] = await db.select().from(allocations).where(eq(allocations.id, id));
    return result;
  }

  async getAllocationByClass(department: string, year: number, semester: number, section: string): Promise<Allocation | undefined> {
    const [result] = await db
      .select()
      .from(allocations)
      .where(
        and(
          eq(allocations.department, department),
          eq(allocations.year, year),
          eq(allocations.semester, semester),
          eq(allocations.section, section),
          eq(allocations.isActive, true)
        )
      );
    return result;
  }

  async createAllocation(allocationData: InsertAllocation): Promise<Allocation> {
    const [result] = await db.insert(allocations).values(allocationData).returning();
    return result;
  }

  async updateAllocation(id: number, allocationData: Partial<InsertAllocation>): Promise<Allocation> {
    const [result] = await db
      .update(allocations)
      .set({ ...allocationData, updatedAt: new Date() })
      .where(eq(allocations.id, id))
      .returning();
    return result;
  }

  async deleteAllocation(id: number): Promise<void> {
    await db.update(allocations).set({ isActive: false }).where(eq(allocations.id, id));
  }

  // Timetable operations
  async getTimetables(): Promise<Timetable[]> {
    return await db.select().from(timetables).where(eq(timetables.isActive, true)).orderBy(desc(timetables.createdAt));
  }

  async getTimetableById(id: number): Promise<Timetable | undefined> {
    const [result] = await db.select().from(timetables).where(eq(timetables.id, id));
    return result;
  }

  async getTimetableByClass(department: string, year: number, semester: number, section: string): Promise<Timetable | undefined> {
    const [result] = await db
      .select()
      .from(timetables)
      .where(
        and(
          eq(timetables.department, department),
          eq(timetables.year, year),
          eq(timetables.semester, semester),
          eq(timetables.section, section),
          eq(timetables.isActive, true)
        )
      );
    return result;
  }

  async createTimetable(timetableData: InsertTimetable): Promise<Timetable> {
    const [result] = await db.insert(timetables).values(timetableData).returning();
    return result;
  }

  async updateTimetable(id: number, timetableData: Partial<InsertTimetable>): Promise<Timetable> {
    const [result] = await db
      .update(timetables)
      .set({ ...timetableData, updatedAt: new Date() })
      .where(eq(timetables.id, id))
      .returning();
    return result;
  }

  async deleteTimetable(id: number): Promise<void> {
    await db.update(timetables).set({ isActive: false }).where(eq(timetables.id, id));
  }

  async replaceExistingTimetable(department: string, year: number, semester: number, section: string, timetableData: InsertTimetable): Promise<Timetable> {
    // First, deactivate any existing timetable
    await db
      .update(timetables)
      .set({ isActive: false })
      .where(
        and(
          eq(timetables.department, department),
          eq(timetables.year, year),
          eq(timetables.semester, semester),
          eq(timetables.section, section)
        )
      );

    // Then create the new timetable
    return await this.createTimetable(timetableData);
  }
}

export const storage = new DatabaseStorage();