const { MongoClient } = require('mongodb');

let db = null;
let client = null;

const connectDB = async () => {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/smartscheduler';
    
    client = new MongoClient(mongoURI, {
      useUnifiedTopology: true,
    });

    await client.connect();
    db = client.db();
    
    console.log('MongoDB connected successfully');
    
    // Create indexes for better performance
    await createIndexes();
    
  } catch (error) {
    console.error('MongoDB connection error:', error);
    process.exit(1);
  }
};

const createIndexes = async () => {
  try {
    // User indexes
    await db.collection('users').createIndex({ email: 1 }, { unique: true });
    await db.collection('users').createIndex({ employeeId: 1 }, { unique: true, sparse: true });
    
    // Faculty indexes
    await db.collection('faculty').createIndex({ employeeId: 1 }, { unique: true });
    await db.collection('faculty').createIndex({ department: 1 });
    
    // Subject indexes
    await db.collection('subjects').createIndex({ code: 1 }, { unique: true });
    await db.collection('subjects').createIndex({ department: 1 });
    
    // Allocation indexes
    await db.collection('allocations').createIndex({ 
      department: 1, 
      year: 1, 
      section: 1, 
      semester: 1 
    });
    await db.collection('allocations').createIndex({ facultyId: 1 });
    
    // Timetable indexes
    await db.collection('timetables').createIndex({ 
      department: 1, 
      year: 1, 
      section: 1, 
      semester: 1 
    }, { unique: true });
    
    console.log('Database indexes created successfully');
  } catch (error) {
    console.error('Error creating indexes:', error);
  }
};

const getDB = () => {
  if (!db) {
    throw new Error('Database not connected. Call connectDB first.');
  }
  return db;
};

const closeDB = async () => {
  if (client) {
    await client.close();
    console.log('MongoDB connection closed');
  }
};

module.exports = {
  connectDB,
  getDB,
  closeDB
};
