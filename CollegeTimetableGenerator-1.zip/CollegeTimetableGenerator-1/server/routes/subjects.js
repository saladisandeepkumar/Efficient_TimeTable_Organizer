const express = require('express');
const Subject = require('../models/Subject');
const { verifyToken, requireAdmin, requireAuth } = require('../middleware/auth');

const router = express.Router();

// Get all subjects
router.get('/', verifyToken, requireAuth, async (req, res) => {
  try {
    const { department, year, semester, type } = req.query;
    let subjects;

    if (department && year && semester) {
      subjects = await Subject.findByDepartmentAndYear(department, parseInt(year), parseInt(semester));
    } else {
      subjects = await Subject.getAll();
    }

    // Filter by type if specified
    if (type) {
      subjects = subjects.filter(subject => subject.type === type);
    }

    res.json({
      success: true,
      data: subjects,
      count: subjects.length
    });
  } catch (error) {
    console.error('Get subjects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch subjects',
      error: error.message
    });
  }
});

// Get subject by ID
router.get('/:id', verifyToken, requireAuth, async (req, res) => {
  try {
    const subject = await Subject.findById(req.params.id);
    
    if (!subject) {
      return res.status(404).json({
        success: false,
        message: 'Subject not found'
      });
    }

    res.json({
      success: true,
      data: subject
    });
  } catch (error) {
    console.error('Get subject by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch subject',
      error: error.message
    });
  }
});

// Create new subject (Admin only)
router.post('/', verifyToken, requireAdmin, async (req, res) => {
  try {
    const {
      code,
      name,
      department,
      year,
      semester,
      credits,
      type,
      periodsPerWeek
    } = req.body;

    // Validation
    if (!code || !name || !department || !year || !semester || !type || !periodsPerWeek) {
      return res.status(400).json({
        success: false,
        message: 'Code, name, department, year, semester, type, and periods per week are required'
      });
    }

    // Check if subject with same code exists
    const existingSubject = await Subject.findByCode(code);
    if (existingSubject) {
      return res.status(400).json({
        success: false,
        message: 'Subject with this code already exists'
      });
    }

    // Validate type
    if (!['theory', 'lab', 'practical'].includes(type)) {
      return res.status(400).json({
        success: false,
        message: 'Type must be theory, lab, or practical'
      });
    }

    const subjectData = {
      code,
      name,
      department,
      year: parseInt(year),
      semester: parseInt(semester),
      credits: parseInt(credits) || 0,
      type,
      periodsPerWeek: parseInt(periodsPerWeek)
    };

    const subject = new Subject(subjectData);
    const savedSubject = await subject.save();

    res.status(201).json({
      success: true,
      message: 'Subject created successfully',
      data: savedSubject
    });
  } catch (error) {
    console.error('Create subject error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create subject',
      error: error.message
    });
  }
});

// Update subject (Admin only)
router.put('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const subjectId = req.params.id;
    const updateData = req.body;

    // Remove fields that shouldn't be updated
    delete updateData._id;
    delete updateData.createdAt;

    // Validate type if provided
    if (updateData.type && !['theory', 'lab', 'practical'].includes(updateData.type)) {
      return res.status(400).json({
        success: false,
        message: 'Type must be theory, lab, or practical'
      });
    }

    // Convert numeric fields
    if (updateData.year) updateData.year = parseInt(updateData.year);
    if (updateData.semester) updateData.semester = parseInt(updateData.semester);
    if (updateData.credits) updateData.credits = parseInt(updateData.credits);
    if (updateData.periodsPerWeek) updateData.periodsPerWeek = parseInt(updateData.periodsPerWeek);

    const result = await Subject.updateById(subjectId, updateData);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Subject not found'
      });
    }

    res.json({
      success: true,
      message: 'Subject updated successfully'
    });
  } catch (error) {
    console.error('Update subject error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update subject',
      error: error.message
    });
  }
});

// Delete subject (Admin only) - Soft delete
router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const subjectId = req.params.id;

    const result = await Subject.deleteById(subjectId);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Subject not found'
      });
    }

    res.json({
      success: true,
      message: 'Subject deleted successfully'
    });
  } catch (error) {
    console.error('Delete subject error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete subject',
      error: error.message
    });
  }
});

// Get lab subjects
router.get('/type/lab', verifyToken, requireAuth, async (req, res) => {
  try {
    const { department, year, semester } = req.query;
    
    if (!department || !year || !semester) {
      return res.status(400).json({
        success: false,
        message: 'Department, year, and semester are required'
      });
    }

    const labSubjects = await Subject.findLabSubjects(department, parseInt(year), parseInt(semester));

    res.json({
      success: true,
      data: labSubjects,
      count: labSubjects.length
    });
  } catch (error) {
    console.error('Get lab subjects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch lab subjects',
      error: error.message
    });
  }
});

// Get theory subjects
router.get('/type/theory', verifyToken, requireAuth, async (req, res) => {
  try {
    const { department, year, semester } = req.query;
    
    if (!department || !year || !semester) {
      return res.status(400).json({
        success: false,
        message: 'Department, year, and semester are required'
      });
    }

    const theorySubjects = await Subject.findTheorySubjects(department, parseInt(year), parseInt(semester));

    res.json({
      success: true,
      data: theorySubjects,
      count: theorySubjects.length
    });
  } catch (error) {
    console.error('Get theory subjects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch theory subjects',
      error: error.message
    });
  }
});

module.exports = router;
