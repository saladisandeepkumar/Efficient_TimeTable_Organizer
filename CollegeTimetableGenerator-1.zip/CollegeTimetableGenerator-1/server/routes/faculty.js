const express = require('express');
const Faculty = require('../models/Faculty');
const { verifyToken, requireAdmin, requireAuth } = require('../middleware/auth');

const router = express.Router();

// Get all faculty (Admin and Faculty can view)
router.get('/', verifyToken, requireAuth, async (req, res) => {
  try {
    const { department, search } = req.query;
    let faculty;

    if (search) {
      faculty = await Faculty.searchByName(search);
    } else if (department) {
      faculty = await Faculty.findByDepartment(department);
    } else {
      faculty = await Faculty.getAll();
    }

    res.json({
      success: true,
      data: faculty,
      count: faculty.length
    });
  } catch (error) {
    console.error('Get faculty error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch faculty',
      error: error.message
    });
  }
});

// Get faculty by ID
router.get('/:id', verifyToken, requireAuth, async (req, res) => {
  try {
    const faculty = await Faculty.findById(req.params.id);
    
    if (!faculty) {
      return res.status(404).json({
        success: false,
        message: 'Faculty not found'
      });
    }

    res.json({
      success: true,
      data: faculty
    });
  } catch (error) {
    console.error('Get faculty by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch faculty',
      error: error.message
    });
  }
});

// Create new faculty (Admin only)
router.post('/', verifyToken, requireAdmin, async (req, res) => {
  try {
    const {
      employeeId,
      name,
      email,
      department,
      designation,
      maxLecturesPerDay
    } = req.body;

    // Validation
    if (!employeeId || !name || !email || !department) {
      return res.status(400).json({
        success: false,
        message: 'Employee ID, name, email, and department are required'
      });
    }

    // Check if faculty with same employee ID exists
    const existingFaculty = await Faculty.findByEmployeeId(employeeId);
    if (existingFaculty) {
      return res.status(400).json({
        success: false,
        message: 'Faculty with this employee ID already exists'
      });
    }

    const facultyData = {
      employeeId,
      name,
      email,
      department,
      designation: designation || 'Assistant Professor',
      maxLecturesPerDay: maxLecturesPerDay || 4
    };

    const faculty = new Faculty(facultyData);
    const savedFaculty = await faculty.save();

    res.status(201).json({
      success: true,
      message: 'Faculty created successfully',
      data: savedFaculty
    });
  } catch (error) {
    console.error('Create faculty error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create faculty',
      error: error.message
    });
  }
});

// Update faculty (Admin only)
router.put('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const facultyId = req.params.id;
    const updateData = req.body;

    // Remove fields that shouldn't be updated
    delete updateData._id;
    delete updateData.createdAt;

    const result = await Faculty.updateById(facultyId, updateData);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Faculty not found'
      });
    }

    res.json({
      success: true,
      message: 'Faculty updated successfully'
    });
  } catch (error) {
    console.error('Update faculty error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update faculty',
      error: error.message
    });
  }
});

// Delete faculty (Admin only) - Soft delete
router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const facultyId = req.params.id;

    const result = await Faculty.deleteById(facultyId);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Faculty not found'
      });
    }

    res.json({
      success: true,
      message: 'Faculty deleted successfully'
    });
  } catch (error) {
    console.error('Delete faculty error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete faculty',
      error: error.message
    });
  }
});

// Get faculty by employee ID
router.get('/employee/:employeeId', verifyToken, requireAuth, async (req, res) => {
  try {
    const faculty = await Faculty.findByEmployeeId(req.params.employeeId);
    
    if (!faculty) {
      return res.status(404).json({
        success: false,
        message: 'Faculty not found'
      });
    }

    res.json({
      success: true,
      data: faculty
    });
  } catch (error) {
    console.error('Get faculty by employee ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch faculty',
      error: error.message
    });
  }
});

// Get faculty by department
router.get('/department/:department', verifyToken, requireAuth, async (req, res) => {
  try {
    const faculty = await Faculty.findByDepartment(req.params.department);

    res.json({
      success: true,
      data: faculty,
      count: faculty.length
    });
  } catch (error) {
    console.error('Get faculty by department error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch faculty',
      error: error.message
    });
  }
});

// Get faculty-specific timetable
router.get('/:employeeId/timetable', verifyToken, requireAuth, async (req, res) => {
  try {
    const { employeeId } = req.params;
    
    // Verify faculty access
    if (req.user.role !== 'admin' && req.user.employeeId !== employeeId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied. You can only view your own timetable.'
      });
    }
    
    // Find faculty member
    const faculty = await Faculty.findByEmployeeId(employeeId);
    if (!faculty) {
      return res.status(404).json({
        success: false,
        message: 'Faculty member not found'
      });
    }
    
    // Get all timetables and extract faculty-specific schedule
    const allTimetables = await Timetable.getAllActive();
    const facultySchedule = [];
    
    allTimetables.forEach(timetable => {
      if (timetable.schedule && Array.isArray(timetable.schedule)) {
        timetable.schedule.forEach((daySchedule, dayIndex) => {
          if (daySchedule && Array.isArray(daySchedule)) {
            daySchedule.forEach((period, periodIndex) => {
              if (period && period.facultyId === faculty.id) {
                facultySchedule.push({
                  day: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayIndex],
                  period: periodIndex,
                  periodTime: ['9:00-9:50', '9:50-10:40', '10:40-11:30', '11:30-12:20', '12:20-1:10', '1:10-2:00', '2:00-2:50'][periodIndex],
                  subjectName: period.subjectName,
                  subjectCode: period.subjectCode,
                  subjectType: period.subjectType,
                  className: `${timetable.department} ${timetable.year}-${timetable.semester} ${timetable.section}`,
                  department: timetable.department,
                  year: timetable.year,
                  semester: timetable.semester,
                  section: timetable.section
                });
              }
            });
          }
        });
      }
    });
    
    res.json({
      success: true,
      data: facultySchedule,
      faculty: {
        name: faculty.name,
        employeeId: faculty.employeeId,
        department: faculty.department,
        designation: faculty.designation
      },
      totalClasses: facultySchedule.length
    });
  } catch (error) {
    console.error('Get faculty timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch faculty timetable',
      error: error.message
    });
  }
});

module.exports = router;
