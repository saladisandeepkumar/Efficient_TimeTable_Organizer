const express = require('express');
const Timetable = require('../models/Timetable');
const Allocation = require('../models/Allocation');
const { generateEnhancedTimetable } = require('../services/enhancedTimetableGenerator');
const { generateTimetablePDF } = require('../utils/pdfGenerator');
const { verifyToken, requireAdmin, requireAuth } = require('../middleware/auth');

const router = express.Router();

// Get all timetables
router.get('/', verifyToken, requireAuth, async (req, res) => {
  try {
    const { department, year, semester, section } = req.query;
    let timetables;

    if (department && year && semester && section) {
      const timetable = await Timetable.findByClassDetails(department, parseInt(year), parseInt(semester), section);
      timetables = timetable ? [timetable] : [];
    } else {
      timetables = await Timetable.getAllActive();
    }

    res.json({
      success: true,
      data: timetables,
      count: timetables.length
    });
  } catch (error) {
    console.error('Get timetables error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch timetables',
      error: error.message
    });
  }
});

// Get timetable by ID
router.get('/:id', verifyToken, requireAuth, async (req, res) => {
  try {
    const timetable = await Timetable.findById(req.params.id);
    
    if (!timetable) {
      return res.status(404).json({
        success: false,
        message: 'Timetable not found'
      });
    }

    res.json({
      success: true,
      data: timetable
    });
  } catch (error) {
    console.error('Get timetable by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch timetable',
      error: error.message
    });
  }
});

// Generate timetable (Admin only)
router.post('/generate', verifyToken, requireAdmin, async (req, res) => {
  try {
    const { department, year, semester, section } = req.body;

    // Validation
    if (!department || !year || !semester || !section) {
      return res.status(400).json({
        success: false,
        message: 'Department, year, semester, and section are required'
      });
    }

    // Check if allocation exists
    const allocation = await Allocation.findByClassDetails(department, parseInt(year), parseInt(semester), section);
    if (!allocation) {
      return res.status(404).json({
        success: false,
        message: 'No allocation found for this class. Please create allocation first.'
      });
    }

    if (!allocation.facultySubjects || allocation.facultySubjects.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No faculty-subject mappings found in allocation'
      });
    }

    // Generate timetable with enhanced constraints
    const generationResult = await generateEnhancedTimetable(allocation);
    
    if (!generationResult.success) {
      return res.status(400).json({
        success: false,
        message: 'Failed to generate timetable',
        error: generationResult.error,
        details: generationResult.details
      });
    }

    // Save timetable
    const timetableData = {
      department,
      year: parseInt(year),
      semester: parseInt(semester),
      section,
      schedule: generationResult.schedule,
      generatedBy: req.user._id,
      allocationId: allocation._id,
      metadata: generationResult.metadata
    };

    const savedTimetable = await Timetable.replaceExisting(department, parseInt(year), parseInt(semester), section, timetableData);

    res.status(201).json({
      success: true,
      message: 'Timetable generated successfully',
      data: savedTimetable
    });
  } catch (error) {
    console.error('Generate timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate timetable',
      error: error.message
    });
  }
});

// Update timetable (Admin only)
router.put('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const timetableId = req.params.id;
    const updateData = req.body;

    // Remove fields that shouldn't be updated
    delete updateData._id;
    delete updateData.createdAt;
    delete updateData.generatedBy;
    delete updateData.allocationId;

    // Convert numeric fields
    if (updateData.year) updateData.year = parseInt(updateData.year);
    if (updateData.semester) updateData.semester = parseInt(updateData.semester);

    const result = await Timetable.updateById(timetableId, updateData);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Timetable not found'
      });
    }

    res.json({
      success: true,
      message: 'Timetable updated successfully'
    });
  } catch (error) {
    console.error('Update timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update timetable',
      error: error.message
    });
  }
});

// Delete timetable (Admin only) - Soft delete
router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const timetableId = req.params.id;

    const result = await Timetable.deleteById(timetableId);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Timetable not found'
      });
    }

    res.json({
      success: true,
      message: 'Timetable deleted successfully'
    });
  } catch (error) {
    console.error('Delete timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete timetable',
      error: error.message
    });
  }
});

// Get faculty timetable
router.get('/faculty/:facultyId', verifyToken, requireAuth, async (req, res) => {
  try {
    const facultyId = req.params.facultyId;
    const facultySchedule = await Timetable.getFacultySchedule(facultyId);

    res.json({
      success: true,
      data: facultySchedule,
      count: facultySchedule.length
    });
  } catch (error) {
    console.error('Get faculty timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch faculty timetable',
      error: error.message
    });
  }
});

// Export timetable as PDF
router.get('/:id/export', verifyToken, requireAuth, async (req, res) => {
  try {
    const timetableId = req.params.id;
    const timetable = await Timetable.findById(timetableId);
    
    if (!timetable) {
      return res.status(404).json({
        success: false,
        message: 'Timetable not found'
      });
    }

    // Generate PDF
    const pdfBuffer = await generateTimetablePDF(timetable);

    // Set headers for PDF download
    const filename = `timetable_${timetable.department}_${timetable.year}_${timetable.semester}_${timetable.section}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdfBuffer.length);

    res.send(pdfBuffer);
  } catch (error) {
    console.error('Export timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to export timetable',
      error: error.message
    });
  }
});

// Get faculty-specific timetable
router.get('/faculty/:employeeId', verifyToken, requireAuth, async (req, res) => {
  try {
    const { employeeId } = req.params;
    
    // Verify faculty access
    if (req.user.role !== 'admin' && req.user.employeeId !== employeeId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied. You can only view your own timetable.'
      });
    }
    
    // Find faculty member
    const faculty = await Faculty.findByEmployeeId(employeeId);
    if (!faculty) {
      return res.status(404).json({
        success: false,
        message: 'Faculty member not found'
      });
    }
    
    // Get all timetables and extract faculty-specific schedule
    const allTimetables = await Timetable.getAllActive();
    const facultySchedule = [];
    
    allTimetables.forEach(timetable => {
      if (timetable.schedule && Array.isArray(timetable.schedule)) {
        timetable.schedule.forEach((daySchedule, dayIndex) => {
          if (daySchedule && Array.isArray(daySchedule)) {
            daySchedule.forEach((period, periodIndex) => {
              if (period && period.facultyId === faculty.id) {
                facultySchedule.push({
                  day: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayIndex],
                  period: periodIndex,
                  periodTime: ['9:00-9:50', '9:50-10:40', '10:40-11:30', '11:30-12:20', '12:20-1:10', '1:10-2:00', '2:00-2:50'][periodIndex],
                  subjectName: period.subjectName,
                  subjectCode: period.subjectCode,
                  subjectType: period.subjectType,
                  className: `${timetable.department} ${timetable.year}-${timetable.semester} ${timetable.section}`,
                  department: timetable.department,
                  year: timetable.year,
                  semester: timetable.semester,
                  section: timetable.section
                });
              }
            });
          }
        });
      }
    });
    
    res.json({
      success: true,
      data: facultySchedule,
      faculty: {
        name: faculty.name,
        employeeId: faculty.employeeId,
        department: faculty.department,
        designation: faculty.designation
      },
      totalClasses: facultySchedule.length
    });
  } catch (error) {
    console.error('Get faculty timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch faculty timetable',
      error: error.message
    });
  }
});

// Export faculty-specific timetable as PDF
router.get('/faculty/:employeeId/export', verifyToken, requireAuth, async (req, res) => {
  try {
    const { employeeId } = req.params;
    
    // Verify faculty access
    if (req.user.role !== 'admin' && req.user.employeeId !== employeeId) {
      return res.status(403).json({
        success: false,
        message: 'Access denied. You can only export your own timetable.'
      });
    }
    
    // Find faculty member
    const faculty = await Faculty.findByEmployeeId(employeeId);
    if (!faculty) {
      return res.status(404).json({
        success: false,
        message: 'Faculty member not found'
      });
    }
    
    // Get faculty schedule (reuse logic from above)
    const allTimetables = await Timetable.getAllActive();
    const facultySchedule = [];
    
    allTimetables.forEach(timetable => {
      if (timetable.schedule && Array.isArray(timetable.schedule)) {
        timetable.schedule.forEach((daySchedule, dayIndex) => {
          if (daySchedule && Array.isArray(daySchedule)) {
            daySchedule.forEach((period, periodIndex) => {
              if (period && period.facultyId === faculty.id) {
                facultySchedule.push({
                  day: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayIndex],
                  period: periodIndex,
                  periodTime: ['9:00-9:50', '9:50-10:40', '10:40-11:30', '11:30-12:20', '12:20-1:10', '1:10-2:00', '2:00-2:50'][periodIndex],
                  subjectName: period.subjectName,
                  subjectCode: period.subjectCode,
                  subjectType: period.subjectType,
                  className: `${timetable.department} ${timetable.year}-${timetable.semester} ${timetable.section}`,
                  department: timetable.department,
                  year: timetable.year,
                  semester: timetable.semester,
                  section: timetable.section
                });
              }
            });
          }
        });
      }
    });
    
    // Generate faculty-specific PDF
    const pdfBuffer = await generateFacultyTimetablePDF(faculty, facultySchedule);
    
    // Set headers for PDF download
    const filename = `faculty_schedule_${faculty.employeeId}_${faculty.name.replace(/\s+/g, '_')}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdfBuffer.length);
    
    res.send(pdfBuffer);
  } catch (error) {
    console.error('Export faculty timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to export faculty timetable',
      error: error.message
    });
  }
});

// Export faculty timetable as PDF
router.get('/faculty/:facultyId/export', verifyToken, requireAuth, async (req, res) => {
  try {
    const facultyId = req.params.facultyId;
    const facultySchedule = await Timetable.getFacultySchedule(facultyId);
    
    if (!facultySchedule || facultySchedule.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No timetable found for this faculty'
      });
    }

    // Generate PDF for faculty
    const pdfBuffer = await generateTimetablePDF(null, facultySchedule, true);

    // Set headers for PDF download
    const filename = `faculty_timetable_${facultyId}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdfBuffer.length);

    res.send(pdfBuffer);
  } catch (error) {
    console.error('Export faculty timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to export faculty timetable',
      error: error.message
    });
  }
});

// Regenerate timetable (Admin only)
router.post('/:id/regenerate', verifyToken, requireAdmin, async (req, res) => {
  try {
    const timetableId = req.params.id;
    const timetable = await Timetable.findById(timetableId);
    
    if (!timetable) {
      return res.status(404).json({
        success: false,
        message: 'Timetable not found'
      });
    }

    // Get allocation
    const allocation = await Allocation.findById(timetable.allocationId);
    if (!allocation) {
      return res.status(404).json({
        success: false,
        message: 'Associated allocation not found'
      });
    }

    // Regenerate timetable
    const generationResult = await generateTimetable(allocation);
    
    if (!generationResult.success) {
      return res.status(400).json({
        success: false,
        message: 'Failed to regenerate timetable',
        error: generationResult.error,
        details: generationResult.details
      });
    }

    // Update timetable
    const updateData = {
      schedule: generationResult.schedule,
      metadata: generationResult.metadata
    };

    await Timetable.updateById(timetableId, updateData);

    res.json({
      success: true,
      message: 'Timetable regenerated successfully'
    });
  } catch (error) {
    console.error('Regenerate timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to regenerate timetable',
      error: error.message
    });
  }
});

// Delete timetable (Admin only)
router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const timetableId = req.params.id;
    const timetable = await Timetable.findById(timetableId);
    
    if (!timetable) {
      return res.status(404).json({
        success: false,
        message: 'Timetable not found'
      });
    }

    // Delete the timetable
    await Timetable.deleteById(timetableId);

    res.json({
      success: true,
      message: 'Timetable deleted successfully'
    });
  } catch (error) {
    console.error('Delete timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete timetable',
      error: error.message
    });
  }
});

module.exports = router;
