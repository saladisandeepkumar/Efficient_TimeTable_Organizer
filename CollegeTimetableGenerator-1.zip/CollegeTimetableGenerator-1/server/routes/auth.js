const express = require('express');
const User = require('../models/User');
const Faculty = require('../models/Faculty');
const { generateToken, verifyToken } = require('../middleware/auth');

const router = express.Router();

// Register new user (Admin only for creating faculty accounts)
router.post('/register', async (req, res) => {
  try {
    const { email, password, role, employeeId, name, department } = req.body;

    // Validation
    if (!email || !password || !role || !name) {
      return res.status(400).json({
        success: false,
        message: 'Email, password, role, and name are required'
      });
    }

    if (role === 'faculty' && !employeeId) {
      return res.status(400).json({
        success: false,
        message: 'Employee ID is required for faculty'
      });
    }

    // Check if user already exists
    const existingUser = await User.findByEmail(email);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User with this email already exists'
      });
    }

    // Check if employee ID already exists for faculty
    if (role === 'faculty') {
      const existingEmployee = await User.findByEmployeeId(employeeId);
      if (existingEmployee) {
        return res.status(400).json({
          success: false,
          message: 'User with this employee ID already exists'
        });
      }
    }

    // Create new user
    const userData = {
      email,
      password,
      role,
      name,
      employeeId: role === 'faculty' ? employeeId : undefined,
      department: role === 'faculty' ? department : undefined
    };

    const user = new User(userData);
    const savedUser = await user.save();

    // If faculty, also create faculty record
    if (role === 'faculty') {
      const facultyData = {
        employeeId,
        name,
        email,
        department: department || 'General',
        designation: 'Assistant Professor'
      };
      const faculty = new Faculty(facultyData);
      await faculty.save();
    }

    // Generate token
    const token = generateToken(savedUser._id);

    // Remove password from response
    const { password: _, ...userResponse } = savedUser;

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        user: userResponse,
        token
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Registration failed',
      error: error.message
    });
  }
});

// Login user
router.post('/login', async (req, res) => {
  try {
    const { email, password, employeeId } = req.body;

    // Find user by email or employee ID
    let user;
    if (email) {
      user = await User.findByEmail(email);
    } else if (employeeId) {
      user = await User.findByEmployeeId(employeeId);
    } else {
      return res.status(400).json({
        success: false,
        message: 'Email or Employee ID is required'
      });
    }

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check password
    const isPasswordValid = await User.comparePassword(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Generate token
    const token = generateToken(user._id);

    // Remove password from response
    const { password: _, ...userResponse } = user;

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user: userResponse,
        token
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed',
      error: error.message
    });
  }
});

// Get current user profile
router.get('/profile', verifyToken, async (req, res) => {
  try {
    const user = req.user;
    
    // If faculty, get additional faculty details
    if (user.role === 'faculty') {
      const facultyDetails = await Faculty.findByEmployeeId(user.employeeId);
      res.json({
        success: true,
        data: {
          ...user,
          facultyDetails
        }
      });
    } else {
      res.json({
        success: true,
        data: user
      });
    }
  } catch (error) {
    console.error('Profile fetch error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch profile',
      error: error.message
    });
  }
});

// Update user profile
router.put('/profile', verifyToken, async (req, res) => {
  try {
    const userId = req.user._id;
    const updateData = req.body;

    // Remove sensitive fields that shouldn't be updated via this endpoint
    delete updateData.password;
    delete updateData.role;
    delete updateData._id;

    await User.updateById(userId, updateData);

    // If faculty, update faculty record too
    if (req.user.role === 'faculty' && req.user.employeeId) {
      const facultyUpdateData = {
        name: updateData.name,
        email: updateData.email,
        department: updateData.department
      };
      
      const faculty = await Faculty.findByEmployeeId(req.user.employeeId);
      if (faculty) {
        await Faculty.updateById(faculty._id, facultyUpdateData);
      }
    }

    res.json({
      success: true,
      message: 'Profile updated successfully'
    });
  } catch (error) {
    console.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update profile',
      error: error.message
    });
  }
});

// Change password
router.put('/change-password', verifyToken, async (req, res) => {
  try {
    const userId = req.user._id;
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Current password and new password are required'
      });
    }

    // Get user with password
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Verify current password
    const isCurrentPasswordValid = await User.comparePassword(currentPassword, user.password);
    if (!isCurrentPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    // Update password
    await User.updateById(userId, { password: newPassword });

    res.json({
      success: true,
      message: 'Password changed successfully'
    });
  } catch (error) {
    console.error('Password change error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to change password',
      error: error.message
    });
  }
});

module.exports = router;
