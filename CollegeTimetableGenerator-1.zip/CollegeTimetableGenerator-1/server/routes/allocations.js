const express = require('express');
const Allocation = require('../models/Allocation');
const Faculty = require('../models/Faculty');
const Subject = require('../models/Subject');
const { verifyToken, requireAdmin, requireAuth } = require('../middleware/auth');

const router = express.Router();

// Get all allocations
router.get('/', verifyToken, requireAuth, async (req, res) => {
  try {
    const { department, year, semester, section } = req.query;
    let allocations;

    if (department && year && semester && section) {
      const allocation = await Allocation.findByClassDetails(department, parseInt(year), parseInt(semester), section);
      allocations = allocation ? [allocation] : [];
    } else {
      allocations = await Allocation.getAllActive();
    }

    res.json({
      success: true,
      data: allocations,
      count: allocations.length
    });
  } catch (error) {
    console.error('Get allocations error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch allocations',
      error: error.message
    });
  }
});

// Get allocation by ID with populated data
router.get('/:id', verifyToken, requireAuth, async (req, res) => {
  try {
    const allocation = await Allocation.findById(req.params.id);
    
    if (!allocation) {
      return res.status(404).json({
        success: false,
        message: 'Allocation not found'
      });
    }

    // Populate faculty and subject details
    const populatedAllocation = await populateAllocationData(allocation);

    res.json({
      success: true,
      data: populatedAllocation
    });
  } catch (error) {
    console.error('Get allocation by ID error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch allocation',
      error: error.message
    });
  }
});

// Create new allocation (Admin only)
router.post('/', verifyToken, requireAdmin, async (req, res) => {
  try {
    const {
      department,
      year,
      semester,
      section,
      facultySubjects
    } = req.body;

    // Validation
    if (!department || !year || !semester || !section) {
      return res.status(400).json({
        success: false,
        message: 'Department, year, semester, and section are required'
      });
    }

    // Check if allocation already exists for this class
    const existingAllocation = await Allocation.findByClassDetails(department, parseInt(year), parseInt(semester), section);
    if (existingAllocation) {
      return res.status(400).json({
        success: false,
        message: 'Allocation already exists for this class'
      });
    }

    // Validate faculty and subjects if provided
    if (facultySubjects && facultySubjects.length > 0) {
      const validation = await validateFacultySubjects(facultySubjects);
      if (!validation.isValid) {
        return res.status(400).json({
          success: false,
          message: validation.message
        });
      }
    }

    const allocationData = {
      department,
      year: parseInt(year),
      semester: parseInt(semester),
      section,
      facultySubjects: facultySubjects || [],
      createdBy: req.user._id
    };

    const allocation = new Allocation(allocationData);
    const savedAllocation = await allocation.save();

    res.status(201).json({
      success: true,
      message: 'Allocation created successfully',
      data: savedAllocation
    });
  } catch (error) {
    console.error('Create allocation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create allocation',
      error: error.message
    });
  }
});

// Update allocation (Admin only)
router.put('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const allocationId = req.params.id;
    const updateData = req.body;

    // Remove fields that shouldn't be updated
    delete updateData._id;
    delete updateData.createdAt;
    delete updateData.createdBy;

    // Validate faculty and subjects if provided
    if (updateData.facultySubjects && updateData.facultySubjects.length > 0) {
      const validation = await validateFacultySubjects(updateData.facultySubjects);
      if (!validation.isValid) {
        return res.status(400).json({
          success: false,
          message: validation.message
        });
      }
    }

    // Convert numeric fields
    if (updateData.year) updateData.year = parseInt(updateData.year);
    if (updateData.semester) updateData.semester = parseInt(updateData.semester);

    const result = await Allocation.updateById(allocationId, updateData);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Allocation not found'
      });
    }

    res.json({
      success: true,
      message: 'Allocation updated successfully'
    });
  } catch (error) {
    console.error('Update allocation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update allocation',
      error: error.message
    });
  }
});

// Delete allocation (Admin only) - Soft delete
router.delete('/:id', verifyToken, requireAdmin, async (req, res) => {
  try {
    const allocationId = req.params.id;

    const result = await Allocation.deleteById(allocationId);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Allocation not found'
      });
    }

    res.json({
      success: true,
      message: 'Allocation deleted successfully'
    });
  } catch (error) {
    console.error('Delete allocation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete allocation',
      error: error.message
    });
  }
});

// Add faculty-subject pair to allocation (Admin only)
router.post('/:id/faculty-subject', verifyToken, requireAdmin, async (req, res) => {
  try {
    const allocationId = req.params.id;
    const { facultyId, subjectId } = req.body;

    if (!facultyId || !subjectId) {
      return res.status(400).json({
        success: false,
        message: 'Faculty ID and Subject ID are required'
      });
    }

    // Validate faculty and subject exist
    const faculty = await Faculty.findById(facultyId);
    const subject = await Subject.findById(subjectId);

    if (!faculty || !subject) {
      return res.status(404).json({
        success: false,
        message: 'Faculty or Subject not found'
      });
    }

    const result = await Allocation.addFacultySubject(allocationId, facultyId, subjectId);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Allocation not found'
      });
    }

    res.json({
      success: true,
      message: 'Faculty-Subject pair added successfully'
    });
  } catch (error) {
    console.error('Add faculty-subject error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add faculty-subject pair',
      error: error.message
    });
  }
});

// Remove faculty-subject pair from allocation (Admin only)
router.delete('/:id/faculty-subject', verifyToken, requireAdmin, async (req, res) => {
  try {
    const allocationId = req.params.id;
    const { facultyId, subjectId } = req.body;

    if (!facultyId || !subjectId) {
      return res.status(400).json({
        success: false,
        message: 'Faculty ID and Subject ID are required'
      });
    }

    const result = await Allocation.removeFacultySubject(allocationId, facultyId, subjectId);

    if (result.matchedCount === 0) {
      return res.status(404).json({
        success: false,
        message: 'Allocation not found'
      });
    }

    res.json({
      success: true,
      message: 'Faculty-Subject pair removed successfully'
    });
  } catch (error) {
    console.error('Remove faculty-subject error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove faculty-subject pair',
      error: error.message
    });
  }
});

// Get allocations by faculty
router.get('/faculty/:facultyId', verifyToken, requireAuth, async (req, res) => {
  try {
    const allocations = await Allocation.findByFaculty(req.params.facultyId);

    // Populate data for each allocation
    const populatedAllocations = await Promise.all(
      allocations.map(allocation => populateAllocationData(allocation))
    );

    res.json({
      success: true,
      data: populatedAllocations,
      count: populatedAllocations.length
    });
  } catch (error) {
    console.error('Get allocations by faculty error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch faculty allocations',
      error: error.message
    });
  }
});

// Helper function to validate faculty-subject pairs
async function validateFacultySubjects(facultySubjects) {
  try {
    const facultyIds = [...new Set(facultySubjects.map(fs => fs.facultyId))];
    const subjectIds = [...new Set(facultySubjects.map(fs => fs.subjectId))];

    const faculties = await Faculty.findByIds(facultyIds);
    const subjects = await Subject.findByIds(subjectIds);

    if (faculties.length !== facultyIds.length) {
      return { isValid: false, message: 'One or more faculty members not found' };
    }

    if (subjects.length !== subjectIds.length) {
      return { isValid: false, message: 'One or more subjects not found' };
    }

    return { isValid: true };
  } catch (error) {
    return { isValid: false, message: 'Validation error: ' + error.message };
  }
}

// Helper function to populate allocation data
async function populateAllocationData(allocation) {
  try {
    const populatedFacultySubjects = await Promise.all(
      allocation.facultySubjects.map(async (fs) => {
        const faculty = await Faculty.findById(fs.facultyId);
        const subject = await Subject.findById(fs.subjectId);
        return {
          facultyId: fs.facultyId,
          subjectId: fs.subjectId,
          faculty,
          subject
        };
      })
    );

    return {
      ...allocation,
      facultySubjects: populatedFacultySubjects
    };
  } catch (error) {
    console.error('Error populating allocation data:', error);
    return allocation;
  }
}

module.exports = router;
