const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 8000;

// In-memory storage for generated timetables with persistence
let generatedTimetables = [];
let timetableIdCounter = 1;

// Load timetables from persistent storage (simulate with file system)
const fs = require('fs');
const TIMETABLES_FILE = path.join(__dirname, 'timetables.json');

// Load existing timetables on startup
function loadTimetables() {
  try {
    if (fs.existsSync(TIMETABLES_FILE)) {
      const data = fs.readFileSync(TIMETABLES_FILE, 'utf8');
      const parsed = JSON.parse(data);
      generatedTimetables = parsed.timetables || [];
      timetableIdCounter = parsed.counter || 1;
      console.log(`Loaded ${generatedTimetables.length} existing timetables`);
    }
  } catch (error) {
    console.log('No existing timetables found, starting fresh');
  }
}

// Save timetables to persistent storage
function saveTimetables() {
  try {
    const data = {
      timetables: generatedTimetables,
      counter: timetableIdCounter
    };
    fs.writeFileSync(TIMETABLES_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Failed to save timetables:', error);
  }
}

// Load timetables on startup
loadTimetables();

// Basic middleware
app.use(cors());
app.use(express.json());



// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'SmartScheduler API is running',
    timestamp: new Date().toISOString()
  });
});

// In-memory faculty storage
let facultyList = [
  {
    id: 1,
    employeeId: 'FAC001',
    name: 'Dr. John Smith',
    email: 'john.smith@college.edu',
    department: 'Computer Science',
    designation: 'Professor'
  },
  {
    id: 2,
    employeeId: 'FAC002', 
    name: 'Dr. Sarah Johnson',
    email: 'sarah.johnson@college.edu',
    department: 'Computer Science',
    designation: 'Associate Professor'
  },
  {
    id: 3,
    employeeId: 'FAC003',
    name: 'Dr. Michael Brown',
    email: 'michael.brown@college.edu',
    department: 'Computer Science', 
    designation: 'Assistant Professor'
  }
];

// Faculty endpoints
app.get('/api/faculty', (req, res) => {
  res.json({
    success: true,
    data: facultyList,
    count: facultyList.length
  });
});

app.post('/api/faculty', (req, res) => {
  const newFaculty = {
    id: Math.max(...facultyList.map(f => f.id), 0) + 1,
    ...req.body
  };
  facultyList.push(newFaculty);
  res.json({
    success: true,
    data: newFaculty,
    message: 'Faculty member added successfully'
  });
});

app.put('/api/faculty/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = facultyList.findIndex(f => f.id === id);
  
  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: 'Faculty member not found'
    });
  }
  
  facultyList[index] = { ...facultyList[index], ...req.body };
  res.json({
    success: true,
    data: facultyList[index],
    message: 'Faculty member updated successfully'
  });
});

app.delete('/api/faculty/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = facultyList.findIndex(f => f.id === id);
  
  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: 'Faculty member not found'
    });
  }
  
  const deletedFaculty = facultyList.splice(index, 1)[0];
  res.json({
    success: true,
    data: deletedFaculty,
    message: 'Faculty member deleted successfully'
  });
});

// In-memory subjects storage
let subjectsList = [
    {
      id: 1,
      code: 'CS101',
      name: 'Programming Fundamentals',
      type: 'theory',
      credits: 3,
      department: 'Computer Science',
      year: 1,
      semester: 1
    },
    {
      id: 2,
      code: 'CS102',
      name: 'Programming Lab',
      type: 'lab',
      credits: 2,
      department: 'Computer Science',
      year: 1,
      semester: 1
    },
    {
      id: 3,
      code: 'CS201',
      name: 'Data Structures',
      type: 'theory',
      credits: 4,
      department: 'Computer Science',
      year: 2,
      semester: 1
    }
];

// In-memory allocations storage
let allocationsList = [
  {
    id: 1,
    department: 'Computer Science',
    year: 1,
    semester: 1,
    section: 'A',
    facultySubjects: [
      { facultyId: 1, subjectId: 1, type: 'theory' },
      { facultyId: 2, subjectId: 2, type: 'lab' }
    ]
  }
];

// Subjects endpoints
app.get('/api/subjects', (req, res) => {
  res.json({
    success: true,
    data: subjectsList,
    count: subjectsList.length
  });
});

app.post('/api/subjects', (req, res) => {
  const newSubject = {
    id: Math.max(...subjectsList.map(s => s.id), 0) + 1,
    ...req.body
  };
  subjectsList.push(newSubject);
  res.json({
    success: true,
    data: newSubject,
    message: 'Subject added successfully'
  });
});

app.put('/api/subjects/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = subjectsList.findIndex(s => s.id === id);
  
  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: 'Subject not found'
    });
  }
  
  subjectsList[index] = { ...subjectsList[index], ...req.body };
  res.json({
    success: true,
    data: subjectsList[index],
    message: 'Subject updated successfully'
  });
});

app.delete('/api/subjects/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = subjectsList.findIndex(s => s.id === id);
  
  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: 'Subject not found'
    });
  }
  
  const deletedSubject = subjectsList.splice(index, 1)[0];
  res.json({
    success: true,
    data: deletedSubject,
    message: 'Subject deleted successfully'
  });
});

// Allocation endpoints
app.get('/api/allocations', (req, res) => {
  res.json({
    success: true,
    data: allocationsList,
    count: allocationsList.length
  });
});

app.post('/api/allocations', (req, res) => {
  const newAllocation = {
    id: Math.max(...allocationsList.map(a => a.id), 0) + 1,
    ...req.body
  };
  allocationsList.push(newAllocation);
  res.json({
    success: true,
    data: newAllocation,
    message: 'Allocation created successfully'
  });
});

app.put('/api/allocations/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = allocationsList.findIndex(a => a.id === id);
  
  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: 'Allocation not found'
    });
  }
  
  allocationsList[index] = { ...allocationsList[index], ...req.body };
  res.json({
    success: true,
    data: allocationsList[index],
    message: 'Allocation updated successfully'
  });
});

app.delete('/api/allocations/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = allocationsList.findIndex(a => a.id === id);
  
  if (index === -1) {
    return res.status(404).json({
      success: false,
      message: 'Allocation not found'
    });
  }
  
  const deletedAllocation = allocationsList.splice(index, 1)[0];
  res.json({
    success: true,
    data: deletedAllocation,
    message: 'Allocation deleted successfully'
  });
});

// Auth login endpoint
app.post('/api/auth/login', (req, res) => {
  const { email, password, employeeId } = req.body;
  
  // Test credentials
  if ((email === 'admin@college.edu' && password === 'admin123') || 
      (employeeId === 'FAC001' && password === 'faculty123')) {
    
    const user = email === 'admin@college.edu' ? 
      {
        id: 'admin001',
        email: 'admin@college.edu',
        name: 'System Administrator',
        role: 'admin'
      } : 
      {
        id: 'fac001',
        email: 'john.smith@college.edu',
        name: 'Dr. John Smith',
        role: 'faculty',
        employeeId: 'FAC001'
      };
    
    res.json({
      success: true,
      message: 'Login successful',
      data: {
        user,
        token: 'test_token_' + Date.now()
      }
    });
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid credentials'
    });
  }
});

// Duplicate endpoint removed - using the one above

// Get all timetables endpoint
app.get('/api/timetables', (req, res) => {
  res.json({
    success: true,
    data: generatedTimetables,
    count: generatedTimetables.length
  });
});

// Generate timetable endpoint
// Helper function to generate balanced timetable with dynamic lunch breaks and balanced labs
function generateRandomTimetable() {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const schedule = [];
  
  // Define lab subjects for balanced distribution
  const labSubjects = [
    { subject: "Programming Lab", faculty: "Dr. Sarah Johnson", subjectCode: "CS101L", subjectType: "lab", facultyName: "Dr. Sarah Johnson" },
    { subject: "Database Lab", faculty: "Dr. Sarah Johnson", subjectCode: "CS301L", subjectType: "lab", facultyName: "Dr. Sarah Johnson" },
    { subject: "Data Structures Lab", faculty: "Dr. Michael Brown", subjectCode: "CS201L", subjectType: "lab", facultyName: "Dr. Michael Brown" },
    { subject: "Web Development Lab", faculty: "Dr. John Smith", subjectCode: "CS401L", subjectType: "lab", facultyName: "Dr. John Smith" }
  ];
  
  // Theory subjects
  const theorySubjects = [
    { subject: "Programming Fundamentals", faculty: "Dr. John Smith", subjectCode: "CS101", subjectType: "theory", facultyName: "Dr. John Smith" },
    { subject: "Data Structures", faculty: "Dr. Michael Brown", subjectCode: "CS201", subjectType: "theory", facultyName: "Dr. Michael Brown" },
    { subject: "Database Systems", faculty: "Dr. Sarah Johnson", subjectCode: "CS301", subjectType: "theory", facultyName: "Dr. Sarah Johnson" }
  ];
  
  // Pre-plan lab distribution for balance: 2 morning, 2 afternoon
  const labSlots = [
    { day: 0, type: 'morning' },  // Monday morning
    { day: 1, type: 'afternoon' }, // Tuesday afternoon
    { day: 2, type: 'morning' },  // Wednesday morning
    { day: 3, type: 'afternoon' }  // Thursday afternoon
  ];
  
  days.forEach((day, dayIndex) => {
    const daySchedule = new Array(7).fill(null);
    
    // Randomly assign lunch to period 4 or 5 (index 3 or 4)
    const lunchPeriod = Math.random() < 0.5 ? 3 : 4;
    daySchedule[lunchPeriod] = { type: "lunch" };
    
    // Check if this day should have a lab and schedule it
    const labSlot = labSlots.find(slot => slot.day === dayIndex);
    if (labSlot && dayIndex < labSubjects.length) {
      const currentLab = labSubjects[dayIndex];
      let labScheduled = false;
      
      if (labSlot.type === 'morning') {
        // Schedule in morning (periods 0-2) regardless of lunch position
        if (daySchedule[0] === null && daySchedule[1] === null && daySchedule[2] === null) {
          daySchedule[0] = currentLab;
          daySchedule[1] = currentLab;
          daySchedule[2] = currentLab;
          labScheduled = true;
        }
      } else if (labSlot.type === 'afternoon') {
        // Schedule in afternoon after lunch
        if (lunchPeriod === 3) {
          // Lunch at period 4, schedule lab at periods 4-6
          if (daySchedule[4] === null && daySchedule[5] === null && daySchedule[6] === null) {
            daySchedule[4] = currentLab;
            daySchedule[5] = currentLab;
            daySchedule[6] = currentLab;
            labScheduled = true;
          }
        } else if (lunchPeriod === 4) {
          // Lunch at period 5, schedule lab at periods 5-6 + 1 more
          if (daySchedule[5] === null && daySchedule[6] === null) {
            daySchedule[5] = currentLab;
            daySchedule[6] = currentLab;
            // Find another slot for 3rd consecutive period
            for (let i = 0; i < 7; i++) {
              if (daySchedule[i] === null && i !== lunchPeriod) {
                daySchedule[i] = currentLab;
                labScheduled = true;
                break;
              }
            }
          }
        }
      }
    }
    
    // Fill remaining periods with theory subjects
    let theoryIndex = 0;
    for (let i = 0; i < 7; i++) {
      if (daySchedule[i] === null && theoryIndex < theorySubjects.length) {
        daySchedule[i] = theorySubjects[theoryIndex];
        theoryIndex = (theoryIndex + 1) % theorySubjects.length;
      }
    }
    
    schedule.push(daySchedule);
  });
  
  return schedule;
}

app.post('/api/timetables/generate', (req, res) => {
  const { department, year, semester, section } = req.body;
  
  const generatedTimetable = {
    id: Date.now(),
    department,
    year: parseInt(year),
    semester: parseInt(semester),
    section,
    schedule: generateRandomTimetable(),
    metadata: {
      totalSubjects: 7,
      totalFaculty: 3,
      totalLabs: 4,
      constraints: {
        lunchPeriods: "Randomized between Period 4 and 5 for each day",
        labDuration: "3 consecutive periods",
        labDistribution: "Balanced between morning (2 labs) and afternoon (2 labs)",
        maxFacultyPerDay: 4
      },
      generation: {
        algorithm: "Balanced Lab Distribution with Random Lunch Breaks",
        retries: 1,
        successRate: "100%"
      }
    },
    createdAt: new Date().toISOString()
  };
  
  // Store the generated timetable
  generatedTimetables.push(generatedTimetable);
  saveTimetables(); // Persist to storage
  
  res.status(201).json({
    success: true,
    message: 'Timetable generated successfully with balanced labs and randomized lunch breaks',
    data: generatedTimetable
  });
});

// Delete timetable by ID
app.delete('/api/timetables/:id', (req, res) => {
  try {
    const timetableId = parseInt(req.params.id);
    
    console.log('Delete request for timetable ID:', timetableId);
    console.log('Available timetables:', generatedTimetables.map(t => ({ id: t.id, dept: t.department })));
    
    if (isNaN(timetableId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid timetable ID'
      });
    }
    
    const timetableIndex = generatedTimetables.findIndex(t => t.id === timetableId);
    
    if (timetableIndex === -1) {
      console.log('Timetable not found for ID:', timetableId);
      return res.status(404).json({
        success: false,
        message: 'Timetable not found'
      });
    }
    
    const deletedTimetable = generatedTimetables.splice(timetableIndex, 1)[0];
    saveTimetables(); // Persist the change
    
    console.log('Timetable deleted successfully:', deletedTimetable.id);
    
    res.json({
      success: true,
      message: 'Timetable deleted successfully',
      data: deletedTimetable
    });
  } catch (error) {
    console.error('Delete timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error while deleting timetable',
      error: error.message
    });
  }
});

// Get all timetables
app.get('/api/timetables', (req, res) => {
  res.json({
    success: true,
    data: generatedTimetables,
    count: generatedTimetables.length
  });
});

// Get timetable by ID
app.get('/api/timetables/:id', (req, res) => {
  const timetableId = parseInt(req.params.id);
  const timetable = generatedTimetables.find(t => t.id === timetableId);
  
  if (!timetable) {
    return res.status(404).json({
      success: false,
      message: 'Timetable not found'
    });
  }
  
  res.json({
    success: true,
    data: timetable
  });
});

// Export timetable as PDF
app.get('/api/timetables/:id/export', async (req, res) => {
  try {
    const timetableId = parseInt(req.params.id);
    
    console.log('PDF Export Request - ID:', timetableId);
    console.log('Available timetables:', generatedTimetables.map(t => ({ id: t.id, dept: t.department })));
    
    // Check authentication - accept token from query parameter or header
    const token = req.query.token || req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
      console.log('No authentication token provided');
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }
    
    if (isNaN(timetableId)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid timetable ID'
      });
    }
    
    const timetable = generatedTimetables.find(t => t.id === timetableId);
    
    if (!timetable) {
      console.log('Timetable not found for ID:', timetableId);
      return res.status(404).json({
        success: false,
        message: 'Timetable not found'
      });
    }

    console.log('Generating PDF for timetable:', timetable.department, 'Year:', timetable.year, 'Section:', timetable.section);
    
    // Create simple PDF using PDFkit directly
    const PDFDocument = require('pdfkit');
    const doc = new PDFDocument({ 
      size: 'A4', 
      layout: 'landscape',
      margins: { top: 50, bottom: 50, left: 50, right: 50 }
    });

    const buffers = [];
    doc.on('data', buffers.push.bind(buffers));
    
    // Generate PDF content
    doc.fontSize(20).font('Helvetica-Bold');
    doc.text('SmartScheduler - Class Timetable', 50, 50);
    
    doc.fontSize(14).font('Helvetica');
    doc.text(`Department: ${timetable.department || 'N/A'}`, 50, 90);
    doc.text(`Year: ${timetable.year || 'N/A'} | Semester: ${timetable.semester || 'N/A'} | Section: ${timetable.section || 'N/A'}`, 50, 110);
    doc.text(`Generated: ${new Date(timetable.createdAt).toLocaleDateString()}`, 50, 130);

    // Draw timetable
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const periods = ['Period 1', 'Period 2', 'Period 3', 'Period 4', 'Period 5', 'Period 6', 'Period 7'];
    
    let startY = 170;
    const cellWidth = 100;
    const cellHeight = 40;
    
    // Headers
    doc.fontSize(10).font('Helvetica-Bold');
    doc.text('Day/Period', 50, startY);
    periods.forEach((period, i) => {
      doc.text(period, 150 + (i * cellWidth), startY);
    });
    
    // Schedule content
    if (timetable.schedule && timetable.schedule.length > 0) {
      timetable.schedule.forEach((daySchedule, dayIndex) => {
        if (dayIndex < days.length) {
          const y = startY + 20 + (dayIndex * cellHeight);
          doc.fontSize(9).font('Helvetica-Bold');
          doc.text(days[dayIndex], 50, y);
          
          daySchedule.forEach((slot, periodIndex) => {
            if (periodIndex < periods.length) {
              const x = 150 + (periodIndex * cellWidth);
              doc.fontSize(8).font('Helvetica');
              if (slot && slot.type === 'lunch') {
                doc.text('LUNCH', x, y);
              } else if (slot && slot.subject) {
                doc.text(slot.subject.substring(0, 12), x, y);
                if (slot.facultyName) {
                  doc.text(slot.facultyName.substring(0, 10), x, y + 10);
                }
              }
            }
          });
        }
      });
    }

    doc.end();

    // Wait for PDF generation to complete
    const pdfBuffer = await new Promise((resolve) => {
      doc.on('end', () => {
        resolve(Buffer.concat(buffers));
      });
    });

    console.log('PDF generated successfully, size:', pdfBuffer.length);

    // Set headers for PDF download
    const filename = `timetable_${timetable.department || 'schedule'}_${timetable.year || 'Y'}_${timetable.semester || 'S'}_${timetable.section || 'A'}.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', pdfBuffer.length);
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Disposition');

    res.send(pdfBuffer);
  } catch (error) {
    console.error('Export timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to export timetable',
      error: error.message
    });
  }
});



// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ 
    success: false, 
    message: 'Internal server error'
  });
});



app.listen(PORT, '0.0.0.0', () => {
  console.log(`SmartScheduler running on port ${PORT}`);
  console.log('Frontend: http://localhost:' + PORT);
  console.log('API: http://localhost:' + PORT + '/api/');
  console.log('Test credentials:');
  console.log('  Admin: admin@college.edu / admin123');
  console.log('  Faculty: FAC001 / faculty123');
});

module.exports = app;