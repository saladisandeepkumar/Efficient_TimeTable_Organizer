const Faculty = require('../models/Faculty');
const Subject = require('../models/Subject');

class TimetableGenerator {
  constructor() {
    this.DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    this.PERIODS_PER_DAY = 7;
    this.LUNCH_PERIOD_OPTIONS = [4, 5]; // 4th or 5th period (0-indexed: 3 or 4)
    this.MAX_RETRIES = 20;
    this.MAX_FACULTY_PERIODS_PER_DAY = 4; // Faculty constraint: max 3-4 lectures per day
    this.LAB_DURATION = 3; // Lab subjects require 3 consecutive periods
    this.PERIOD_TIMES = [
      '9:00-10:00',
      '10:00-11:00', 
      '11:15-12:15',
      '12:15-1:15',
      '1:15-2:15',
      '2:30-3:30',
      '3:30-4:30'
    ];
  }

  async generateTimetable(allocation) {
    try {
      // Validate allocation
      if (!allocation.facultySubjects || allocation.facultySubjects.length === 0) {
        return {
          success: false,
          error: 'No faculty-subject mappings found'
        };
      }

      // Get faculty and subject details
      const { facultyMap, subjectMap } = await this.loadAllocationData(allocation);

      // Initialize timetable structure
      const timetable = this.initializeTimetable();

      // Attempt to generate timetable with retries
      for (let retry = 0; retry < this.MAX_RETRIES; retry++) {
        const result = await this.attemptGeneration(timetable, allocation, facultyMap, subjectMap);
        
        if (result.success) {
          return {
            success: true,
            schedule: result.schedule,
            metadata: result.metadata
          };
        }

        // Reset timetable for next attempt
        this.clearTimetable(timetable);
        console.log(`Generation attempt ${retry + 1} failed: ${result.error}`);
      }

      return {
        success: false,
        error: 'Failed to generate valid timetable after multiple attempts',
        details: 'Consider reducing constraints or adjusting subject periods'
      };

    } catch (error) {
      console.error('Timetable generation error:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async loadAllocationData(allocation) {
    const facultyIds = [...new Set(allocation.facultySubjects.map(fs => fs.facultyId))];
    const subjectIds = [...new Set(allocation.facultySubjects.map(fs => fs.subjectId))];

    const faculties = await Faculty.findByIds(facultyIds);
    const subjects = await Subject.findByIds(subjectIds);

    const facultyMap = new Map();
    const subjectMap = new Map();

    faculties.forEach(faculty => {
      facultyMap.set(faculty._id.toString(), faculty);
    });

    subjects.forEach(subject => {
      subjectMap.set(subject._id.toString(), subject);
    });

    return { facultyMap, subjectMap };
  }

  initializeTimetable() {
    const timetable = {};
    
    this.DAYS.forEach(day => {
      timetable[day] = {
        periods: new Array(this.PERIODS_PER_DAY).fill(null),
        lunchPeriod: null
      };
    });

    return timetable;
  }

  clearTimetable(timetable) {
    this.DAYS.forEach(day => {
      timetable[day].periods = new Array(this.PERIODS_PER_DAY).fill(null);
      timetable[day].lunchPeriod = null;
    });
  }

  async attemptGeneration(timetable, allocation, facultyMap, subjectMap) {
    try {
      // Step 1: Set random lunch breaks for each day
      this.setLunchBreaks(timetable);

      // Step 2: Process subjects by priority (labs first, then theory)
      const processedSubjects = this.prioritizeSubjects(allocation, subjectMap);

      // Step 3: Track faculty workload
      const facultyWorkload = this.initializeFacultyWorkload(facultyMap);

      // Step 4: Schedule subjects
      for (const subjectInfo of processedSubjects) {
        const success = await this.scheduleSubject(
          timetable, 
          subjectInfo, 
          facultyMap, 
          subjectMap, 
          facultyWorkload
        );

        if (!success) {
          return {
            success: false,
            error: `Failed to schedule subject: ${subjectInfo.subject.name}`
          };
        }
      }

      // Step 5: Convert to output format
      const schedule = this.convertToScheduleFormat(timetable, facultyMap, subjectMap);
      const metadata = this.generateMetadata(timetable, facultyWorkload);

      return {
        success: true,
        schedule,
        metadata
      };

    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  setLunchBreaks(timetable) {
    this.DAYS.forEach(day => {
      // Randomly choose 4th or 5th period for lunch (0-indexed: 3 or 4)
      const lunchPeriod = this.LUNCH_PERIOD_OPTIONS[Math.floor(Math.random() * this.LUNCH_PERIOD_OPTIONS.length)];
      timetable[day].lunchPeriod = lunchPeriod;
      timetable[day].periods[lunchPeriod] = {
        type: 'lunch',
        subject: 'Lunch Break',
        faculty: null
      };
    });
  }

  prioritizeSubjects(allocation, subjectMap) {
    const subjectPeriods = [];

    allocation.facultySubjects.forEach(fs => {
      const subject = subjectMap.get(fs.subjectId);
      const faculty = fs.facultyId;

      if (subject) {
        // Create period entries for each subject
        for (let i = 0; i < subject.periodsPerWeek; i++) {
          subjectPeriods.push({
            subject,
            facultyId: faculty,
            isLab: subject.type === 'lab'
          });
        }
      }
    });

    // Sort: labs first, then theory subjects
    subjectPeriods.sort((a, b) => {
      if (a.isLab && !b.isLab) return -1;
      if (!a.isLab && b.isLab) return 1;
      return 0;
    });

    return subjectPeriods;
  }

  initializeFacultyWorkload(facultyMap) {
    const workload = {};
    
    facultyMap.forEach((faculty, facultyId) => {
      workload[facultyId] = {
        dailyLoad: {},
        totalLoad: 0,
        maxPerDay: faculty.maxDailyLectures || 6
      };

      this.DAYS.forEach(day => {
        workload[facultyId].dailyLoad[day] = 0;
      });
    });

    return workload;
  }

  validateTimetable(timetable, facultyWorkload, facultyMap) {
    // Check for faculty overload
    for (const [facultyId, workload] of Object.entries(facultyWorkload)) {
      for (const [day, load] of Object.entries(workload.dailyLoad)) {
        if (load > workload.maxPerDay) {
          return {
            valid: false,
            error: `Faculty ${facultyId} overloaded on ${day} (${load}/${workload.maxPerDay})`
          };
        }
      }
    }

    // Check for conflicting assignments
    for (const day of this.DAYS) {
      for (let period = 0; period < this.PERIODS_PER_DAY; period++) {
        const facultiesInPeriod = new Set();
        const periodData = timetable[day].periods[period];
        
        if (periodData && periodData.facultyId) {
          if (facultiesInPeriod.has(periodData.facultyId)) {
            return {
              valid: false,
              error: `Faculty ${periodData.facultyId} has conflict on ${day}, period ${period + 1}`
            };
          }
          facultiesInPeriod.add(periodData.facultyId);
        }
      }
    }

    return { valid: true };
  }

  async scheduleSubject(timetable, subjectInfo, facultyMap, subjectMap, facultyWorkload) {
    if (subjectInfo.isLab) {
      return this.scheduleLabSubject(timetable, subjectInfo, facultyWorkload);
    } else {
      return this.scheduleTheorySubject(timetable, subjectInfo, facultyWorkload);
    }
  }

  scheduleLabSubject(timetable, subjectInfo, facultyWorkload) {
    const { subject, facultyId } = subjectInfo;
    const faculty = facultyWorkload[facultyId];

    // Shuffle days for random placement
    const shuffledDays = [...this.DAYS].sort(() => Math.random() - 0.5);

    for (const day of shuffledDays) {
      const daySchedule = timetable[day];
      const lunchPeriod = daySchedule.lunchPeriod;

      // Check if faculty has capacity for 3 more periods
      if (faculty.dailyLoad[day] + 3 > faculty.maxPerDay) {
        continue;
      }

      // Try to place 3 consecutive periods before lunch
      const beforeLunchSlot = this.findConsecutiveSlots(daySchedule.periods, 0, lunchPeriod, 3);
      if (beforeLunchSlot !== -1) {
        this.assignLabPeriods(daySchedule.periods, beforeLunchSlot, subject, facultyId);
        faculty.dailyLoad[day] += 3;
        faculty.totalLoad += 3;
        return true;
      }

      // Try to place 3 consecutive periods after lunch (if enough space)
      const periodsAfterLunch = this.PERIODS_PER_DAY - (lunchPeriod + 1);
      if (periodsAfterLunch >= 3) {
        const afterLunchSlot = this.findConsecutiveSlots(daySchedule.periods, lunchPeriod + 1, this.PERIODS_PER_DAY, 3);
        if (afterLunchSlot !== -1) {
          this.assignLabPeriods(daySchedule.periods, afterLunchSlot, subject, facultyId);
          faculty.dailyLoad[day] += 3;
          faculty.totalLoad += 3;
          return true;
        }
      }
    }

    return false; // Could not schedule lab
  }

  scheduleTheorySubject(timetable, subjectInfo, facultyWorkload) {
    const { subject, facultyId } = subjectInfo;
    const faculty = facultyWorkload[facultyId];

    // Shuffle days for random placement
    const shuffledDays = [...this.DAYS].sort(() => Math.random() - 0.5);

    for (const day of shuffledDays) {
      const daySchedule = timetable[day];
      const lunchPeriod = daySchedule.lunchPeriod;

      // Check if faculty has capacity
      if (faculty.dailyLoad[day] >= faculty.maxPerDay) {
        continue;
      }

      // Find available period
      const availablePeriod = this.findAvailablePeriod(daySchedule.periods, lunchPeriod);
      if (availablePeriod !== -1) {
        // Check for faculty conflicts across all days
        if (this.hasFacultyConflict(timetable, facultyId, day, availablePeriod)) {
          continue;
        }

        daySchedule.periods[availablePeriod] = {
          type: 'theory',
          subject: subject.name,
          subjectCode: subject.code,
          facultyId: facultyId,
          faculty: facultyId
        };

        faculty.dailyLoad[day] += 1;
        faculty.totalLoad += 1;
        return true;
      }
    }

    return false; // Could not schedule theory subject
  }

  findConsecutiveSlots(periods, startIndex, endIndex, count) {
    for (let i = startIndex; i <= endIndex - count; i++) {
      let consecutive = true;
      for (let j = i; j < i + count; j++) {
        if (periods[j] !== null) {
          consecutive = false;
          break;
        }
      }
      if (consecutive) {
        return i;
      }
    }
    return -1;
  }

  findAvailablePeriod(periods, lunchPeriod) {
    // Create array of available period indices (excluding lunch)
    const availablePeriods = [];
    for (let i = 0; i < periods.length; i++) {
      if (i !== lunchPeriod && periods[i] === null) {
        availablePeriods.push(i);
      }
    }

    // Return random available period
    if (availablePeriods.length > 0) {
      return availablePeriods[Math.floor(Math.random() * availablePeriods.length)];
    }
    return -1;
  }

  assignLabPeriods(periods, startIndex, subject, facultyId) {
    for (let i = startIndex; i < startIndex + 3; i++) {
      periods[i] = {
        type: 'lab',
        subject: subject.name,
        subjectCode: subject.code,
        facultyId: facultyId,
        faculty: facultyId,
        labSession: i - startIndex + 1 // 1, 2, 3
      };
    }
  }

  hasFacultyConflict(timetable, facultyId, currentDay, currentPeriod) {
    // Check if faculty is already assigned to this period on any other day
    for (const day of this.DAYS) {
      if (day === currentDay) continue;
      
      const period = timetable[day].periods[currentPeriod];
      if (period && period.facultyId === facultyId) {
        return true;
      }
    }
    return false;
  }

  convertToScheduleFormat(timetable, facultyMap, subjectMap) {
    const schedule = [];

    this.DAYS.forEach(day => {
      const daySchedule = {
        day,
        periods: []
      };

      timetable[day].periods.forEach((period, index) => {
        if (period) {
          let periodInfo = {
            periodNumber: index + 1,
            type: period.type,
            subject: period.subject || null,
            subjectCode: period.subjectCode || null,
            facultyId: period.facultyId || null,
            faculty: null
          };

          // Add faculty name if available
          if (period.facultyId && facultyMap.has(period.facultyId)) {
            periodInfo.faculty = facultyMap.get(period.facultyId).name;
          }

          // Add lab session info if applicable
          if (period.labSession) {
            periodInfo.labSession = period.labSession;
          }

          daySchedule.periods.push(periodInfo);
        } else {
          daySchedule.periods.push({
            periodNumber: index + 1,
            type: 'free',
            subject: null,
            subjectCode: null,
            facultyId: null,
            faculty: null
          });
        }
      });

      schedule.push(daySchedule);
    });

    return schedule;
  }

  generateMetadata(timetable, facultyWorkload) {
    const metadata = {
      generatedAt: new Date(),
      totalPeriods: 0,
      labPeriods: 0,
      theoryPeriods: 0,
      freePeriods: 0,
      lunchBreaks: {},
      facultyWorkload: {}
    };

    // Count periods and lunch breaks
    this.DAYS.forEach(day => {
      const dayData = timetable[day];
      metadata.lunchBreaks[day] = dayData.lunchPeriod + 1; // Convert to 1-indexed

      dayData.periods.forEach(period => {
        if (period) {
          metadata.totalPeriods++;
          if (period.type === 'lab') {
            metadata.labPeriods++;
          } else if (period.type === 'theory') {
            metadata.theoryPeriods++;
          }
        } else {
          metadata.freePeriods++;
        }
      });
    });

    // Faculty workload summary
    Object.entries(facultyWorkload).forEach(([facultyId, workload]) => {
      metadata.facultyWorkload[facultyId] = {
        totalLoad: workload.totalLoad,
        dailyLoad: workload.dailyLoad,
        maxPerDay: workload.maxPerDay
      };
    });

    return metadata;
  }
}

// Export the generator function
async function generateTimetable(allocation) {
  const generator = new TimetableGenerator();
  return await generator.generateTimetable(allocation);
}

module.exports = { generateTimetable };
