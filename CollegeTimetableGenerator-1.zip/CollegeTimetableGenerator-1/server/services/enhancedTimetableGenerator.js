const Faculty = require('../models/Faculty');
const Subject = require('../models/Subject');

class EnhancedTimetableGenerator {
  constructor() {
    this.DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    this.PERIODS_PER_DAY = 7;
    this.LUNCH_PERIOD_OPTIONS = [4, 5]; // Period 4 or 5 (1-indexed)
    this.MAX_RETRIES = 25;
    this.MAX_FACULTY_PERIODS_PER_DAY = 4; // Faculty max 3-4 lectures per day
    this.LAB_DURATION = 3; // Lab subjects require 3 consecutive periods
    this.PERIOD_TIMES = [
      '9:00-10:00',   // Period 1
      '10:00-11:00',  // Period 2  
      '11:15-12:15',  // Period 3
      '12:15-1:15',   // Period 4
      '1:15-2:15',    // Period 5
      '2:30-3:30',    // Period 6
      '3:30-4:30'     // Period 7
    ];
  }

  async generateTimetable(allocation) {
    try {
      console.log('Starting enhanced timetable generation for:', allocation.department, allocation.year, allocation.semester, allocation.section);
      
      // Validate allocation has faculty-subject mappings
      if (!allocation.facultySubjects || allocation.facultySubjects.length === 0) {
        return {
          success: false,
          error: 'No faculty-subject mappings found for this allocation'
        };
      }

      // Load faculty and subject data from database
      const { facultyMap, subjectMap } = await this.loadAllocationData(allocation);

      // Initialize timetable structure
      const timetable = this.initializeTimetable();

      // Attempt generation with enhanced constraints
      for (let attempt = 1; attempt <= this.MAX_RETRIES; attempt++) {
        console.log(`Generation attempt ${attempt}/${this.MAX_RETRIES}`);
        
        const result = await this.attemptEnhancedGeneration(timetable, allocation, facultyMap, subjectMap);
        
        if (result.success) {
          console.log('Timetable generation successful');
          return {
            success: true,
            schedule: result.schedule,
            metadata: result.metadata,
            constraints: this.getConstraintsSummary()
          };
        }

        // Clear timetable for next attempt
        this.clearTimetable(timetable);
        console.log(`Attempt ${attempt} failed: ${result.error}`);
      }

      return {
        success: false,
        error: 'Failed to generate valid timetable after multiple attempts. Consider adjusting constraints or subject allocations.',
        details: 'All lab, faculty, and timing constraints could not be satisfied simultaneously'
      };

    } catch (error) {
      console.error('Enhanced timetable generation error:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async loadAllocationData(allocation) {
    const facultyIds = [...new Set(allocation.facultySubjects.map(fs => fs.facultyId))];
    const subjectIds = [...new Set(allocation.facultySubjects.map(fs => fs.subjectId))];

    const faculties = await Faculty.findByIds(facultyIds);
    const subjects = await Subject.findByIds(subjectIds);

    const facultyMap = new Map();
    const subjectMap = new Map();

    faculties.forEach(faculty => {
      facultyMap.set(faculty._id.toString(), faculty);
    });

    subjects.forEach(subject => {
      subjectMap.set(subject._id.toString(), subject);
    });

    return { facultyMap, subjectMap };
  }

  initializeTimetable() {
    const timetable = {};
    
    this.DAYS.forEach(day => {
      timetable[day] = {
        periods: new Array(this.PERIODS_PER_DAY).fill(null),
        lunchPeriod: null
      };
    });

    return timetable;
  }

  clearTimetable(timetable) {
    this.DAYS.forEach(day => {
      timetable[day].periods = new Array(this.PERIODS_PER_DAY).fill(null);
      timetable[day].lunchPeriod = null;
    });
  }

  async attemptEnhancedGeneration(timetable, allocation, facultyMap, subjectMap) {
    try {
      // Step 1: Set random lunch breaks for each day (Period 4 or 5)
      this.setRandomLunchBreaks(timetable);

      // Step 2: Create subject instances with workload distribution
      const subjectInstances = this.createSubjectInstances(allocation, subjectMap);

      // Step 3: Prioritize subjects (Labs first, then theory)
      const prioritizedSubjects = this.prioritizeSubjectsEnhanced(subjectInstances);

      // Step 4: Initialize faculty workload tracking
      const facultyWorkload = this.initializeFacultyWorkload(facultyMap);

      // Step 5: Schedule lab subjects first (3 consecutive periods constraint)
      const labSubjects = prioritizedSubjects.filter(s => s.type === 'lab');
      for (const labSubject of labSubjects) {
        const scheduled = this.scheduleLabSubjectEnhanced(timetable, labSubject, facultyWorkload);
        if (!scheduled) {
          return {
            success: false,
            error: `Failed to schedule lab subject: ${labSubject.name}`
          };
        }
      }

      // Step 6: Schedule theory subjects randomly across the week
      const theorySubjects = prioritizedSubjects.filter(s => s.type !== 'lab');
      const shuffledTheory = this.shuffleArray([...theorySubjects]);
      
      for (const theorySubject of shuffledTheory) {
        const scheduled = this.scheduleTheorySubjectEnhanced(timetable, theorySubject, facultyWorkload);
        if (!scheduled) {
          return {
            success: false,
            error: `Failed to schedule theory subject: ${theorySubject.name}`
          };
        }
      }

      // Step 7: Validate all constraints
      const validation = this.validateAllConstraints(timetable, facultyWorkload, allocation);
      if (!validation.valid) {
        return {
          success: false,
          error: validation.error
        };
      }

      // Step 8: Final shuffle to distribute subjects randomly
      this.finalShuffleDistribution(timetable, facultyWorkload);

      // Step 9: Convert to output format
      const schedule = this.convertToEnhancedScheduleFormat(timetable, facultyMap, subjectMap);
      const metadata = this.generateComprehensiveMetadata(timetable, facultyWorkload, allocation);

      return {
        success: true,
        schedule,
        metadata
      };

    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }

  setRandomLunchBreaks(timetable) {
    this.DAYS.forEach(day => {
      // Randomly choose Period 4 or 5 for lunch (0-indexed: 3 or 4)
      const randomIndex = Math.floor(Math.random() * this.LUNCH_PERIOD_OPTIONS.length);
      const lunchPeriod = this.LUNCH_PERIOD_OPTIONS[randomIndex] - 1; // Convert to 0-indexed
      
      console.log(`Setting lunch for ${day} at period ${lunchPeriod + 1} (0-indexed: ${lunchPeriod})`);
      
      timetable[day].lunchPeriod = lunchPeriod;
      timetable[day].periods[lunchPeriod] = {
        type: 'lunch',
        subject: 'LUNCH BREAK',
        faculty: null,
        subjectType: 'lunch'
      };
    });
  }

  createSubjectInstances(allocation, subjectMap) {
    const instances = [];
    
    allocation.facultySubjects.forEach(fs => {
      const subject = subjectMap.get(fs.subjectId.toString());
      const periodsPerWeek = subject.periodsPerWeek || 3;
      
      // Create instances for each period per week
      for (let i = 0; i < periodsPerWeek; i++) {
        instances.push({
          subjectId: fs.subjectId,
          facultyId: fs.facultyId,
          name: subject.name,
          code: subject.code,
          type: subject.type || 'theory',
          credits: subject.credits,
          periodsPerWeek: subject.periodsPerWeek,
          instance: i + 1
        });
      }
    });

    return instances;
  }

  prioritizeSubjectsEnhanced(subjectInstances) {
    // Labs first (higher priority), then theory subjects
    return subjectInstances.sort((a, b) => {
      if (a.type === 'lab' && b.type !== 'lab') return -1;
      if (a.type !== 'lab' && b.type === 'lab') return 1;
      
      // Within same type, sort by periods per week (higher first)
      if (b.periodsPerWeek !== a.periodsPerWeek) {
        return b.periodsPerWeek - a.periodsPerWeek;
      }
      
      // Finally by name for consistency
      return a.name.localeCompare(b.name);
    });
  }

  initializeFacultyWorkload(facultyMap) {
    const workload = new Map();
    
    facultyMap.forEach((faculty, facultyId) => {
      workload.set(facultyId, {
        faculty: faculty,
        dailySchedule: {},
        totalPeriods: 0,
        subjectsAssigned: new Set()
      });
      
      // Initialize daily schedule
      this.DAYS.forEach(day => {
        workload.get(facultyId).dailySchedule[day] = new Array(this.PERIODS_PER_DAY).fill(false);
      });
    });

    return workload;
  }

  scheduleLabSubjectEnhanced(timetable, labSubject, facultyWorkload) {
    const facultyId = labSubject.facultyId.toString();
    const faculty = facultyWorkload.get(facultyId);
    
    if (!faculty) return false;

    console.log(`Attempting to schedule lab: ${labSubject.name}`);

    // Try to schedule lab in each day
    for (const day of this.DAYS) {
      const lunchPeriod = timetable[day].lunchPeriod;
      
      console.log(`Checking ${day} with lunch at period ${lunchPeriod + 1}`);
      
      // Find 3 consecutive periods avoiding lunch and following constraints
      const consecutiveSlots = this.findConsecutiveLabSlots(timetable[day].periods, lunchPeriod);
      
      console.log(`Found ${consecutiveSlots.length} potential lab slots for ${day}`);
      
      for (const startPeriod of consecutiveSlots) {
        // Check if faculty is available for all 3 periods
        let facultyAvailable = true;
        for (let p = startPeriod; p < startPeriod + this.LAB_DURATION; p++) {
          if (faculty.dailySchedule[day][p]) {
            facultyAvailable = false;
            break;
          }
        }

        if (facultyAvailable && this.canScheduleLabPeriods(faculty, day)) {
          console.log(`Scheduling lab ${labSubject.name} on ${day} from period ${startPeriod + 1} to ${startPeriod + this.LAB_DURATION}`);
          
          // Schedule the lab
          for (let p = startPeriod; p < startPeriod + this.LAB_DURATION; p++) {
            timetable[day].periods[p] = {
              type: 'subject',
              subject: labSubject.name,
              subjectCode: labSubject.code,
              faculty: faculty.faculty.name,
              facultyId: facultyId,
              subjectType: 'lab',
              labPart: p - startPeriod + 1
            };
            faculty.dailySchedule[day][p] = true;
          }
          
          faculty.totalPeriods += this.LAB_DURATION;
          faculty.subjectsAssigned.add(labSubject.name);
          return true;
        }
      }
    }

    console.log(`Failed to schedule lab: ${labSubject.name}`);
    return false;
  }

  findConsecutiveLabSlots(periods, lunchPeriod) {
    const slots = [];
    
    for (let start = 0; start <= periods.length - this.LAB_DURATION; start++) {
      let valid = true;
      
      // Check if this slot overlaps with lunch
      for (let p = start; p < start + this.LAB_DURATION; p++) {
        if (p === lunchPeriod || periods[p] !== null) {
          valid = false;
          break;
        }
      }
      
      // Critical constraint: Lab cannot be scheduled after lunch if fewer than 3 periods remain
      if (start > lunchPeriod) {
        const periodsAfterLunch = this.PERIODS_PER_DAY - (lunchPeriod + 1);
        const periodsFromStartToEnd = this.PERIODS_PER_DAY - start;
        
        console.log(`Checking lab slot starting at period ${start + 1}, lunch at ${lunchPeriod + 1}, periods after lunch: ${periodsAfterLunch}, periods from start to end: ${periodsFromStartToEnd}`);
        
        if (periodsAfterLunch < this.LAB_DURATION || periodsFromStartToEnd < this.LAB_DURATION) {
          console.log(`Rejecting lab slot at period ${start + 1} - insufficient periods after lunch`);
          valid = false;
        }
      }
      
      // Additional check: Lab should not span across lunch
      if (start < lunchPeriod && start + this.LAB_DURATION > lunchPeriod) {
        console.log(`Rejecting lab slot at period ${start + 1} - would span across lunch`);
        valid = false;
      }
      
      if (valid) {
        console.log(`Valid lab slot found: periods ${start + 1} to ${start + this.LAB_DURATION}`);
        slots.push(start);
      }
    }
    
    return slots;
  }

  canScheduleLabPeriods(faculty, day) {
    // Check if faculty doesn't exceed daily period limit
    const dailyPeriods = faculty.dailySchedule[day].filter(p => p).length;
    return dailyPeriods + this.LAB_DURATION <= this.MAX_FACULTY_PERIODS_PER_DAY;
  }

  scheduleTheorySubjectEnhanced(timetable, theorySubject, facultyWorkload) {
    const facultyId = theorySubject.facultyId.toString();
    const faculty = facultyWorkload.get(facultyId);
    
    if (!faculty) return false;

    // Create list of all available slots across all days
    const availableSlots = [];
    
    this.DAYS.forEach(day => {
      const lunchPeriod = timetable[day].lunchPeriod;
      
      for (let period = 0; period < this.PERIODS_PER_DAY; period++) {
        if (period !== lunchPeriod && 
            timetable[day].periods[period] === null && 
            !faculty.dailySchedule[day][period]) {
          
          // Check daily faculty limit
          const dailyPeriods = faculty.dailySchedule[day].filter(p => p).length;
          if (dailyPeriods < this.MAX_FACULTY_PERIODS_PER_DAY) {
            availableSlots.push({ day, period });
          }
        }
      }
    });

    // Shuffle slots for random distribution
    const shuffledSlots = this.shuffleArray(availableSlots);
    
    if (shuffledSlots.length > 0) {
      const slot = shuffledSlots[0];
      
      // Schedule the theory subject
      timetable[slot.day].periods[slot.period] = {
        type: 'subject',
        subject: theorySubject.name,
        subjectCode: theorySubject.code,
        faculty: faculty.faculty.name,
        facultyId: facultyId,
        subjectType: 'theory'
      };
      
      faculty.dailySchedule[slot.day][slot.period] = true;
      faculty.totalPeriods += 1;
      faculty.subjectsAssigned.add(theorySubject.name);
      return true;
    }

    return false;
  }

  validateAllConstraints(timetable, facultyWorkload, allocation) {
    // Constraint 1: No faculty double booking
    for (const [facultyId, faculty] of facultyWorkload) {
      for (const day of this.DAYS) {
        let periodsOnDay = 0;
        for (let period = 0; period < this.PERIODS_PER_DAY; period++) {
          if (faculty.dailySchedule[day][period]) {
            periodsOnDay++;
          }
        }
        if (periodsOnDay > this.MAX_FACULTY_PERIODS_PER_DAY) {
          return {
            valid: false,
            error: `Faculty ${faculty.faculty.name} exceeds daily period limit on ${day}`
          };
        }
      }
    }

    // Constraint 2: All lab subjects have 3 consecutive periods
    for (const day of this.DAYS) {
      const periods = timetable[day].periods;
      for (let p = 0; p < periods.length; p++) {
        if (periods[p] && periods[p].subjectType === 'lab' && periods[p].labPart === 1) {
          // Check if next 2 periods are consecutive parts of same lab
          if (p + 2 >= periods.length || 
              !periods[p + 1] || !periods[p + 2] ||
              periods[p + 1].subject !== periods[p].subject ||
              periods[p + 2].subject !== periods[p].subject) {
            return {
              valid: false,
              error: `Lab subject ${periods[p].subject} not scheduled in 3 consecutive periods on ${day}`
            };
          }
        }
      }
    }

    // Constraint 3: Verify total workload per subject
    const subjectWorkload = {};
    allocation.facultySubjects.forEach(fs => {
      const subjectId = fs.subjectId.toString();
      if (!subjectWorkload[subjectId]) {
        subjectWorkload[subjectId] = { scheduled: 0, required: 0 };
      }
    });

    // Count scheduled periods
    for (const day of this.DAYS) {
      for (const period of timetable[day].periods) {
        if (period && period.type === 'subject') {
          // For lab, count as 1 subject occurrence even though it takes 3 periods
          if (period.subjectType === 'lab' && period.labPart === 1) {
            const allocation_entry = allocation.facultySubjects.find(fs => 
              fs.facultyId.toString() === period.facultyId);
            if (allocation_entry) {
              const subjectId = allocation_entry.subjectId.toString();
              if (subjectWorkload[subjectId]) {
                subjectWorkload[subjectId].scheduled++;
              }
            }
          } else if (period.subjectType === 'theory') {
            const allocation_entry = allocation.facultySubjects.find(fs => 
              fs.facultyId.toString() === period.facultyId);
            if (allocation_entry) {
              const subjectId = allocation_entry.subjectId.toString();
              if (subjectWorkload[subjectId]) {
                subjectWorkload[subjectId].scheduled++;
              }
            }
          }
        }
      }
    }

    return { valid: true };
  }

  finalShuffleDistribution(timetable, facultyWorkload) {
    // Get all non-lunch, non-lab periods for potential shuffling
    const shuffleCandidates = [];
    
    for (const day of this.DAYS) {
      for (let period = 0; period < this.PERIODS_PER_DAY; period++) {
        const slot = timetable[day].periods[period];
        if (slot && slot.type === 'subject' && slot.subjectType === 'theory') {
          shuffleCandidates.push({
            day,
            period,
            slot: { ...slot }
          });
        }
      }
    }

    // Randomly shuffle some theory subjects to distribute across week
    if (shuffleCandidates.length > 2) {
      const shuffleCount = Math.min(3, Math.floor(shuffleCandidates.length / 3));
      
      for (let i = 0; i < shuffleCount; i++) {
        const idx1 = Math.floor(Math.random() * shuffleCandidates.length);
        const idx2 = Math.floor(Math.random() * shuffleCandidates.length);
        
        if (idx1 !== idx2) {
          const candidate1 = shuffleCandidates[idx1];
          const candidate2 = shuffleCandidates[idx2];
          
          // Swap the subjects if faculty constraints allow
          if (this.canSwapSubjects(candidate1, candidate2, facultyWorkload)) {
            const temp = { ...candidate1.slot };
            timetable[candidate1.day].periods[candidate1.period] = { ...candidate2.slot };
            timetable[candidate2.day].periods[candidate2.period] = temp;
          }
        }
      }
    }
  }

  canSwapSubjects(candidate1, candidate2, facultyWorkload) {
    const faculty1 = facultyWorkload.get(candidate1.slot.facultyId);
    const faculty2 = facultyWorkload.get(candidate2.slot.facultyId);
    
    if (!faculty1 || !faculty2) return false;
    
    // Check if faculties are available in swapped time slots
    const available1 = !faculty1.dailySchedule[candidate2.day][candidate2.period] || 
                     faculty1.dailySchedule[candidate2.day][candidate2.period] === 'self';
    const available2 = !faculty2.dailySchedule[candidate1.day][candidate1.period] || 
                     faculty2.dailySchedule[candidate1.day][candidate1.period] === 'self';
    
    return available1 && available2;
  }

  convertToEnhancedScheduleFormat(timetable, facultyMap, subjectMap) {
    const schedule = [];
    
    this.DAYS.forEach((day, dayIndex) => {
      const daySchedule = [];
      
      timetable[day].periods.forEach((period, periodIndex) => {
        if (period) {
          if (period.type === 'lunch') {
            daySchedule.push({
              type: 'lunch',
              subject: 'LUNCH BREAK',
              faculty: null,
              time: this.PERIOD_TIMES[periodIndex],
              period: periodIndex + 1
            });
          } else {
            const faculty = facultyMap.get(period.facultyId);
            daySchedule.push({
              type: 'subject',
              subject: period.subject,
              subjectCode: period.subjectCode,
              faculty: period.faculty,
              facultyName: faculty ? faculty.name : period.faculty,
              facultyId: faculty ? faculty.employeeId : null,
              subjectType: period.subjectType,
              time: this.PERIOD_TIMES[periodIndex],
              period: periodIndex + 1,
              ...(period.labPart && { labPart: period.labPart })
            });
          }
        } else {
          daySchedule.push(null);
        }
      });
      
      schedule.push(daySchedule);
    });
    
    return schedule;
  }

  generateComprehensiveMetadata(timetable, facultyWorkload, allocation) {
    let totalPeriods = 0;
    let theoryPeriods = 0;
    let labPeriods = 0;
    let freePeriods = 0;
    let lunchPeriods = 0;

    const facultyUtilization = {};
    const subjectDistribution = {};

    // Count periods and gather statistics
    this.DAYS.forEach(day => {
      timetable[day].periods.forEach(period => {
        totalPeriods++;
        
        if (period === null) {
          freePeriods++;
        } else if (period.type === 'lunch') {
          lunchPeriods++;
        } else if (period.subjectType === 'theory') {
          theoryPeriods++;
          
          // Track subject distribution
          if (!subjectDistribution[period.subject]) {
            subjectDistribution[period.subject] = 0;
          }
          subjectDistribution[period.subject]++;
          
          // Track faculty utilization
          if (!facultyUtilization[period.faculty]) {
            facultyUtilization[period.faculty] = 0;
          }
          facultyUtilization[period.faculty]++;
          
        } else if (period.subjectType === 'lab') {
          labPeriods++;
          
          // Count lab as 1 subject instance (3 periods = 1 lab session)
          if (period.labPart === 1) {
            if (!subjectDistribution[period.subject]) {
              subjectDistribution[period.subject] = 0;
            }
            subjectDistribution[period.subject]++;
            
            if (!facultyUtilization[period.faculty]) {
              facultyUtilization[period.faculty] = 0;
            }
            facultyUtilization[period.faculty] += 3; // Lab takes 3 periods
          }
        }
      });
    });

    return {
      totalPeriods: totalPeriods,
      theoryPeriods: theoryPeriods,
      labPeriods: labPeriods,
      freePeriods: freePeriods,
      lunchPeriods: lunchPeriods,
      facultyUtilization: facultyUtilization,
      subjectDistribution: subjectDistribution,
      generationRules: this.getConstraintsSummary(),
      weeklyStructure: {
        days: this.DAYS.length,
        periodsPerDay: this.PERIODS_PER_DAY,
        totalSlots: this.DAYS.length * this.PERIODS_PER_DAY
      }
    };
  }

  getConstraintsSummary() {
    return {
      labConstraints: {
        duration: '3 consecutive periods',
        placement: 'Before or after lunch, no split across lunch',
        availability: 'Morning or afternoon blocks'
      },
      facultyConstraints: {
        maxPeriodsPerDay: this.MAX_FACULTY_PERIODS_PER_DAY,
        noDoubleBooking: true,
        interdepartmentClashPrevention: true
      },
      allocationConstraints: {
        randomDistribution: true,
        workloadBalance: true,
        saturdayIncluded: true,
        perDepartmentSemesterSection: true
      },
      scheduleStructure: {
        days: 'Monday to Saturday',
        periods: '7 periods per day',
        lunchBreak: 'Period 4 or 5 (random per day)',
        timeSlots: this.PERIOD_TIMES
      }
    };
  }

  shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }
}

// Export the enhanced generator function
async function generateEnhancedTimetable(allocation) {
  const generator = new EnhancedTimetableGenerator();
  return await generator.generateTimetable(allocation);
}

module.exports = { generateEnhancedTimetable, EnhancedTimetableGenerator };