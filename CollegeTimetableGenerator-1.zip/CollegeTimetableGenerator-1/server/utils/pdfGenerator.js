const PDFDocument = require('pdfkit');

class TimetablePDFGenerator {
  constructor() {
    this.DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    this.PERIOD_TIMES = [
      '9:00-9:50',
      '9:50-10:40',
      '10:40-11:30',
      '11:30-12:20',
      '12:20-1:10',
      '1:10-2:00',
      '2:00-2:50'
    ];
  }

  async generateTimetablePDF(timetable, facultySchedule = null, isFacultyView = false) {
    return new Promise((resolve, reject) => {
      try {
        const doc = new PDFDocument({ 
          size: 'A4', 
          layout: 'landscape',
          margins: { top: 50, bottom: 50, left: 50, right: 50 }
        });

        const buffers = [];
        doc.on('data', buffers.push.bind(buffers));
        doc.on('end', () => {
          const pdfData = Buffer.concat(buffers);
          resolve(pdfData);
        });

        if (isFacultyView) {
          this.generateFacultyPDF(doc, facultySchedule);
        } else {
          this.generateClassTimetablePDF(doc, timetable);
        }

        doc.end();
      } catch (error) {
        reject(error);
      }
    });
  }

  generateClassTimetablePDF(doc, timetable) {
    // Enhanced Header with comprehensive information
    doc.fontSize(24).font('Helvetica-Bold').fillColor('#1f2937');
    doc.text('SmartScheduler - Class Timetable', 50, 50);
    
    // Class information section
    doc.fontSize(14).font('Helvetica');
    const classInfo = `${timetable.department} - Year ${timetable.year}, Semester ${timetable.semester}, Section ${timetable.section}`;
    doc.text(classInfo, 50, 80);
    
    // Generation date and metadata
    doc.fontSize(10).font('Helvetica');
    const generatedDate = new Date(timetable.createdAt || Date.now()).toLocaleDateString();
    doc.text(`Generated on: ${generatedDate}`, 50, 100);
    
    if (timetable.metadata) {
      const metadataText = `Total Periods: ${timetable.metadata.totalPeriods} | Theory: ${timetable.metadata.theoryPeriods} | Lab: ${timetable.metadata.labPeriods} | Free: ${timetable.metadata.freePeriods}`;
      doc.text(metadataText, 50, 115);
    }
    
    doc.fontSize(14).font('Helvetica');
    doc.text(`Department: ${timetable.department}`, 50, 80);
    doc.text(`Year: ${timetable.year} | Semester: ${timetable.semester} | Section: ${timetable.section}`, 50, 100);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 50, 120);

    // Start table at y = 160
    const startY = 160;
    const cellWidth = 110;
    const cellHeight = 60;
    const headerHeight = 30;

    // Draw table headers
    this.drawTableHeaders(doc, startY, cellWidth, headerHeight);

    // Draw timetable content
    this.drawTimetableContent(doc, timetable, startY + headerHeight, cellWidth, cellHeight);

    // Add legend
    this.addLegend(doc, startY + headerHeight + (this.DAYS.length * cellHeight) + 40);

    // Add metadata
    this.addMetadata(doc, timetable, startY + headerHeight + (this.DAYS.length * cellHeight) + 140);
  }

  generateFacultyPDF(doc, facultySchedule) {
    // Header for faculty timetable
    doc.fontSize(20).font('Helvetica-Bold');
    doc.text('SmartScheduler - Faculty Timetable', 50, 50);
    
    doc.fontSize(14).font('Helvetica');
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 50, 80);

    // Group schedule by day and faculty
    const groupedSchedule = this.groupFacultySchedule(facultySchedule);
    
    let currentY = 120;
    
    Object.entries(groupedSchedule).forEach(([facultyId, facultyData]) => {
      if (currentY > 500) { // Start new page if needed
        doc.addPage();
        currentY = 50;
      }

      // Faculty header
      doc.fontSize(16).font('Helvetica-Bold');
      doc.text(`Faculty: ${facultyData.facultyName}`, 50, currentY);
      currentY += 30;

      // Draw faculty timetable
      const tableHeight = this.drawFacultyTable(doc, facultyData.schedule, currentY);
      currentY += tableHeight + 40;
    });
  }

  drawTableHeaders(doc, startY, cellWidth, headerHeight) {
    const headers = ['Time / Day', ...this.DAYS];
    
    headers.forEach((header, index) => {
      const x = 50 + (index * cellWidth);
      
      // Draw header cell background
      doc.rect(x, startY, cellWidth, headerHeight)
         .fillAndStroke('#E8F4FD', '#2196F3');
      
      // Draw header text
      doc.fillColor('#000000')
         .fontSize(10)
         .font('Helvetica-Bold')
         .text(header, x + 5, startY + headerHeight/2 - 5, {
           width: cellWidth - 10,
           align: 'center'
         });
    });
  }

  drawTimetableContent(doc, timetable, startY, cellWidth, cellHeight) {
    // Draw time column and schedule
    for (let periodIndex = 0; periodIndex < 7; periodIndex++) {
      const y = startY + (periodIndex * cellHeight);
      
      // Time column
      doc.rect(50, y, cellWidth, cellHeight)
         .fillAndStroke('#F5F5F5', '#CCCCCC');
      
      doc.fillColor('#000000')
         .fontSize(9)
         .font('Helvetica-Bold')
         .text(this.PERIOD_TIMES[periodIndex], 55, y + cellHeight/2 - 5, {
           width: cellWidth - 10,
           align: 'center'
         });

      // Day columns
      this.DAYS.forEach((day, dayIndex) => {
        const x = 50 + ((dayIndex + 1) * cellWidth);
        const period = this.getPeriodForDay(timetable, day, periodIndex);
        
        // Determine cell color based on period type
        let bgColor = '#FFFFFF';
        let textColor = '#000000';
        
        if (period) {
          switch (period.type) {
            case 'lab':
              bgColor = '#FFE0E0';
              break;
            case 'theory':
              bgColor = '#E0F0FF';
              break;
            case 'lunch':
              bgColor = '#FFF0E0';
              break;
            default:
              bgColor = '#F0F0F0';
          }
        }

        // Draw cell
        doc.rect(x, y, cellWidth, cellHeight)
           .fillAndStroke(bgColor, '#CCCCCC');

        // Draw cell content
        if (period && period.type !== 'free') {
          doc.fillColor(textColor)
             .fontSize(8)
             .font('Helvetica-Bold');

          if (period.type === 'lunch') {
            doc.text('LUNCH', x + 5, y + 15, {
              width: cellWidth - 10,
              align: 'center'
            });
          } else {
            doc.text(period.subjectCode || period.subject, x + 5, y + 10, {
              width: cellWidth - 10,
              align: 'center'
            });
            
            doc.font('Helvetica')
               .fontSize(7)
               .text(period.faculty || '', x + 5, y + 25, {
                 width: cellWidth - 10,
                 align: 'center'
               });

            if (period.type === 'lab') {
              doc.text('(Lab)', x + 5, y + 40, {
                width: cellWidth - 10,
                align: 'center'
              });
            }
          }
        }
      });
    }
  }

  drawFacultyTable(doc, schedule, startY) {
    const cellWidth = 100;
    const cellHeight = 25;
    const headerHeight = 25;

    // Draw headers
    const headers = ['Time', ...this.DAYS];
    headers.forEach((header, index) => {
      const x = 50 + (index * cellWidth);
      doc.rect(x, startY, cellWidth, headerHeight)
         .fillAndStroke('#E8F4FD', '#2196F3');
      
      doc.fillColor('#000000')
         .fontSize(9)
         .font('Helvetica-Bold')
         .text(header, x + 5, startY + headerHeight/2 - 5, {
           width: cellWidth - 10,
           align: 'center'
         });
    });

    // Draw schedule rows
    for (let periodIndex = 0; periodIndex < 7; periodIndex++) {
      const y = startY + headerHeight + (periodIndex * cellHeight);
      
      // Time column
      doc.rect(50, y, cellWidth, cellHeight)
         .fillAndStroke('#F5F5F5', '#CCCCCC');
      
      doc.fillColor('#000000')
         .fontSize(8)
         .font('Helvetica')
         .text(this.PERIOD_TIMES[periodIndex], 55, y + cellHeight/2 - 5, {
           width: cellWidth - 10,
           align: 'center'
         });

      // Day columns
      this.DAYS.forEach((day, dayIndex) => {
        const x = 50 + ((dayIndex + 1) * cellWidth);
        const period = schedule[day] && schedule[day][periodIndex];
        
        doc.rect(x, y, cellWidth, cellHeight)
           .fillAndStroke('#FFFFFF', '#CCCCCC');

        if (period) {
          doc.fillColor('#000000')
             .fontSize(7)
             .font('Helvetica')
             .text(`${period.department} ${period.year}-${period.section}`, x + 2, y + 5, {
               width: cellWidth - 4,
               align: 'center'
             });
        }
      });
    }

    return headerHeight + (7 * cellHeight);
  }

  getPeriodForDay(timetable, day, periodIndex) {
    const daySchedule = timetable.schedule.find(d => d.day === day);
    if (daySchedule && daySchedule.periods[periodIndex]) {
      return daySchedule.periods[periodIndex];
    }
    return null;
  }

  groupFacultySchedule(facultySchedule) {
    const grouped = {};
    
    facultySchedule.forEach(item => {
      const facultyId = item.period.facultyId;
      
      if (!grouped[facultyId]) {
        grouped[facultyId] = {
          facultyName: item.period.faculty,
          schedule: {}
        };
        
        this.DAYS.forEach(day => {
          grouped[facultyId].schedule[day] = new Array(7).fill(null);
        });
      }
      
      const periodIndex = item.period.periodNumber - 1;
      grouped[facultyId].schedule[item.day][periodIndex] = {
        department: item.department,
        year: item.year,
        section: item.section,
        subject: item.period.subject
      };
    });
    
    return grouped;
  }

  addLegend(doc, startY) {
    doc.fontSize(12).font('Helvetica-Bold');
    doc.text('Legend:', 50, startY);
    
    const legendItems = [
      { color: '#E0F0FF', label: 'Theory Classes' },
      { color: '#FFE0E0', label: 'Lab Sessions' },
      { color: '#FFF0E0', label: 'Lunch Break' },
      { color: '#FFFFFF', label: 'Free Period' }
    ];
    
    legendItems.forEach((item, index) => {
      const x = 50 + (index * 150);
      const y = startY + 25;
      
      doc.rect(x, y, 15, 15)
         .fillAndStroke(item.color, '#CCCCCC');
      
      doc.fillColor('#000000')
         .fontSize(10)
         .font('Helvetica')
         .text(item.label, x + 20, y + 3);
    });
  }

  addMetadata(doc, timetable, startY) {
    if (timetable.metadata) {
      doc.fontSize(10).font('Helvetica-Bold');
      doc.text('Timetable Statistics:', 50, startY);
      
      const stats = [
        `Total Periods: ${timetable.metadata.totalPeriods}`,
        `Theory Periods: ${timetable.metadata.theoryPeriods}`,
        `Lab Periods: ${timetable.metadata.labPeriods}`,
        `Free Periods: ${timetable.metadata.freePeriods}`
      ];
      
      stats.forEach((stat, index) => {
        doc.fontSize(9).font('Helvetica');
        doc.text(stat, 50, startY + 20 + (index * 15));
      });
    }
  }
}

// Export the generator function
async function generateTimetablePDF(timetable, facultySchedule = null, isFacultyView = false) {
  const generator = new TimetablePDFGenerator();
  return await generator.generateTimetablePDF(timetable, facultySchedule, isFacultyView);
}

module.exports = { generateTimetablePDF };
