const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 8000;

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5000',
  credentials: true
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Test route to verify server is working
app.get('/api/health', (req, res) => {
  res.status(200).json({ 
    status: 'OK', 
    message: 'SmartScheduler API is running',
    timestamp: new Date().toISOString(),
    database: 'PostgreSQL with Drizzle ORM'
  });
});

// Faculty endpoints
app.get('/api/faculty', async (req, res) => {
  try {
    // Mock data for testing
    const facultyList = [
      {
        id: 1,
        employeeId: 'FAC001',
        name: 'Dr. John Smith',
        email: 'john.smith@college.edu',
        department: 'Computer Science',
        designation: 'Professor',
        isActive: true
      },
      {
        id: 2,
        employeeId: 'FAC002',
        name: 'Dr. Sarah Johnson',
        email: 'sarah.johnson@college.edu',
        department: 'Computer Science',
        designation: 'Associate Professor',
        isActive: true
      },
      {
        id: 3,
        employeeId: 'FAC003',
        name: 'Dr. Michael Brown',
        email: 'michael.brown@college.edu',
        department: 'Computer Science',
        designation: 'Assistant Professor',
        isActive: true
      }
    ];
    
    res.json({
      success: true,
      data: facultyList,
      count: facultyList.length
    });
  } catch (error) {
    console.error('Get faculty error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch faculty',
      error: error.message
    });
  }
});

// Subjects endpoints
app.get('/api/subjects', async (req, res) => {
  try {
    const { department, year, semester } = req.query;
    
    // Mock data for testing
    const subjectsList = [
      {
        id: 1,
        code: 'CS101',
        name: 'Programming Fundamentals',
        type: 'theory',
        credits: 3,
        department: 'Computer Science',
        year: 1,
        semester: 1,
        totalHours: 3
      },
      {
        id: 2,
        code: 'CS102',
        name: 'Programming Lab',
        type: 'lab',
        credits: 2,
        department: 'Computer Science',
        year: 1,
        semester: 1,
        totalHours: 3
      },
      {
        id: 3,
        code: 'CS201',
        name: 'Data Structures',
        type: 'theory',
        credits: 4,
        department: 'Computer Science',
        year: 2,
        semester: 1,
        totalHours: 4
      },
      {
        id: 4,
        code: 'CS202',
        name: 'Data Structures Lab',
        type: 'lab',
        credits: 2,
        department: 'Computer Science',
        year: 2,
        semester: 1,
        totalHours: 3
      },
      {
        id: 5,
        code: 'CS301',
        name: 'Database Management',
        type: 'theory',
        credits: 4,
        department: 'Computer Science',
        year: 3,
        semester: 1,
        totalHours: 4
      }
    ];
    
    // Filter subjects based on query parameters
    let filteredSubjects = subjectsList;
    if (department) {
      filteredSubjects = filteredSubjects.filter(s => s.department === department);
    }
    if (year) {
      filteredSubjects = filteredSubjects.filter(s => s.year === parseInt(year));
    }
    if (semester) {
      filteredSubjects = filteredSubjects.filter(s => s.semester === parseInt(semester));
    }
    
    res.json({
      success: true,
      data: filteredSubjects,
      count: filteredSubjects.length
    });
  } catch (error) {
    console.error('Get subjects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch subjects',
      error: error.message
    });
  }
});

// Allocations endpoints
app.get('/api/allocations', async (req, res) => {
  try {
    const { department, year, semester, section } = req.query;
    
    // Mock allocation data
    const allocationsList = [
      {
        id: 1,
        department: 'Computer Science',
        year: 1,
        semester: 1,
        section: 'A',
        facultySubjects: [
          { facultyId: 1, subjectId: 1, type: 'theory' },
          { facultyId: 2, subjectId: 2, type: 'lab' }
        ],
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 2,
        department: 'Computer Science',
        year: 2,
        semester: 1,
        section: 'A',
        facultySubjects: [
          { facultyId: 2, subjectId: 3, type: 'theory' },
          { facultyId: 3, subjectId: 4, type: 'lab' }
        ],
        isActive: true,
        createdAt: new Date().toISOString()
      }
    ];
    
    // Filter based on query parameters
    let filteredAllocations = allocationsList;
    if (department && year && semester && section) {
      filteredAllocations = allocationsList.filter(a => 
        a.department === department && 
        a.year === parseInt(year) && 
        a.semester === parseInt(semester) && 
        a.section === section
      );
    }
    
    res.json({
      success: true,
      data: filteredAllocations,
      count: filteredAllocations.length
    });
  } catch (error) {
    console.error('Get allocations error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch allocations',
      error: error.message
    });
  }
});

// Create allocation endpoint
app.post('/api/allocations', async (req, res) => {
  try {
    const { department, year, semester, section, facultySubjects } = req.body;
    
    // Validation
    if (!department || !year || !semester || !section || !facultySubjects) {
      return res.status(400).json({
        success: false,
        message: 'All fields are required'
      });
    }
    
    // Mock creation
    const newAllocation = {
      id: Date.now(), // Simple ID generation for testing
      department,
      year: parseInt(year),
      semester: parseInt(semester),
      section,
      facultySubjects,
      isActive: true,
      createdAt: new Date().toISOString()
    };
    
    res.status(201).json({
      success: true,
      message: 'Allocation created successfully',
      data: newAllocation
    });
  } catch (error) {
    console.error('Create allocation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create allocation',
      error: error.message
    });
  }
});

// Timetables endpoints
app.get('/api/timetables', async (req, res) => {
  try {
    const { department, year, semester, section } = req.query;
    
    // Mock timetable data
    const timetablesList = [
      {
        id: 1,
        department: 'Computer Science',
        year: 1,
        semester: 1,
        section: 'A',
        schedule: {
          Monday: {
            "09:00-10:00": {
              subject: "Programming Fundamentals",
              faculty: "Dr. John Smith",
              type: "theory",
              room: "101"
            },
            "10:00-11:00": {
              subject: "Programming Fundamentals",
              faculty: "Dr. John Smith",
              type: "theory",
              room: "101"
            },
            "11:00-12:00": {
              subject: "Programming Lab",
              faculty: "Dr. Sarah Johnson",
              type: "lab",
              room: "Lab1"
            },
            "12:00-13:00": {
              subject: "Programming Lab",
              faculty: "Dr. Sarah Johnson",
              type: "lab",
              room: "Lab1"
            },
            "13:00-14:00": { subject: "Lunch Break", type: "break" },
            "14:00-15:00": {
              subject: "Programming Lab",
              faculty: "Dr. Sarah Johnson",
              type: "lab",
              room: "Lab1"
            }
          },
          Tuesday: {
            "09:00-10:00": {
              subject: "Programming Fundamentals",
              faculty: "Dr. John Smith",
              type: "theory",
              room: "101"
            },
            "10:00-11:00": {
              subject: "Programming Fundamentals",
              faculty: "Dr. John Smith",
              type: "theory",
              room: "101"
            },
            "11:00-12:00": { subject: "Free Period", type: "free" },
            "12:00-13:00": { subject: "Lunch Break", type: "break" },
            "13:00-14:00": {
              subject: "Programming Lab",
              faculty: "Dr. Sarah Johnson",
              type: "lab",
              room: "Lab1"
            },
            "14:00-15:00": {
              subject: "Programming Lab",
              faculty: "Dr. Sarah Johnson",
              type: "lab",
              room: "Lab1"
            }
          }
        },
        metadata: {
          totalPeriods: 30,
          theoryPeriods: 20,
          labPeriods: 10,
          freePeriods: 0,
          conflicts: []
        },
        isActive: true,
        createdAt: new Date().toISOString()
      }
    ];
    
    // Filter based on query parameters
    let filteredTimetables = timetablesList;
    if (department && year && semester && section) {
      filteredTimetables = timetablesList.filter(t => 
        t.department === department && 
        t.year === parseInt(year) && 
        t.semester === parseInt(semester) && 
        t.section === section
      );
    }
    
    res.json({
      success: true,
      data: filteredTimetables,
      count: filteredTimetables.length
    });
  } catch (error) {
    console.error('Get timetables error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch timetables',
      error: error.message
    });
  }
});

// Generate timetable endpoint
app.post('/api/timetables/generate', async (req, res) => {
  try {
    const { department, year, semester, section } = req.body;
    
    // Validation
    if (!department || !year || !semester || !section) {
      return res.status(400).json({
        success: false,
        message: 'Department, year, semester, and section are required'
      });
    }
    
    // Mock timetable generation
    const generatedTimetable = {
      id: Date.now(),
      department,
      year: parseInt(year),
      semester: parseInt(semester),
      section,
      schedule: {
        Monday: {
          "09:00-10:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "10:00-11:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "11:00-12:00": {
            subject: "Programming Lab",
            faculty: "Dr. Sarah Johnson",
            type: "lab",
            room: "Lab1"
          },
          "12:00-13:00": {
            subject: "Programming Lab",
            faculty: "Dr. Sarah Johnson",
            type: "lab",
            room: "Lab1"
          },
          "13:00-14:00": { subject: "Lunch Break", type: "break" },
          "14:00-15:00": {
            subject: "Programming Lab",
            faculty: "Dr. Sarah Johnson",
            type: "lab",
            room: "Lab1"
          }
        },
        Tuesday: {
          "09:00-10:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "10:00-11:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "11:00-12:00": { subject: "Free Period", type: "free" },
          "12:00-13:00": { subject: "Lunch Break", type: "break" },
          "13:00-14:00": {
            subject: "Programming Lab",
            faculty: "Dr. Sarah Johnson",
            type: "lab",
            room: "Lab1"
          },
          "14:00-15:00": {
            subject: "Programming Lab",
            faculty: "Dr. Sarah Johnson",
            type: "lab",
            room: "Lab1"
          }
        },
        Wednesday: {
          "09:00-10:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "10:00-11:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "11:00-12:00": { subject: "Free Period", type: "free" },
          "12:00-13:00": { subject: "Lunch Break", type: "break" },
          "13:00-14:00": { subject: "Free Period", type: "free" },
          "14:00-15:00": { subject: "Free Period", type: "free" }
        },
        Thursday: {
          "09:00-10:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "10:00-11:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "11:00-12:00": { subject: "Free Period", type: "free" },
          "12:00-13:00": { subject: "Lunch Break", type: "break" },
          "13:00-14:00": { subject: "Free Period", type: "free" },
          "14:00-15:00": { subject: "Free Period", type: "free" }
        },
        Friday: {
          "09:00-10:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "10:00-11:00": {
            subject: "Programming Fundamentals",
            faculty: "Dr. John Smith",
            type: "theory",
            room: "101"
          },
          "11:00-12:00": { subject: "Free Period", type: "free" },
          "12:00-13:00": { subject: "Lunch Break", type: "break" },
          "13:00-14:00": { subject: "Free Period", type: "free" },
          "14:00-15:00": { subject: "Free Period", type: "free" }
        },
        Saturday: {
          "09:00-10:00": {
            subject: "Programming Lab",
            faculty: "Dr. Sarah Johnson",
            type: "lab",
            room: "Lab1"
          },
          "10:00-11:00": {
            subject: "Programming Lab",
            faculty: "Dr. Sarah Johnson",
            type: "lab",
            room: "Lab1"
          },
          "11:00-12:00": {
            subject: "Programming Lab",
            faculty: "Dr. Sarah Johnson",
            type: "lab",
            room: "Lab1"
          },
          "12:00-13:00": { subject: "Lunch Break", type: "break" },
          "13:00-14:00": { subject: "Free Period", type: "free" },
          "14:00-15:00": { subject: "Free Period", type: "free" }
        }
      },
      metadata: {
        totalPeriods: 36,
        theoryPeriods: 12,
        labPeriods: 9,
        freePeriods: 15,
        conflicts: [],
        generationTime: new Date().toISOString()
      },
      isActive: true,
      createdAt: new Date().toISOString()
    };
    
    res.status(201).json({
      success: true,
      message: 'Timetable generated successfully',
      data: generatedTimetable
    });
  } catch (error) {
    console.error('Generate timetable error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate timetable',
      error: error.message
    });
  }
});

// Auth endpoints (simplified)
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password, employeeId } = req.body;
    
    // Mock authentication
    if ((email === 'admin@college.edu' && password === 'admin123') || 
        (employeeId === 'FAC001' && password === 'faculty123')) {
      
      const user = email === 'admin@college.edu' ? 
        {
          id: 'admin001',
          email: 'admin@college.edu',
          name: 'System Administrator',
          role: 'admin'
        } : 
        {
          id: 'fac001',
          email: 'john.smith@college.edu',
          name: 'Dr. John Smith',
          role: 'faculty',
          employeeId: 'FAC001',
          department: 'Computer Science'
        };
      
      res.json({
        success: true,
        message: 'Login successful',
        data: {
          user,
          token: 'mock_jwt_token_' + Date.now()
        }
      });
    } else {
      res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed',
      error: error.message
    });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err.stack);
  res.status(500).json({ 
    success: false, 
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ 
    success: false, 
    message: 'API endpoint not found' 
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`SmartScheduler API server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log('Database: PostgreSQL with Drizzle ORM');
  console.log('Test login credentials:');
  console.log('  Admin: admin@college.edu / admin123');
  console.log('  Faculty: FAC001 / faculty123');
});

module.exports = app;