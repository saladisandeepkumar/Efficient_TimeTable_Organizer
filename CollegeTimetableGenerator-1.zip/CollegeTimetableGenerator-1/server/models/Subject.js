const { getDB } = require('../config/database');
const { ObjectId } = require('mongodb');

class Subject {
  constructor(subjectData) {
    this.code = subjectData.code;
    this.name = subjectData.name;
    this.department = subjectData.department;
    this.year = subjectData.year;
    this.semester = subjectData.semester;
    this.credits = subjectData.credits;
    this.type = subjectData.type; // 'theory', 'lab', 'practical'
    this.periodsPerWeek = subjectData.periodsPerWeek;
    this.isActive = subjectData.isActive !== undefined ? subjectData.isActive : true;
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }

  async save() {
    const db = getDB();
    const result = await db.collection('subjects').insertOne(this);
    return { ...this, _id: result.insertedId };
  }

  static async findByCode(code) {
    const db = getDB();
    return await db.collection('subjects').findOne({ code, isActive: true });
  }

  static async findById(id) {
    const db = getDB();
    return await db.collection('subjects').findOne({ 
      _id: new ObjectId(id), 
      isActive: true 
    });
  }

  static async findByDepartmentAndYear(department, year, semester) {
    const db = getDB();
    return await db.collection('subjects').find({ 
      department, 
      year, 
      semester,
      isActive: true 
    }).toArray();
  }

  static async getAll() {
    const db = getDB();
    return await db.collection('subjects').find({ isActive: true }).toArray();
  }

  static async updateById(id, updateData) {
    const db = getDB();
    updateData.updatedAt = new Date();
    
    return await db.collection('subjects').updateOne(
      { _id: new ObjectId(id) },
      { $set: updateData }
    );
  }

  static async deleteById(id) {
    const db = getDB();
    return await db.collection('subjects').updateOne(
      { _id: new ObjectId(id) },
      { $set: { isActive: false, updatedAt: new Date() } }
    );
  }

  static async findByIds(subjectIds) {
    const db = getDB();
    const objectIds = subjectIds.map(id => new ObjectId(id));
    return await db.collection('subjects').find({ 
      _id: { $in: objectIds },
      isActive: true 
    }).toArray();
  }

  static async findLabSubjects(department, year, semester) {
    const db = getDB();
    return await db.collection('subjects').find({ 
      department, 
      year, 
      semester,
      type: 'lab',
      isActive: true 
    }).toArray();
  }

  static async findTheorySubjects(department, year, semester) {
    const db = getDB();
    return await db.collection('subjects').find({ 
      department, 
      year, 
      semester,
      type: 'theory',
      isActive: true 
    }).toArray();
  }
}

module.exports = Subject;
