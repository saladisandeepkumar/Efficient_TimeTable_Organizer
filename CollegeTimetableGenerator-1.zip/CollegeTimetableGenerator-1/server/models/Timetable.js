const { getDB } = require('../config/database');
const { ObjectId } = require('mongodb');

class Timetable {
  constructor(timetableData) {
    this.department = timetableData.department;
    this.year = timetableData.year;
    this.semester = timetableData.semester;
    this.section = timetableData.section;
    this.schedule = timetableData.schedule; // Weekly schedule array
    this.generatedBy = timetableData.generatedBy;
    this.allocationId = timetableData.allocationId;
    this.metadata = timetableData.metadata || {};
    this.isActive = timetableData.isActive !== undefined ? timetableData.isActive : true;
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }

  async save() {
    const db = getDB();
    const result = await db.collection('timetables').insertOne(this);
    return { ...this, _id: result.insertedId };
  }

  static async findByClassDetails(department, year, semester, section) {
    const db = getDB();
    return await db.collection('timetables').findOne({ 
      department, 
      year, 
      semester, 
      section,
      isActive: true 
    });
  }

  static async findById(id) {
    const db = getDB();
    return await db.collection('timetables').findOne({ 
      _id: new ObjectId(id), 
      isActive: true 
    });
  }

  static async updateById(id, updateData) {
    const db = getDB();
    updateData.updatedAt = new Date();
    
    return await db.collection('timetables').updateOne(
      { _id: new ObjectId(id) },
      { $set: updateData }
    );
  }

  static async deleteById(id) {
    const db = getDB();
    return await db.collection('timetables').updateOne(
      { _id: new ObjectId(id) },
      { $set: { isActive: false, updatedAt: new Date() } }
    );
  }

  static async findByFaculty(facultyId) {
    const db = getDB();
    return await db.collection('timetables').find({
      'schedule.periods.facultyId': facultyId,
      isActive: true
    }).toArray();
  }

  static async getAllActive() {
    const db = getDB();
    return await db.collection('timetables').find({ isActive: true }).toArray();
  }

  static async replaceExisting(department, year, semester, section, newTimetableData) {
    const db = getDB();
    
    // First, deactivate existing timetable
    await db.collection('timetables').updateMany(
      { department, year, semester, section, isActive: true },
      { $set: { isActive: false, updatedAt: new Date() } }
    );
    
    // Then create new timetable
    const timetable = new Timetable(newTimetableData);
    return await timetable.save();
  }

  static async getFacultySchedule(facultyId, startDate, endDate) {
    const db = getDB();
    return await db.collection('timetables').aggregate([
      { $match: { isActive: true } },
      { $unwind: '$schedule' },
      { $unwind: '$schedule.periods' },
      { $match: { 'schedule.periods.facultyId': facultyId } },
      {
        $project: {
          department: 1,
          year: 1,
          semester: 1,
          section: 1,
          day: '$schedule.day',
          period: '$schedule.periods',
          createdAt: 1
        }
      }
    ]).toArray();
  }
}

module.exports = Timetable;
