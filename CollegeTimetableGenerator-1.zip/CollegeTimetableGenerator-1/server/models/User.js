const { getDB } = require('../config/database');
const { ObjectId } = require('mongodb');
const bcrypt = require('bcryptjs');

class User {
  constructor(userData) {
    this.email = userData.email;
    this.password = userData.password;
    this.role = userData.role; // 'admin' or 'faculty'
    this.employeeId = userData.employeeId; // For faculty
    this.name = userData.name;
    this.department = userData.department; // For faculty
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }

  async save() {
    const db = getDB();
    
    // Hash password before saving
    if (this.password) {
      const salt = await bcrypt.genSalt(10);
      this.password = await bcrypt.hash(this.password, salt);
    }
    
    const result = await db.collection('users').insertOne(this);
    return { ...this, _id: result.insertedId };
  }

  static async findByEmail(email) {
    const db = getDB();
    return await db.collection('users').findOne({ email });
  }

  static async findByEmployeeId(employeeId) {
    const db = getDB();
    return await db.collection('users').findOne({ employeeId });
  }

  static async findById(id) {
    const db = getDB();
    return await db.collection('users').findOne({ _id: new ObjectId(id) });
  }

  static async comparePassword(candidatePassword, hashedPassword) {
    return await bcrypt.compare(candidatePassword, hashedPassword);
  }

  static async updateById(id, updateData) {
    const db = getDB();
    updateData.updatedAt = new Date();
    
    if (updateData.password) {
      const salt = await bcrypt.genSalt(10);
      updateData.password = await bcrypt.hash(updateData.password, salt);
    }
    
    return await db.collection('users').updateOne(
      { _id: new ObjectId(id) },
      { $set: updateData }
    );
  }

  static async deleteById(id) {
    const db = getDB();
    return await db.collection('users').deleteOne({ _id: new ObjectId(id) });
  }

  static async getAllByRole(role) {
    const db = getDB();
    return await db.collection('users').find({ role }).toArray();
  }
}

module.exports = User;
