const { getDB } = require('../config/database');
const { ObjectId } = require('mongodb');

class Faculty {
  constructor(facultyData) {
    this.employeeId = facultyData.employeeId;
    this.name = facultyData.name;
    this.email = facultyData.email;
    this.department = facultyData.department;
    this.designation = facultyData.designation;
    this.maxLecturesPerDay = facultyData.maxLecturesPerDay || 4;
    this.isActive = facultyData.isActive !== undefined ? facultyData.isActive : true;
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }

  async save() {
    const db = getDB();
    const result = await db.collection('faculty').insertOne(this);
    return { ...this, _id: result.insertedId };
  }

  static async findByEmployeeId(employeeId) {
    const db = getDB();
    return await db.collection('faculty').findOne({ employeeId });
  }

  static async findById(id) {
    const db = getDB();
    return await db.collection('faculty').findOne({ _id: new ObjectId(id) });
  }

  static async findByDepartment(department) {
    const db = getDB();
    return await db.collection('faculty').find({ 
      department, 
      isActive: true 
    }).toArray();
  }

  static async getAll() {
    const db = getDB();
    return await db.collection('faculty').find({ isActive: true }).toArray();
  }

  static async updateById(id, updateData) {
    const db = getDB();
    updateData.updatedAt = new Date();
    
    return await db.collection('faculty').updateOne(
      { _id: new ObjectId(id) },
      { $set: updateData }
    );
  }

  static async deleteById(id) {
    const db = getDB();
    return await db.collection('faculty').updateOne(
      { _id: new ObjectId(id) },
      { $set: { isActive: false, updatedAt: new Date() } }
    );
  }

  static async findByIds(facultyIds) {
    const db = getDB();
    const objectIds = facultyIds.map(id => new ObjectId(id));
    return await db.collection('faculty').find({ 
      _id: { $in: objectIds },
      isActive: true 
    }).toArray();
  }

  static async searchByName(searchTerm) {
    const db = getDB();
    return await db.collection('faculty').find({
      name: { $regex: searchTerm, $options: 'i' },
      isActive: true
    }).toArray();
  }
}

module.exports = Faculty;
