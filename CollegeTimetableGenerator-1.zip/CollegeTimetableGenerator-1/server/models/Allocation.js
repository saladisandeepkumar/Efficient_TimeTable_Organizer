const { getDB } = require('../config/database');
const { ObjectId } = require('mongodb');

class Allocation {
  constructor(allocationData) {
    this.department = allocationData.department;
    this.year = allocationData.year;
    this.semester = allocationData.semester;
    this.section = allocationData.section;
    this.facultySubjects = allocationData.facultySubjects; // Array of { facultyId, subjectId }
    this.createdBy = allocationData.createdBy;
    this.isActive = allocationData.isActive !== undefined ? allocationData.isActive : true;
    this.createdAt = new Date();
    this.updatedAt = new Date();
  }

  async save() {
    const db = getDB();
    const result = await db.collection('allocations').insertOne(this);
    return { ...this, _id: result.insertedId };
  }

  static async findByClassDetails(department, year, semester, section) {
    const db = getDB();
    return await db.collection('allocations').findOne({ 
      department, 
      year, 
      semester, 
      section,
      isActive: true 
    });
  }

  static async findById(id) {
    const db = getDB();
    return await db.collection('allocations').findOne({ 
      _id: new ObjectId(id), 
      isActive: true 
    });
  }

  static async updateById(id, updateData) {
    const db = getDB();
    updateData.updatedAt = new Date();
    
    return await db.collection('allocations').updateOne(
      { _id: new ObjectId(id) },
      { $set: updateData }
    );
  }

  static async deleteById(id) {
    const db = getDB();
    return await db.collection('allocations').updateOne(
      { _id: new ObjectId(id) },
      { $set: { isActive: false, updatedAt: new Date() } }
    );
  }

  static async findByFaculty(facultyId) {
    const db = getDB();
    return await db.collection('allocations').find({
      'facultySubjects.facultyId': facultyId,
      isActive: true
    }).toArray();
  }

  static async getAllActive() {
    const db = getDB();
    return await db.collection('allocations').find({ isActive: true }).toArray();
  }

  static async addFacultySubject(id, facultyId, subjectId) {
    const db = getDB();
    return await db.collection('allocations').updateOne(
      { _id: new ObjectId(id) },
      { 
        $push: { 
          facultySubjects: { facultyId, subjectId }
        },
        $set: { updatedAt: new Date() }
      }
    );
  }

  static async removeFacultySubject(id, facultyId, subjectId) {
    const db = getDB();
    return await db.collection('allocations').updateOne(
      { _id: new ObjectId(id) },
      { 
        $pull: { 
          facultySubjects: { facultyId, subjectId }
        },
        $set: { updatedAt: new Date() }
      }
    );
  }
}

module.exports = Allocation;
