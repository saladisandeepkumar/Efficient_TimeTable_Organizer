import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
  unique,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// Session storage table for auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Faculty table
export const faculty = pgTable("faculty", {
  id: serial("id").primaryKey(),
  employeeId: varchar("employee_id").unique().notNull(),
  name: varchar("name").notNull(),
  email: varchar("email").unique(),
  department: varchar("department").notNull(),
  designation: varchar("designation").default("Assistant Professor"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Subjects table
export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  code: varchar("code").unique().notNull(),
  name: varchar("name").notNull(),
  type: varchar("type").notNull(), // 'theory', 'lab', 'practical'
  credits: integer("credits").default(3),
  department: varchar("department").notNull(),
  year: integer("year").notNull(),
  semester: integer("semester").notNull(),
  totalHours: integer("total_hours").default(3),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Allocations table
export const allocations = pgTable("allocations", {
  id: serial("id").primaryKey(),
  department: varchar("department").notNull(),
  year: integer("year").notNull(),
  semester: integer("semester").notNull(),
  section: varchar("section").notNull(),
  facultySubjects: jsonb("faculty_subjects").notNull(), // Array of {facultyId, subjectId, type}
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  unique().on(table.department, table.year, table.semester, table.section),
]);

// Timetables table
export const timetables = pgTable("timetables", {
  id: serial("id").primaryKey(),
  department: varchar("department").notNull(),
  year: integer("year").notNull(),
  semester: integer("semester").notNull(),
  section: varchar("section").notNull(),
  schedule: jsonb("schedule").notNull(), // Timetable data
  allocationId: integer("allocation_id").references(() => allocations.id),
  generatedBy: varchar("generated_by").references(() => users.id),
  metadata: jsonb("metadata"), // Generation stats, conflicts, etc.
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  unique().on(table.department, table.year, table.semester, table.section),
]);

// Relations
export const facultyRelations = relations(faculty, ({ many }) => ({
  timetables: many(timetables),
}));

export const subjectsRelations = relations(subjects, ({ many }) => ({
  allocations: many(allocations),
}));

export const allocationsRelations = relations(allocations, ({ many, one }) => ({
  timetables: many(timetables),
}));

export const timetablesRelations = relations(timetables, ({ one }) => ({
  allocation: one(allocations, {
    fields: [timetables.allocationId],
    references: [allocations.id],
  }),
  generatedByUser: one(users, {
    fields: [timetables.generatedBy],
    references: [users.id],
  }),
}));

// Type exports
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Faculty = typeof faculty.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type Allocation = typeof allocations.$inferSelect;
export type Timetable = typeof timetables.$inferSelect;
export type InsertFaculty = typeof faculty.$inferInsert;
export type InsertSubject = typeof subjects.$inferInsert;
export type InsertAllocation = typeof allocations.$inferInsert;
export type InsertTimetable = typeof timetables.$inferInsert;