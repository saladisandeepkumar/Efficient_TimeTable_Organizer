const { app, BrowserWindow, Menu } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let mainWindow;
let backendProcess;
let frontendProcess;

function createWindow() {
    // Create the browser window
    mainWindow = new BrowserWindow({
        width: 1400,
        height: 900,
        minWidth: 1200,
        minHeight: 800,
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
            enableRemoteModule: false,
            webSecurity: true
        },
        icon: path.join(__dirname, 'assets', 'icon.png'),
        title: 'SmartScheduler - College Timetable Generator',
        show: false // Don't show until ready
    });

    // Create application menu
    const template = [
        {
            label: 'File',
            submenu: [
                {
                    label: 'Refresh',
                    accelerator: 'CmdOrCtrl+R',
                    click() {
                        mainWindow.reload();
                    }
                },
                {
                    label: 'Developer Tools',
                    accelerator: 'F12',
                    click() {
                        mainWindow.webContents.toggleDevTools();
                    }
                },
                { type: 'separator' },
                {
                    label: 'Exit',
                    accelerator: process.platform === 'darwin' ? 'Cmd+Q' : 'Ctrl+Q',
                    click() {
                        app.quit();
                    }
                }
            ]
        },
        {
            label: 'View',
            submenu: [
                {
                    label: 'Zoom In',
                    accelerator: 'CmdOrCtrl+Plus',
                    click() {
                        mainWindow.webContents.setZoomLevel(mainWindow.webContents.getZoomLevel() + 1);
                    }
                },
                {
                    label: 'Zoom Out',
                    accelerator: 'CmdOrCtrl+-',
                    click() {
                        mainWindow.webContents.setZoomLevel(mainWindow.webContents.getZoomLevel() - 1);
                    }
                },
                {
                    label: 'Reset Zoom',
                    accelerator: 'CmdOrCtrl+0',
                    click() {
                        mainWindow.webContents.setZoomLevel(0);
                    }
                }
            ]
        },
        {
            label: 'Help',
            submenu: [
                {
                    label: 'About SmartScheduler',
                    click() {
                        const { dialog } = require('electron');
                        dialog.showMessageBox(mainWindow, {
                            type: 'info',
                            title: 'About SmartScheduler',
                            message: 'SmartScheduler v1.0',
                            detail: 'College Timetable Generator\nBuilt with Node.js, Express, and PostgreSQL'
                        });
                    }
                }
            ]
        }
    ];

    const menu = Menu.buildFromTemplate(template);
    Menu.setApplicationMenu(menu);

    // Start backend and frontend servers
    startServers().then(() => {
        // Load the app after servers are ready
        setTimeout(() => {
            mainWindow.loadURL('http://localhost:5000');
            mainWindow.show();
        }, 3000);
    });

    // Handle window closed
    mainWindow.on('closed', () => {
        mainWindow = null;
    });

    // Handle page loading
    mainWindow.webContents.on('did-finish-load', () => {
        mainWindow.webContents.insertCSS(`
            body {
                -webkit-user-select: text;
                user-select: text;
            }
        `);
    });
}

async function startServers() {
    return new Promise((resolve) => {
        console.log('Starting SmartScheduler servers...');
        
        // Start backend server
        backendProcess = spawn('node', ['server/index.js'], {
            cwd: __dirname,
            stdio: 'pipe'
        });

        backendProcess.stdout.on('data', (data) => {
            console.log(`Backend: ${data}`);
        });

        backendProcess.stderr.on('data', (data) => {
            console.error(`Backend Error: ${data}`);
        });

        // Start frontend server
        frontendProcess = spawn('node', ['client/simple-server.js'], {
            cwd: __dirname,
            stdio: 'pipe'
        });

        frontendProcess.stdout.on('data', (data) => {
            console.log(`Frontend: ${data}`);
        });

        frontendProcess.stderr.on('data', (data) => {
            console.error(`Frontend Error: ${data}`);
        });

        // Wait for servers to start
        setTimeout(() => {
            console.log('Servers started successfully');
            resolve();
        }, 2000);
    });
}

function stopServers() {
    if (backendProcess) {
        backendProcess.kill();
        backendProcess = null;
    }
    if (frontendProcess) {
        frontendProcess.kill();
        frontendProcess = null;
    }
}

// App event handlers
app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
    stopServers();
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
    }
});

app.on('before-quit', () => {
    stopServers();
});

// Handle protocol for development
if (process.defaultApp) {
    if (process.argv.length >= 2) {
        app.setAsDefaultProtocolClient('smartscheduler', process.execPath, [path.resolve(process.argv[1])]);
    }
} else {
    app.setAsDefaultProtocolClient('smartscheduler');
}