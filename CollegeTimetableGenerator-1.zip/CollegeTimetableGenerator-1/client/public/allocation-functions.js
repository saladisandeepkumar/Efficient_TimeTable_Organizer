// Allocation Management Functions
// This file contains all allocation-related functions

// Create allocation modal functions
function showCreateAllocationModal() {
    console.log('Opening allocation modal...');
    const modal = document.getElementById('createAllocationModal');
    if (modal) {
        modal.style.display = 'block';
        // Reset form
        const deptField = document.getElementById('allocationDepartment');
        const yearField = document.getElementById('allocationYear');
        const semesterField = document.getElementById('allocationSemester');
        const sectionField = document.getElementById('allocationSection');
        const rowsContainer = document.getElementById('facultySubjectRows');
        
        if (deptField) deptField.value = '';
        if (yearField) yearField.value = '';
        if (semesterField) semesterField.value = '';
        if (sectionField) sectionField.value = '';
        if (rowsContainer) rowsContainer.innerHTML = '';
        
        console.log('Modal opened successfully');
    } else {
        console.error('Modal element not found');
    }
}

function closeCreateAllocationModal() {
    const modal = document.getElementById('createAllocationModal');
    if (modal) {
        modal.style.display = 'none';
        
        // Reset form to create mode
        const form = modal.querySelector('form');
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) submitBtn.textContent = 'Create Allocation';
        
        // Remove edit field
        const editField = form.querySelector('input[name="editId"]');
        if (editField) {
            editField.remove();
        }
    }
}

function addFacultySubjectRow() {
    console.log('Adding faculty subject row...');
    const container = document.getElementById('facultySubjectRows');
    const department = document.getElementById('allocationDepartment').value;
    const year = document.getElementById('allocationYear').value;
    const semester = document.getElementById('allocationSemester').value;
    
    if (!container) {
        console.error('Container not found');
        return;
    }
    
    if (!department) {
        alert('Please select a department first');
        return;
    }
    
    // Get data from global app state - ensure we have the latest data
    if (!window.appData) {
        console.error('window.appData is not available');
        alert('Application data not loaded. Please refresh the page and try again.');
        return;
    }
    
    const facultyData = window.appData.faculty || [];
    const subjectData = window.appData.subjects || [];
    
    console.log('Department selected:', department);
    console.log('Year selected:', year);
    console.log('Semester selected:', semester);
    console.log('Total faculty available:', facultyData.length);
    console.log('Total subjects available:', subjectData.length);
    
    // Debug: Show sample data
    if (facultyData.length > 0) {
        console.log('Sample faculty:', facultyData[0]);
    }
    if (subjectData.length > 0) {
        console.log('Sample subject:', subjectData[0]);
    }
    
    // Filter faculty by department (case-insensitive)
    const filteredFaculty = facultyData.filter(f => {
        if (!f || !f.department) return false;
        const facultyDept = f.department.toString().trim().toLowerCase();
        const selectedDept = department.toString().trim().toLowerCase();
        const match = facultyDept === selectedDept;
        console.log(`Faculty ${f.name}: "${f.department}" matches "${department}" = ${match}`);
        return match;
    });
    
    // Filter subjects by department, year, and semester (case-insensitive)
    const filteredSubjects = subjectData.filter(s => {
        if (!s || !s.department) return false;
        const subjectDept = s.department.toString().trim().toLowerCase();
        const selectedDept = department.toString().trim().toLowerCase();
        const deptMatch = subjectDept === selectedDept;
        const yearMatch = !year || !s.year || s.year == year;
        const semesterMatch = !semester || !s.semester || s.semester == semester;
        console.log(`Subject ${s.name}: dept="${s.department}"(${deptMatch}), year=${s.year}(${yearMatch}), sem=${s.semester}(${semesterMatch})`);
        return deptMatch && yearMatch && semesterMatch;
    });
    
    console.log('Filtered faculty count:', filteredFaculty.length);
    console.log('Filtered subjects count:', filteredSubjects.length);
    
    // Show helpful message if no data found
    if (filteredFaculty.length === 0) {
        console.warn(`No faculty found for department: ${department}`);
        console.log('Available faculty departments:', facultyData.map(f => f.department).join(', '));
    }
    
    if (filteredSubjects.length === 0) {
        console.warn(`No subjects found for department: ${department}, year: ${year}, semester: ${semester}`);
        console.log('Available subjects:', subjectData.map(s => `${s.department} Y${s.year} S${s.semester}`).join(', '));
    }
    
    // Create options HTML
    const facultyOptions = filteredFaculty.length > 0 
        ? filteredFaculty.map(f => `<option value="${f.id}">${f.name} (${f.employeeId})</option>`).join('')
        : '<option value="" disabled>No faculty found for this department</option>';
        
    const subjectOptions = filteredSubjects.length > 0
        ? filteredSubjects.map(s => `<option value="${s.id}">${s.name} (${s.code})</option>`).join('')
        : '<option value="" disabled>No subjects found for this department/year/semester</option>';
    
    console.log('Faculty options HTML length:', facultyOptions.length);
    console.log('Subject options HTML length:', subjectOptions.length);
    
    const rowHTML = `
        <div class="faculty-subject-row" style="display: grid; grid-template-columns: 1fr 1fr auto; gap: 1rem; align-items: end; padding: 1rem; background: #f8fafc; border-radius: 6px; margin-bottom: 1rem;">
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Faculty (${filteredFaculty.length} available)</label>
                <select name="facultyId[]" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                    <option value="">Select Faculty</option>
                    ${facultyOptions}
                </select>
            </div>
            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Subject (${filteredSubjects.length} available)</label>
                <select name="subjectId[]" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                    <option value="">Select Subject</option>
                    ${subjectOptions}
                </select>
            </div>
            <button type="button" onclick="removeFacultySubjectRow(this)" style="padding: 8px 12px; background: #ef4444; color: white; border: none; border-radius: 6px; cursor: pointer;">
                Remove
            </button>
        </div>
    `;
    
    container.insertAdjacentHTML('beforeend', rowHTML);
    console.log('Row added successfully. Total rows:', container.children.length);
}

function removeFacultySubjectRow(button) {
    if (button && button.parentElement) {
        button.parentElement.remove();
    }
}

async function saveAllocation(event) {
    event.preventDefault();
    
    try {
        const form = event.target;
        const formData = new FormData(form);
        
        const department = formData.get('department');
        const year = parseInt(formData.get('year'));
        const semester = parseInt(formData.get('semester'));
        const section = formData.get('section');
        
        const facultyIds = formData.getAll('facultyId[]');
        const subjectIds = formData.getAll('subjectId[]');
        
        if (facultyIds.length === 0 || subjectIds.length === 0) {
            alert('Please add at least one faculty-subject assignment');
            return;
        }
        
        if (facultyIds.length !== subjectIds.length) {
            alert('Each faculty must be assigned to a subject');
            return;
        }
        
        const facultySubjects = facultyIds.map((facultyId, index) => ({
            facultyId: parseInt(facultyId),
            subjectId: parseInt(subjectIds[index])
        }));
        
        const allocationData = {
            department,
            year,
            semester,
            section,
            facultySubjects
        };
        
        // Check if this is an edit operation
        const editId = formData.get('editId');
        const isEdit = editId && editId !== '';
        
        console.log(isEdit ? 'Updating allocation:' : 'Creating allocation:', allocationData);
        console.log('Auth token from localStorage:', localStorage.getItem('authToken'));
        
        const API_BASE_URL = window.location.hostname.includes('replit') || window.location.hostname.includes('.app') ? 
            `${window.location.protocol}//${window.location.hostname.replace('-5000', '-8000')}` : 
            'http://localhost:8000';
        const authToken = localStorage.getItem('authToken');
        
        if (!authToken) {
            throw new Error('No authentication token found. Please log in again.');
        }
        
        const response = await fetch(`${API_BASE_URL}/api/allocations${isEdit ? '/' + editId : ''}`, {
            method: isEdit ? 'PUT' : 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(allocationData)
        });
        
        if (response.ok) {
            const result = await response.json();
            console.log('Allocation saved successfully:', result);
            
            // Close modal and refresh data
            closeCreateAllocationModal();
            
            // Reload data and re-render
            if (typeof loadData === 'function') {
                await loadData();
            } else if (window.loadData) {
                await window.loadData();
            }
            
            if (typeof renderApp === 'function') {
                renderApp();
            } else if (window.renderApp) {
                window.renderApp();
            }
            
            alert(isEdit ? 'Allocation updated successfully!' : 'Allocation created successfully!');
        } else {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to save allocation');
        }
        
    } catch (error) {
        console.error('Save allocation error:', error);
        alert('Failed to save allocation: ' + error.message);
    }
}

function editAllocation(allocationId) {
    console.log('Editing allocation:', allocationId);
    const allocations = window.appData ? window.appData.allocations : [];
    const allocation = allocations.find(a => a.id == allocationId);
    
    if (!allocation) {
        alert('Allocation not found');
        return;
    }
    
    // Open modal with existing data
    const modal = document.getElementById('createAllocationModal');
    if (modal) {
        modal.style.display = 'block';
        
        // Populate form with existing data
        const deptField = document.getElementById('allocationDepartment');
        const yearField = document.getElementById('allocationYear');
        const semesterField = document.getElementById('allocationSemester');
        const sectionField = document.getElementById('allocationSection');
        
        if (deptField) deptField.value = allocation.department;
        if (yearField) yearField.value = allocation.year;
        if (semesterField) semesterField.value = allocation.semester;
        if (sectionField) sectionField.value = allocation.section;
        
        // Clear existing rows
        const rowsContainer = document.getElementById('facultySubjectRows');
        if (rowsContainer) rowsContainer.innerHTML = '';
        
        // Add existing faculty-subject mappings
        if (allocation.facultySubjects && allocation.facultySubjects.length > 0) {
            allocation.facultySubjects.forEach(fs => {
                addFacultySubjectRow();
                const rows = document.getElementById('facultySubjectRows').children;
                const lastRow = rows[rows.length - 1];
                const facultySelect = lastRow.querySelector('select[name="facultyId[]"]');
                const subjectSelect = lastRow.querySelector('select[name="subjectId[]"]');
                
                // Set values after a brief delay to ensure options are loaded
                setTimeout(() => {
                    if (facultySelect) facultySelect.value = fs.facultyId;
                    if (subjectSelect) subjectSelect.value = fs.subjectId;
                }, 100);
            });
        }
        
        // Change submit button text and add hidden field for edit mode
        const form = modal.querySelector('form');
        if (form) {
            const submitBtn = form.querySelector('button[type="submit"]');
            if (submitBtn) submitBtn.textContent = 'Update Allocation';
            
            // Add hidden field to track edit mode
            let editField = form.querySelector('input[name="editId"]');
            if (!editField) {
                editField = document.createElement('input');
                editField.type = 'hidden';
                editField.name = 'editId';
                form.appendChild(editField);
            }
            editField.value = allocationId;
        }
    }
}

// Make functions globally available
window.showCreateAllocationModal = showCreateAllocationModal;
window.closeCreateAllocationModal = closeCreateAllocationModal;
window.addFacultySubjectRow = addFacultySubjectRow;
window.removeFacultySubjectRow = removeFacultySubjectRow;
window.saveAllocation = saveAllocation;
window.editAllocation = editAllocation;

console.log('Allocation functions loaded and registered globally');