// SmartScheduler Application
(function() {
    'use strict';
    
    // Declare allocation functions early to avoid "not defined" errors
    window.showCreateAllocationModal = function() { console.log('Function will be redefined after DOM load'); };
    window.closeCreateAllocationModal = function() { console.log('Function will be redefined after DOM load'); };
    window.addFacultySubjectRow = function() { console.log('Function will be redefined after DOM load'); };
    window.removeFacultySubjectRow = function() { console.log('Function will be redefined after DOM load'); };
    window.saveAllocation = function() { console.log('Function will be redefined after DOM load'); };
    window.editAllocation = function() { console.log('Function will be redefined after DOM load'); };
    
    // API Configuration
    const API_BASE_URL = window.location.hostname.includes('replit') || window.location.hostname.includes('.app') ? 
        `${window.location.protocol}//${window.location.hostname.replace('-5000', '-8000')}` : 
        'http://localhost:8000';

    // API service
    const api = {
        // Authentication
        login: async (credentials) => {
            const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(credentials)
            });
            return response.json();
        },
        
        // Faculty CRUD operations
        getFaculty: async () => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/faculty`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            return response.json();
        },
        
        createFaculty: async (facultyData) => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/faculty`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(facultyData)
            });
            return response.json();
        },
        
        updateFaculty: async (id, facultyData) => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/faculty/${id}`, {
                method: 'PUT',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(facultyData)
            });
            return response.json();
        },
        
        deleteFaculty: async (id) => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/faculty/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            return response.json();
        },
        
        // Subject CRUD operations
        getSubjects: async (params = {}) => {
            const token = localStorage.getItem('authToken');
            const query = new URLSearchParams(params).toString();
            const response = await fetch(`${API_BASE_URL}/api/subjects?${query}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            return response.json();
        },
        
        createSubject: async (subjectData) => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/subjects`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(subjectData)
            });
            return response.json();
        },
        
        updateSubject: async (id, subjectData) => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/subjects/${id}`, {
                method: 'PUT',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(subjectData)
            });
            return response.json();
        },
        
        deleteSubject: async (id) => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/subjects/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            return response.json();
        },
        
        // Allocation operations
        getAllocations: async (params = {}) => {
            const token = localStorage.getItem('authToken');
            const query = new URLSearchParams(params).toString();
            const response = await fetch(`${API_BASE_URL}/api/allocations?${query}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            return response.json();
        },
        
        createAllocation: async (allocationData) => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/allocations`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(allocationData)
            });
            return response.json();
        },
        
        // Timetable operations
        getTimetables: async (params = {}) => {
            const token = localStorage.getItem('authToken');
            const query = new URLSearchParams(params).toString();
            const response = await fetch(`${API_BASE_URL}/api/timetables?${query}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            return response.json();
        },
        
        generateTimetable: async (data) => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/timetables/generate`, {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(data)
            });
            return response.json();
        },

        exportTimetablePDF: async (timetableId) => {
            const token = localStorage.getItem('authToken');
            const response = await fetch(`${API_BASE_URL}/api/timetables/${timetableId}/export`, {
                method: 'GET',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            if (response.ok) {
                const blob = await response.blob();
                return { success: true, data: blob };
            } else {
                const errorData = await response.json();
                return { success: false, message: errorData.message || 'Export failed' };
            }
        }
    };

    // Auth utilities
    const auth = {
        currentUser: null,
        token: null,
        
        setAuth(user, token) {
            this.currentUser = user;
            this.token = token;
            localStorage.setItem('authToken', token);
            localStorage.setItem('currentUser', JSON.stringify(user));
        },
        
        clearAuth() {
            this.currentUser = null;
            this.token = null;
            localStorage.removeItem('authToken');
            localStorage.removeItem('currentUser');
        },
        
        isAuthenticated() {
            return !!this.currentUser;
        },
        
        isAdmin() {
            return this.currentUser?.role === 'admin';
        },
        
        loadFromStorage() {
            const token = localStorage.getItem('authToken');
            const userStr = localStorage.getItem('currentUser');
            if (token && userStr && userStr !== 'undefined') {
                try {
                    this.token = token;
                    this.currentUser = JSON.parse(userStr);
                } catch (error) {
                    console.error('Error parsing user data:', error);
                    this.clearAuth();
                }
            }
        }
    };

    // Application state
    let currentView = 'login';
    let appData = {
        faculty: [],
        subjects: [],
        allocations: [],
        timetables: [],
        facultyTimetables: []
    };
    
    // Make appData globally accessible for allocation functions
    window.appData = appData;
    
    // Toggle login fields based on selected login type
    function toggleLoginFields(loginType) {
        const emailField = document.getElementById('emailField');
        const employeeIdField = document.getElementById('employeeIdField');
        const emailInput = document.querySelector('input[name="email"]');
        const employeeIdInput = document.querySelector('input[name="employeeId"]');
        
        if (loginType === 'email') {
            emailField.style.display = 'block';
            employeeIdField.style.display = 'none';
            emailInput.required = true;
            employeeIdInput.required = false;
            employeeIdInput.value = '';
        } else {
            emailField.style.display = 'none';
            employeeIdField.style.display = 'block';
            emailInput.required = false;
            employeeIdInput.required = true;
            emailInput.value = '';
        }
    }

    // Initialize app
    function initApp() {
        console.log('Initializing SmartScheduler application...');
        
        try {
            auth.loadFromStorage();
            console.log('Authentication state loaded:', auth.isAuthenticated());
            
            if (auth.isAuthenticated()) {
                console.log('User authenticated, loading dashboard...');
                currentView = auth.isAdmin() ? 'admin' : 'faculty';
                loadData().then(() => {
                    console.log('Data loaded, rendering app...');
                    renderApp();
                }).catch(error => {
                    console.error('Error loading data:', error);
                    // Continue with rendering even if data loading fails
                    renderApp();
                });
            } else {
                console.log('User not authenticated, showing login...');
                currentView = 'login';
                renderApp();
            }
        } catch (error) {
            console.error('Error in initApp:', error);
            currentView = 'login';
            renderApp();
        }
    }

    // Load data from API
    async function loadData() {
        try {
            // Load data with individual error handling for each endpoint
            const results = await Promise.allSettled([
                api.getFaculty().catch(error => ({ success: false, data: [], error: error.message })),
                api.getSubjects().catch(error => ({ success: false, data: [], error: error.message })),
                api.getAllocations().catch(error => ({ success: false, data: [], error: error.message })),
                api.getTimetables().catch(error => ({ success: false, data: [], error: error.message }))
            ]);
            
            const [facultyResult, subjectsResult, allocationsResult, timetablesResult] = results.map(result => 
                result.status === 'fulfilled' ? result.value : { success: false, data: [] }
            );
            
            appData.faculty = facultyResult.success ? facultyResult.data : [];
            appData.subjects = subjectsResult.success ? subjectsResult.data : [];
            appData.allocations = allocationsResult.success ? allocationsResult.data : [];
            appData.timetables = timetablesResult.success ? timetablesResult.data : [];
            
            // Update global reference for allocation functions
            window.appData = appData;
            
            console.log('Data loaded successfully:', {
                faculty: appData.faculty.length,
                subjects: appData.subjects.length,
                allocations: appData.allocations.length,
                timetables: appData.timetables.length
            });
        } catch (error) {
            console.error('Error loading data:', error);
            // Ensure appData has empty arrays even if loading fails
            appData.faculty = appData.faculty || [];
            appData.subjects = appData.subjects || [];
            appData.allocations = appData.allocations || [];
            appData.timetables = appData.timetables || [];
        }
    }

    // Handle login
    async function handleLogin(event) {
        event.preventDefault();
        
        const formData = new FormData(event.target);
        const loginType = formData.get('loginType');
        const email = formData.get('email');
        const employeeId = formData.get('employeeId');
        const password = formData.get('password');
        
        try {
            let loginData = { password };
            
            if (loginType === 'email' && email) {
                loginData.email = email;
            } else if (loginType === 'employeeId' && employeeId) {
                loginData.employeeId = employeeId;
            } else {
                alert('Please provide valid login credentials');
                return;
            }
            
            const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(loginData)
            });
            
            const data = await response.json();
            
            if (data.success) {
                auth.setAuth(data.data.user, data.data.token);
                currentView = auth.isAdmin() ? 'admin' : 'faculty';
                
                await loadData();
                
                // Load faculty-specific data if faculty user
                if (data.data.user.role === 'faculty') {
                    await loadFacultyTimetables();
                }
                
                renderApp();
            } else {
                alert(data.message || 'Invalid credentials. Please check your login details.');
            }
        } catch (error) {
            console.error('Login error:', error);
            alert('Login failed. Please check your connection and try again.');
        }
    }

    // Handle logout
    function handleLogout() {
        auth.clearAuth();
        currentView = 'login';
        renderApp();
    }

    // Handle timetable generation
    async function handleGenerateTimetable(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        const data = Object.fromEntries(formData.entries());
        
        data.year = parseInt(data.year);
        data.semester = parseInt(data.semester);
        
        const button = event.target.querySelector('button[type="submit"]');
        const originalText = button.innerHTML;
        button.innerHTML = '<div style="display: inline-block; width: 16px; height: 16px; border: 2px solid #ffffff; border-radius: 50%; border-top-color: transparent; animation: spin 1s linear infinite;"></div> Generating...';
        button.disabled = true;
        
        try {
            const allocationsResult = await api.getAllocations({
                department: data.department,
                year: data.year,
                semester: data.semester,
                section: data.section
            });
            
            if (!allocationsResult.success || allocationsResult.data.length === 0) {
                alert('No faculty-subject allocation found for this class. Please create allocations first in the Allocations tab.');
                return;
            }
            
            const result = await api.generateTimetable(data);
            
            if (result.success) {
                await loadData();
                setActiveTab('timetables');
                alert('Timetable generated successfully! Check the Timetables tab to view it.');
            } else {
                alert('Timetable generation failed: ' + result.message);
            }
        } catch (error) {
            console.error('Error generating timetable:', error);
            alert('Failed to generate timetable. Please try again.');
        } finally {
            button.innerHTML = originalText;
            button.disabled = false;
        }
    }

    // Render application
    function renderApp() {
        const root = document.getElementById('root');
        
        if (!root) {
            console.error('Root element not found');
            return;
        }
        
        try {
            if (currentView === 'login') {
                root.innerHTML = renderLogin();
            } else if (currentView === 'admin') {
                root.innerHTML = renderAdminDashboard();
            } else if (currentView === 'faculty') {
                root.innerHTML = renderFacultyDashboard();
            }
            
            console.log('App rendered successfully, current view:', currentView);
            console.log('Root innerHTML length:', root.innerHTML.length);
            
            // Add visual debugging console output
            console.log('Rendering complete for view:', currentView);
            console.log('DOM element exists:', !!document.getElementById('root'));
            console.log('Content rendered successfully');
            attachEventListeners();
        } catch (error) {
            console.error('Error rendering app:', error);
            root.innerHTML = `
                <div style="min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #f8fafc;">
                    <div style="text-align: center; padding: 2rem; background: white; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                        <h2 style="color: #dc2626; margin-bottom: 1rem;">Rendering Error</h2>
                        <p style="color: #666; margin-bottom: 1rem;">Failed to render application view</p>
                        <button onclick="location.reload()" style="padding: 0.5rem 1rem; background: #2196F3; color: white; border: none; border-radius: 4px; cursor: pointer;">Reload Page</button>
                    </div>
                </div>
            `;
        }
    }

    // Render login page
    function renderLogin() {
        return `
            <div style="min-height: 100vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                <div style="background: white; padding: 2rem; border-radius: 12px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); width: 100%; max-width: 400px;">
                    <div style="text-align: center; margin-bottom: 2rem;">
                        <h1 style="font-size: 1.5rem; font-weight: 700; color: #1f2937; margin-bottom: 0.5rem;">SmartScheduler</h1>
                        <p style="color: #6b7280;">College Timetable Generator</p>
                    </div>
                    
                    <form onsubmit="handleLogin(event)">
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Login Type</label>
                            <select name="loginType" onchange="toggleLoginFields(this.value)" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 1rem; background: white;">
                                <option value="email">Admin Login (Email)</option>
                                <option value="employeeId">Faculty Login (Employee ID)</option>
                            </select>
                        </div>
                        
                        <div id="emailField" style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Email</label>
                            <input type="email" name="email" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 1rem;">
                        </div>
                        
                        <div id="employeeIdField" style="margin-bottom: 1rem; display: none;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Employee ID</label>
                            <input type="text" name="employeeId" placeholder="e.g., FAC001" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 1rem;">
                        </div>
                        
                        <div style="margin-bottom: 1.5rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Password</label>
                            <input type="password" name="password" required style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 1rem;">
                        </div>
                        
                        <button type="submit" style="width: 100%; padding: 12px; background: #2196F3; color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer;">Login</button>
                    </form>
                    
                    <div style="margin-top: 1.5rem; padding: 1rem; background: #f8fafc; border-radius: 8px; border: 1px solid #e5e7eb;">
                        <h3 style="font-size: 0.875rem; font-weight: 600; color: #374151; margin-bottom: 0.5rem;">Test Credentials:</h3>
                        <div style="font-size: 0.75rem; color: #6b7280; margin-bottom: 0.25rem;"><strong>Admin:</strong> admin@college.edu / admin123</div>
                        <div style="font-size: 0.75rem; color: #6b7280; margin-bottom: 0.25rem;"><strong>Faculty:</strong> FAC001 / faculty123</div>
                        <div style="font-size: 0.7rem; color: #9ca3af; margin-top: 0.5rem;">
                            Faculty can view their individual timetables when logged in with Employee ID
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Render admin dashboard
    function renderAdminDashboard() {
        return `
            <div style="min-height: 100vh; background: #f8fafc;">
                <header style="background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 1rem 2rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <h1 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Admin Dashboard</h1>
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <span style="color: #6b7280;">Welcome, ${auth.currentUser.name}</span>
                            <button onclick="handleLogout()" style="padding: 8px 16px; background: #ef4444; color: white; border: none; border-radius: 6px; cursor: pointer;">Logout</button>
                        </div>
                    </div>
                </header>
                
                <nav style="background: white; border-bottom: 1px solid #e5e7eb; padding: 0 2rem;">
                    <div style="display: flex; gap: 2rem;">
                        <button class="nav-tab" data-tab="overview" onclick="setActiveTab('overview')" style="padding: 1rem; border: none; background: none; color: #6b7280; border-bottom: 2px solid transparent; cursor: pointer; font-weight: 500;">Overview</button>
                        <button class="nav-tab" data-tab="faculty" onclick="setActiveTab('faculty')" style="padding: 1rem; border: none; background: none; color: #6b7280; border-bottom: 2px solid transparent; cursor: pointer; font-weight: 500;">Faculty</button>
                        <button class="nav-tab" data-tab="subjects" onclick="setActiveTab('subjects')" style="padding: 1rem; border: none; background: none; color: #6b7280; border-bottom: 2px solid transparent; cursor: pointer; font-weight: 500;">Subjects</button>
                        <button class="nav-tab" data-tab="allocations" onclick="setActiveTab('allocations')" style="padding: 1rem; border: none; background: none; color: #6b7280; border-bottom: 2px solid transparent; cursor: pointer; font-weight: 500;">Allocations</button>
                        <button class="nav-tab" data-tab="timetables" onclick="setActiveTab('timetables')" style="padding: 1rem; border: none; background: none; color: #6b7280; border-bottom: 2px solid transparent; cursor: pointer; font-weight: 500;">Timetables</button>
                    </div>
                </nav>
                
                <main style="padding: 2rem;">
                    <div id="tabContent">
                        ${renderOverviewTab()}
                    </div>
                </main>
            </div>
        `;
    }

    // Render faculty dashboard
    function renderFacultyDashboard() {
        return `
            <div style="min-height: 100vh; background: #f8fafc;">
                <header style="background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 1rem 2rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <h1 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Faculty Dashboard</h1>
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <span style="color: #6b7280;">Welcome, ${auth.currentUser.name}</span>
                            <button onclick="handleLogout()" style="padding: 8px 16px; background: #ef4444; color: white; border: none; border-radius: 6px; cursor: pointer;">Logout</button>
                        </div>
                    </div>
                </header>
                
                <nav style="background: white; border-bottom: 1px solid #e5e7eb; padding: 0 2rem;">
                    <div style="display: flex; gap: 2rem;">
                        <button class="faculty-nav-tab" data-tab="overview" onclick="setFacultyActiveTab('overview')" style="padding: 1rem; border: none; background: none; color: #2196F3; border-bottom: 2px solid #2196F3; cursor: pointer; font-weight: 500;">Overview</button>
                        <button class="faculty-nav-tab" data-tab="timetables" onclick="setFacultyActiveTab('timetables')" style="padding: 1rem; border: none; background: none; color: #6b7280; border-bottom: 2px solid transparent; cursor: pointer; font-weight: 500;">Timetables</button>
                    </div>
                </nav>
                
                <main style="padding: 2rem;">
                    <div id="facultyTabContent">
                        ${renderFacultyOverviewTab()}
                    </div>
                </main>
            </div>
        `;
    }

    // Faculty dashboard tab management
    function setFacultyActiveTab(tabName) {
        const navTabs = document.querySelectorAll('.faculty-nav-tab');
        navTabs.forEach(tab => {
            if (tab.dataset.tab === tabName) {
                tab.style.borderBottomColor = '#2196F3';
                tab.style.color = '#2196F3';
            } else {
                tab.style.borderBottomColor = 'transparent';
                tab.style.color = '#6b7280';
            }
        });
        
        const tabContent = document.getElementById('facultyTabContent');
        switch (tabName) {
            case 'overview':
                tabContent.innerHTML = renderFacultyOverviewTab();
                break;
            case 'timetables':
                tabContent.innerHTML = renderFacultyTimetablesTab();
                break;
        }
    }

    // Faculty dashboard overview tab
    function renderFacultyOverviewTab() {
        const stats = [
            { label: 'Total Faculty', value: appData.faculty.length, color: '#10b981' },
            { label: 'Total Subjects', value: appData.subjects.length, color: '#3b82f6' },
            { label: 'Active Allocations', value: appData.allocations.length, color: '#f59e0b' },
            { label: 'Generated Timetables', value: appData.timetables.length, color: '#8b5cf6' }
        ];
        
        return `
            <h2 style="font-size: 1.5rem; font-weight: 600; margin-bottom: 2rem; color: #1f2937;">Dashboard Overview</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                ${stats.map(stat => `
                    <div style="background: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-left: 4px solid ${stat.color};">
                        <div style="font-size: 2rem; font-weight: 700; color: ${stat.color};">${stat.value}</div>
                        <div style="color: #6b7280; font-size: 0.875rem;">${stat.label}</div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Faculty dashboard subjects tab
    function renderFacultySubjectsTab() {
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Subjects Management</h2>
                <div style="display: flex; gap: 1rem;">
                    <button onclick="showSubjectStatistics()" style="padding: 12px 24px; background: #f59e0b; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Statistics
                    </button>
                    <button onclick="exportSubjects()" style="padding: 12px 24px; background: #7c3aed; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Export CSV
                    </button>
                    <button onclick="showBulkUploadModal()" style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Bulk Upload
                    </button>
                    <button onclick="showAddSubjectModal()" style="padding: 12px 24px; background: #3b82f6; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Add Subject
                    </button>
                </div>
            </div>
            
            <!-- Filters Section -->
            <div style="background: white; border-radius: 8px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #1f2937;">Filter Subjects</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Department</label>
                        <select id="filterDepartment" onchange="filterSubjects()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Departments</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Electronics">Electronics</option>
                            <option value="Mechanical">Mechanical</option>
                            <option value="Civil">Civil</option>
                            <option value="Information Technology">Information Technology</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Year</label>
                        <select id="filterYear" onchange="filterSubjects()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Years</option>
                            <option value="1">Year 1</option>
                            <option value="2">Year 2</option>
                            <option value="3">Year 3</option>
                            <option value="4">Year 4</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Semester</label>
                        <select id="filterSemester" onchange="filterSubjects()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Semesters</option>
                            <option value="1">Semester 1</option>
                            <option value="2">Semester 2</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Type</label>
                        <select id="filterType" onchange="filterSubjects()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Types</option>
                            <option value="theory">Theory</option>
                            <option value="lab">Lab</option>
                            <option value="practical">Practical</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead style="background: #f9fafb;">
                        <tr>
                            ${['Code', 'Name', 'Type', 'Credits', 'Periods/Week', 'Department', 'Year', 'Semester', 'Actions'].map(header => 
                                `<th style="padding: 12px; text-align: left; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb;">${header}</th>`
                            ).join('')}
                        </tr>
                    </thead>
                    <tbody id="subjectsTableBody">
                        ${getFilteredSubjects().map(subject => `
                            <tr style="border-bottom: 1px solid #f3f4f6;">
                                <td style="padding: 12px; font-weight: 600; color: #1f2937;">${subject.code}</td>
                                <td style="padding: 12px; color: #1f2937;">${subject.name}</td>
                                <td style="padding: 12px;">
                                    <span style="padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; background: ${getTypeColor(subject.type).bg}; color: ${getTypeColor(subject.type).text};">
                                        ${subject.type}
                                    </span>
                                </td>
                                <td style="padding: 12px; color: #6b7280;">${subject.credits}</td>
                                <td style="padding: 12px; color: #6b7280;">${subject.periodsPerWeek || 'N/A'}</td>
                                <td style="padding: 12px; color: #6b7280;">${subject.department}</td>
                                <td style="padding: 12px; color: #6b7280;">${subject.year}</td>
                                <td style="padding: 12px; color: #6b7280;">${subject.semester}</td>
                                <td style="padding: 12px;">
                                    <div style="display: flex; gap: 0.5rem;">
                                        <button onclick="editSubject(${subject.id})" style="padding: 6px 12px; background: #f59e0b; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                                            Edit
                                        </button>
                                        <button onclick="deleteSubject(${subject.id})" style="padding: 6px 12px; background: #ef4444; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                ${getFilteredSubjects().length === 0 ? `
                    <div style="padding: 3rem; text-align: center; color: #6b7280;">
                        <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">No Subjects Found</h3>
                        <p>${appData.subjects.length === 0 ? 'Add subjects to start building your course catalog.' : 'No subjects match the current filters.'}</p>
                    </div>
                ` : ''}
            </div>
        `;
    }

    // Faculty dashboard faculty management tab
    function renderFacultyManagementTab() {
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Faculty Management</h2>
                <div style="display: flex; gap: 1rem;">
                    <button onclick="showFacultyStatistics()" style="padding: 12px 24px; background: #f59e0b; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Statistics
                    </button>
                    <button onclick="exportFaculty()" style="padding: 12px 24px; background: #7c3aed; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Export CSV
                    </button>
                    <button onclick="showFacultyBulkUpload()" style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Bulk Upload
                    </button>
                    <button onclick="showAddFacultyModal()" style="padding: 12px 24px; background: #3b82f6; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Add Faculty
                    </button>
                </div>
            </div>
            
            <!-- Filters Section -->
            <div style="background: white; border-radius: 8px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #1f2937;">Filter Faculty</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Department</label>
                        <select id="filterFacultyDepartment" onchange="filterFaculty()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Departments</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Electronics">Electronics</option>
                            <option value="Mechanical">Mechanical</option>
                            <option value="Civil">Civil</option>
                            <option value="Information Technology">Information Technology</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Designation</label>
                        <select id="filterFacultyDesignation" onchange="filterFaculty()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Designations</option>
                            <option value="Professor">Professor</option>
                            <option value="Associate Professor">Associate Professor</option>
                            <option value="Assistant Professor">Assistant Professor</option>
                            <option value="Lecturer">Lecturer</option>
                            <option value="HOD">HOD</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Search by Name</label>
                        <input type="text" id="filterFacultyName" onkeyup="filterFaculty()" placeholder="Enter faculty name..." 
                               style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Search by ID</label>
                        <input type="text" id="filterFacultyId" onkeyup="filterFaculty()" placeholder="Enter employee ID..." 
                               style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                    </div>
                </div>
            </div>
            
            <div style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead style="background: #f9fafb;">
                        <tr>
                            ${['Employee ID', 'Name', 'Email', 'Department', 'Designation', 'Phone', 'Actions'].map(header => 
                                `<th style="padding: 12px; text-align: left; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb;">${header}</th>`
                            ).join('')}
                        </tr>
                    </thead>
                    <tbody id="facultyTableBody">
                        ${getFilteredFaculty().map(member => `
                            <tr style="border-bottom: 1px solid #f3f4f6;">
                                <td style="padding: 12px; color: #1f2937; font-weight: 600;">${member.employeeId}</td>
                                <td style="padding: 12px; color: #1f2937;">${member.name}</td>
                                <td style="padding: 12px; color: #6b7280;">${member.email}</td>
                                <td style="padding: 12px; color: #6b7280;">${member.department}</td>
                                <td style="padding: 12px;">
                                    <span style="padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; background: ${getDesignationColor(member.designation).bg}; color: ${getDesignationColor(member.designation).text};">
                                        ${member.designation || 'Professor'}
                                    </span>
                                </td>
                                <td style="padding: 12px; color: #6b7280;">${member.phone || 'N/A'}</td>
                                <td style="padding: 12px;">
                                    <div style="display: flex; gap: 0.5rem;">
                                        <button onclick="editFaculty(${member.id})" style="padding: 6px 12px; background: #f59e0b; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                                            Edit
                                        </button>
                                        <button onclick="deleteFaculty(${member.id})" style="padding: 6px 12px; background: #ef4444; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                ${getFilteredFaculty().length === 0 ? `
                    <div style="padding: 3rem; text-align: center; color: #6b7280;">
                        <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">No Faculty Found</h3>
                        <p>${appData.faculty.length === 0 ? 'Add faculty members to start managing your institution\'s staff.' : 'No faculty match the current filters.'}</p>
                    </div>
                ` : ''}
            </div>
        `;
    }

    // Faculty dashboard timetables tab - show individual faculty timetable
    function renderFacultyTimetablesTab() {
        const currentUser = auth.currentUser;
        const facultyTimetables = appData.facultyTimetables || [];
        
        return `
            <div style="margin-bottom: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                    <div>
                        <h2 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">My Teaching Schedule</h2>
                        <p style="color: #6b7280; margin-top: 0.25rem;">View your assigned teaching periods and subjects</p>
                    </div>
                    <div style="display: flex; gap: 1rem;">
                        <button onclick="exportFacultyTimetable()" style="padding: 8px 16px; background: #10b981; color: white; border: none; border-radius: 6px; font-weight: 500; cursor: pointer;">
                            <i class="fas fa-download" style="margin-right: 0.5rem;"></i>Export PDF
                        </button>
                        <button onclick="refreshFacultyTimetable()" style="padding: 8px 16px; background: #6b7280; color: white; border: none; border-radius: 6px; font-weight: 500; cursor: pointer;">
                            <i class="fas fa-sync-alt" style="margin-right: 0.5rem;"></i>Refresh
                        </button>
                    </div>
                </div>
                
                ${renderFacultyScheduleTable()}
            </div>
        `;
    }
    
    // Render faculty-specific schedule table
    function renderFacultyScheduleTable() {
        const currentUser = auth.currentUser;
        const facultyTimetables = appData.facultyTimetables || [];
        
        if (!facultyTimetables || facultyTimetables.length === 0) {
            return `
                <div style="text-align: center; padding: 4rem 2rem; background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <i class="fas fa-calendar-times" style="font-size: 4rem; color: #d1d5db; margin-bottom: 1.5rem;"></i>
                    <h3 style="font-size: 1.25rem; font-weight: 600; color: #374151; margin-bottom: 0.75rem;">No Schedule Available</h3>
                    <p style="color: #6b7280; max-width: 400px; margin: 0 auto;">
                        You don't have any teaching assignments yet. Your schedule will appear here once timetables are generated and you are assigned to subjects.
                    </p>
                    <button onclick="refreshFacultyTimetable()" style="margin-top: 1.5rem; padding: 10px 20px; background: #2196F3; color: white; border: none; border-radius: 6px; cursor: pointer;">
                        Check for Updates
                    </button>
                </div>
            `;
        }
        
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const periods = ['9:00-9:50', '9:50-10:40', '10:40-11:30', '11:30-12:20', '12:20-1:10', '1:10-2:00', '2:00-2:50'];
        
        // Create schedule grid
        const scheduleGrid = {};
        facultyTimetables.forEach(entry => {
            if (!scheduleGrid[entry.day]) scheduleGrid[entry.day] = {};
            scheduleGrid[entry.day][entry.period] = entry;
        });
        
        return `
            <div style="background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden;">
                <div style="padding: 1.5rem; border-bottom: 1px solid #e5e7eb;">
                    <div style="display: flex; justify-content: between; align-items: center;">
                        <h3 style="font-size: 1.125rem; font-weight: 600; color: #1f2937;">Weekly Schedule</h3>
                        <div style="display: flex; gap: 1rem; font-size: 0.875rem; color: #6b7280;">
                            <span><i class="fas fa-chalkboard-teacher" style="margin-right: 0.25rem;"></i>Total Classes: ${facultyTimetables.length}</span>
                            <span><i class="fas fa-clock" style="margin-right: 0.25rem;"></i>Weekly Hours: ${facultyTimetables.length * 0.83}</span>
                        </div>
                    </div>
                </div>
                
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: #f8fafc;">
                                <th style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; text-align: left; min-width: 100px;">Day / Period</th>
                                ${periods.map((period, index) => `
                                    <th style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; text-align: center; min-width: 120px;">
                                        <div>Period ${index + 1}</div>
                                        <div style="font-size: 0.75rem; font-weight: 400; color: #6b7280;">${period}</div>
                                    </th>
                                `).join('')}
                            </tr>
                        </thead>
                        <tbody>
                            ${days.map(day => `
                                <tr>
                                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; background: #f8fafc;">
                                        ${day}
                                    </td>
                                    ${periods.map((period, periodIndex) => {
                                        const entry = scheduleGrid[day] && scheduleGrid[day][periodIndex];
                                        if (entry) {
                                            const bgColor = entry.subjectType === 'lab' ? '#dcfce7' : 
                                                           entry.subjectType === 'practical' ? '#fef3c7' : '#dbeafe';
                                            const textColor = entry.subjectType === 'lab' ? '#15803d' : 
                                                             entry.subjectType === 'practical' ? '#d97706' : '#1d4ed8';
                                            
                                            return `
                                                <td style="padding: 8px; border: 1px solid #e5e7eb; background: ${bgColor}; color: ${textColor};">
                                                    <div style="font-weight: 600; font-size: 0.875rem; margin-bottom: 2px;">
                                                        ${entry.subjectName || 'Unknown Subject'}
                                                    </div>
                                                    <div style="font-size: 0.75rem; opacity: 0.8;">
                                                        ${entry.className || 'Unknown Class'}
                                                    </div>
                                                    <div style="font-size: 0.7rem; opacity: 0.7; margin-top: 2px;">
                                                        ${entry.subjectCode || ''}
                                                    </div>
                                                </td>
                                            `;
                                        } else {
                                            return `
                                                <td style="padding: 8px; border: 1px solid #e5e7eb; background: #f9fafb; color: #9ca3af; text-align: center;">
                                                    <div style="font-size: 0.75rem;">Free</div>
                                                </td>
                                            `;
                                        }
                                    }).join('')}
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
                
                <div style="padding: 1rem; background: #f8fafc; border-top: 1px solid #e5e7eb;">
                    <div style="display: flex; gap: 2rem; font-size: 0.875rem;">
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <div style="width: 16px; height: 16px; background: #dbeafe; border-radius: 3px;"></div>
                            <span>Theory Classes</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <div style="width: 16px; height: 16px; background: #dcfce7; border-radius: 3px;"></div>
                            <span>Lab Sessions</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <div style="width: 16px; height: 16px; background: #fef3c7; border-radius: 3px;"></div>
                            <span>Practical Classes</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <div style="width: 16px; height: 16px; background: #f9fafb; border-radius: 3px;"></div>
                            <span>Free Periods</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Render overview tab
    function renderOverviewTab() {
        const stats = [
            { label: 'Total Faculty', value: appData.faculty.length, color: '#10b981' },
            { label: 'Total Subjects', value: appData.subjects.length, color: '#3b82f6' },
            { label: 'Active Allocations', value: appData.allocations.length, color: '#f59e0b' },
            { label: 'Generated Timetables', value: appData.timetables.length, color: '#8b5cf6' }
        ];
        
        return `
            <h2 style="font-size: 1.5rem; font-weight: 600; margin-bottom: 2rem; color: #1f2937;">Dashboard Overview</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                ${stats.map(stat => `
                    <div style="background: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-left: 4px solid ${stat.color};">
                        <div style="font-size: 2rem; font-weight: 700; color: ${stat.color};">${stat.value}</div>
                        <div style="color: #6b7280; font-size: 0.875rem;">${stat.label}</div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    // Faculty management functions
    function showAddFacultyModal(facultyData = null) {
        const isEditing = Boolean(facultyData);
        const modalTitle = isEditing ? 'Edit Faculty' : 'Add Faculty';
        
        const modalHTML = `
            <div id="facultyModal" class="modal" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center;">
                <div style="background: white; border-radius: 12px; padding: 2rem; width: 90%; max-width: 500px; max-height: 90vh; overflow-y: auto;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                        <h3 style="font-size: 1.25rem; font-weight: 600; color: #1f2937;">${modalTitle}</h3>
                        <button onclick="closeFacultyModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280;">×</button>
                    </div>
                    
                    <form onsubmit="saveFaculty(event)">
                        ${isEditing ? `<input type="hidden" name="id" value="${facultyData.id}">` : ''}
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Employee ID *</label>
                            <input type="text" name="employeeId" required value="${facultyData?.employeeId || ''}" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                        </div>
                        
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Full Name *</label>
                            <input type="text" name="name" required value="${facultyData?.name || ''}" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                        </div>
                        
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Email *</label>
                            <input type="email" name="email" required value="${facultyData?.email || ''}" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                        </div>
                        
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Department *</label>
                            <select name="department" required style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                                <option value="">Select Department</option>
                                <option value="Computer Science" ${facultyData?.department === 'Computer Science' ? 'selected' : ''}>Computer Science</option>
                                <option value="Electronics" ${facultyData?.department === 'Electronics' ? 'selected' : ''}>Electronics</option>
                                <option value="Mechanical" ${facultyData?.department === 'Mechanical' ? 'selected' : ''}>Mechanical</option>
                                <option value="Civil" ${facultyData?.department === 'Civil' ? 'selected' : ''}>Civil</option>
                                <option value="Information Technology" ${facultyData?.department === 'Information Technology' ? 'selected' : ''}>Information Technology</option>
                            </select>
                        </div>
                        
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Designation</label>
                            <select name="designation" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                                <option value="Assistant Professor" ${(facultyData?.designation || 'Assistant Professor') === 'Assistant Professor' ? 'selected' : ''}>Assistant Professor</option>
                                <option value="Associate Professor" ${facultyData?.designation === 'Associate Professor' ? 'selected' : ''}>Associate Professor</option>
                                <option value="Professor" ${facultyData?.designation === 'Professor' ? 'selected' : ''}>Professor</option>
                                <option value="Lecturer" ${facultyData?.designation === 'Lecturer' ? 'selected' : ''}>Lecturer</option>
                                <option value="HOD" ${facultyData?.designation === 'HOD' ? 'selected' : ''}>HOD</option>
                            </select>
                        </div>
                        
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Phone Number</label>
                            <input type="tel" name="phone" value="${facultyData?.phone || ''}" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                        </div>
                        
                        <div style="margin-bottom: 1.5rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Max Lectures Per Day</label>
                            <input type="number" name="maxLecturesPerDay" min="1" max="8" value="${facultyData?.maxLecturesPerDay || 4}" style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                        </div>
                        
                        <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                            <button type="button" onclick="closeFacultyModal()" style="padding: 12px 24px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer;">Cancel</button>
                            <button type="submit" style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer;">${isEditing ? 'Update Faculty' : 'Save Faculty'}</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }

    function closeFacultyModal() {
        const modal = document.getElementById('facultyModal');
        if (modal) modal.remove();
    }

    async function saveFaculty(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        const facultyData = Object.fromEntries(formData.entries());
        
        const isEditing = Boolean(facultyData.id);
        
        try {
            let result;
            if (isEditing) {
                const id = facultyData.id;
                delete facultyData.id; // Remove id from data to send
                result = await api.updateFaculty(id, facultyData);
            } else {
                result = await api.createFaculty(facultyData);
            }
            
            if (result && result.success) {
                await loadData();
                closeFacultyModal();
                renderApp(); // Re-render to update the table
                alert(isEditing ? 'Faculty updated successfully!' : 'Faculty added successfully!');
            } else {
                alert('Error: ' + (result?.message || 'Failed to save faculty'));
            }
        } catch (error) {
            console.error('Error saving faculty:', error);
            alert('Failed to save faculty. Please try again.');
        }
    }

    // Tab management
    function setActiveTab(tabName) {
        const navTabs = document.querySelectorAll('.nav-tab');
        navTabs.forEach(tab => {
            if (tab.dataset.tab === tabName) {
                tab.style.borderBottomColor = '#2196F3';
                tab.style.color = '#2196F3';
            } else {
                tab.style.borderBottomColor = 'transparent';
                tab.style.color = '#6b7280';
            }
        });
        
        const tabContent = document.getElementById('tabContent');
        switch (tabName) {
            case 'overview':
                tabContent.innerHTML = renderOverviewTab();
                break;
            case 'faculty':
                tabContent.innerHTML = renderFacultyTab();
                break;
            case 'subjects':
                tabContent.innerHTML = renderSubjectsTab();
                break;
            case 'allocations':
                tabContent.innerHTML = renderAllocationsTab();
                break;
            case 'timetables':
                tabContent.innerHTML = renderTimetablesTab();
                break;
        }
    }

    function renderFacultyTab() {
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Faculty Management</h2>
                <div style="display: flex; gap: 1rem;">
                    <button onclick="showFacultyStatistics()" style="padding: 12px 24px; background: #f59e0b; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Statistics
                    </button>
                    <button onclick="exportFaculty()" style="padding: 12px 24px; background: #7c3aed; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Export CSV
                    </button>
                    <button onclick="showFacultyBulkUpload()" style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Bulk Upload
                    </button>
                    <button onclick="showAddFacultyModal()" style="padding: 12px 24px; background: #3b82f6; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Add Faculty
                    </button>
                </div>
            </div>
            
            <!-- Filters Section -->
            <div style="background: white; border-radius: 8px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #1f2937;">Filter Faculty</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Department</label>
                        <select id="filterFacultyDepartment" onchange="filterFaculty()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Departments</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Electronics">Electronics</option>
                            <option value="Mechanical">Mechanical</option>
                            <option value="Civil">Civil</option>
                            <option value="Information Technology">Information Technology</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Designation</label>
                        <select id="filterFacultyDesignation" onchange="filterFaculty()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Designations</option>
                            <option value="Professor">Professor</option>
                            <option value="Associate Professor">Associate Professor</option>
                            <option value="Assistant Professor">Assistant Professor</option>
                            <option value="Lecturer">Lecturer</option>
                            <option value="HOD">HOD</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Search by Name</label>
                        <input type="text" id="filterFacultyName" onkeyup="filterFaculty()" placeholder="Enter faculty name..." 
                               style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Search by ID</label>
                        <input type="text" id="filterFacultyId" onkeyup="filterFaculty()" placeholder="Enter employee ID..." 
                               style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                    </div>
                </div>
            </div>
            
            <div style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead style="background: #f9fafb;">
                        <tr>
                            ${['Employee ID', 'Name', 'Email', 'Department', 'Designation', 'Phone', 'Actions'].map(header => 
                                `<th style="padding: 12px; text-align: left; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb;">${header}</th>`
                            ).join('')}
                        </tr>
                    </thead>
                    <tbody id="facultyTableBody">
                        ${getFilteredFaculty().map(member => `
                            <tr style="border-bottom: 1px solid #f3f4f6;">
                                <td style="padding: 12px; color: #1f2937; font-weight: 600;">${member.employeeId}</td>
                                <td style="padding: 12px; color: #1f2937;">${member.name}</td>
                                <td style="padding: 12px; color: #6b7280;">${member.email}</td>
                                <td style="padding: 12px; color: #6b7280;">${member.department}</td>
                                <td style="padding: 12px;">
                                    <span style="padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; background: ${getDesignationColor(member.designation).bg}; color: ${getDesignationColor(member.designation).text};">
                                        ${member.designation || 'Professor'}
                                    </span>
                                </td>
                                <td style="padding: 12px; color: #6b7280;">${member.phone || 'N/A'}</td>
                                <td style="padding: 12px;">
                                    <div style="display: flex; gap: 0.5rem;">
                                        <button onclick="editFaculty(${member.id})" style="padding: 6px 12px; background: #f59e0b; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                                            Edit
                                        </button>
                                        <button onclick="deleteFaculty(${member.id})" style="padding: 6px 12px; background: #ef4444; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                ${getFilteredFaculty().length === 0 ? `
                    <div style="padding: 3rem; text-align: center; color: #6b7280;">
                        <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">No Faculty Found</h3>
                        <p>${appData.faculty.length === 0 ? 'Add faculty members to start managing your institution\'s staff.' : 'No faculty match the current filters.'}</p>
                    </div>
                ` : ''}
            </div>
        `;
    }

    function renderSubjectsTab() {
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Subjects Management</h2>
                <div style="display: flex; gap: 1rem;">
                    <button onclick="showSubjectStatistics()" style="padding: 12px 24px; background: #f59e0b; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Statistics
                    </button>
                    <button onclick="exportSubjects()" style="padding: 12px 24px; background: #7c3aed; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Export CSV
                    </button>
                    <button onclick="showBulkUploadModal()" style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Bulk Upload
                    </button>
                    <button onclick="showAddSubjectModal()" style="padding: 12px 24px; background: #3b82f6; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                        Add Subject
                    </button>
                </div>
            </div>
            
            <!-- Filters Section -->
            <div style="background: white; border-radius: 8px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #1f2937;">Filter Subjects</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Department</label>
                        <select id="filterDepartment" onchange="filterSubjects()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Departments</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Electronics">Electronics</option>
                            <option value="Mechanical">Mechanical</option>
                            <option value="Civil">Civil</option>
                            <option value="Information Technology">Information Technology</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Year</label>
                        <select id="filterYear" onchange="filterSubjects()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Years</option>
                            <option value="1">Year 1</option>
                            <option value="2">Year 2</option>
                            <option value="3">Year 3</option>
                            <option value="4">Year 4</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Semester</label>
                        <select id="filterSemester" onchange="filterSubjects()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Semesters</option>
                            <option value="1">Semester 1</option>
                            <option value="2">Semester 2</option>
                        </select>
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Type</label>
                        <select id="filterType" onchange="filterSubjects()" style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                            <option value="">All Types</option>
                            <option value="theory">Theory</option>
                            <option value="lab">Lab</option>
                            <option value="practical">Practical</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div style="background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead style="background: #f9fafb;">
                        <tr>
                            ${['Code', 'Name', 'Type', 'Credits', 'Periods/Week', 'Department', 'Year', 'Semester', 'Actions'].map(header => 
                                `<th style="padding: 12px; text-align: left; font-weight: 600; color: #374151; border-bottom: 1px solid #e5e7eb;">${header}</th>`
                            ).join('')}
                        </tr>
                    </thead>
                    <tbody id="subjectsTableBody">
                        ${getFilteredSubjects().map(subject => `
                            <tr style="border-bottom: 1px solid #f3f4f6;">
                                <td style="padding: 12px; font-weight: 600; color: #1f2937;">${subject.code}</td>
                                <td style="padding: 12px; color: #1f2937;">${subject.name}</td>
                                <td style="padding: 12px;">
                                    <span style="padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; background: ${getTypeColor(subject.type).bg}; color: ${getTypeColor(subject.type).text};">
                                        ${subject.type}
                                    </span>
                                </td>
                                <td style="padding: 12px; color: #6b7280;">${subject.credits}</td>
                                <td style="padding: 12px; color: #6b7280;">${subject.periodsPerWeek || 'N/A'}</td>
                                <td style="padding: 12px; color: #6b7280;">${subject.department}</td>
                                <td style="padding: 12px; color: #6b7280;">${subject.year}</td>
                                <td style="padding: 12px; color: #6b7280;">${subject.semester}</td>
                                <td style="padding: 12px;">
                                    <div style="display: flex; gap: 0.5rem;">
                                        <button onclick="editSubject(${subject.id})" style="padding: 6px 12px; background: #f59e0b; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                                            Edit
                                        </button>
                                        <button onclick="deleteSubject(${subject.id})" style="padding: 6px 12px; background: #ef4444; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                ${getFilteredSubjects().length === 0 ? `
                    <div style="padding: 3rem; text-align: center; color: #6b7280;">
                        <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">No Subjects Found</h3>
                        <p>${appData.subjects.length === 0 ? 'Add subjects to start building your course catalog.' : 'No subjects match the current filters.'}</p>
                    </div>
                ` : ''}
            </div>
        `;
    }

    function renderAllocationsTab() {
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Faculty-Subject Allocations</h2>
                <button onclick="showCreateAllocationModal()" style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                    <i class="fas fa-plus" style="margin-right: 8px;"></i>Create New Allocation
                </button>
            </div>
            
            <!-- Create Allocation Modal -->
            <div id="createAllocationModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000;">
                <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; border-radius: 12px; width: 90%; max-width: 800px; max-height: 90%; overflow-y: auto;">
                    <div style="padding: 2rem; border-bottom: 1px solid #e5e7eb;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <h3 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Create Faculty-Subject Allocation</h3>
                            <button onclick="closeCreateAllocationModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280;">&times;</button>
                        </div>
                    </div>
                    <div style="padding: 2rem;">
                        <form onsubmit="saveAllocation(event)">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Department</label>
                                    <select id="allocationDepartment" name="department" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                                        <option value="">Select Department</option>
                                        <option value="Computer Science">Computer Science</option>
                                        <option value="IT">IT</option>
                                        <option value="CSE">CSE</option>
                                        <option value="Electronics">Electronics</option>
                                        <option value="Mechanical">Mechanical</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Year</label>
                                    <select id="allocationYear" name="year" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                                        <option value="">Select Year</option>
                                        <option value="1">1st Year</option>
                                        <option value="2">2nd Year</option>
                                        <option value="3">3rd Year</option>
                                        <option value="4">4th Year</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Semester</label>
                                    <select id="allocationSemester" name="semester" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                                        <option value="">Select Semester</option>
                                        <option value="1">1st Semester</option>
                                        <option value="2">2nd Semester</option>
                                    </select>
                                </div>
                                <div>
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Section</label>
                                    <input type="text" id="allocationSection" name="section" placeholder="e.g., A, B, C" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                                </div>
                            </div>
                            
                            <div style="margin-bottom: 1.5rem;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                                    <h4 style="font-size: 1rem; font-weight: 600; color: #374151;">Faculty-Subject Assignments</h4>
                                    <button type="button" onclick="addFacultySubjectRow()" style="padding: 8px 16px; background: #3b82f6; color: white; border: none; border-radius: 6px; font-size: 0.875rem; cursor: pointer;">
                                        <i class="fas fa-plus" style="margin-right: 4px;"></i>Add Assignment
                                    </button>
                                </div>
                                <div id="facultySubjectRows" style="display: grid; gap: 1rem;">
                                    <!-- Faculty-subject rows will be added here -->
                                </div>
                            </div>
                            
                            <div style="display: flex; justify-content: flex-end; gap: 1rem; padding-top: 1rem; border-top: 1px solid #e5e7eb;">
                                <button type="button" onclick="closeCreateAllocationModal()" style="padding: 8px 16px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer;">Cancel</button>
                                <button type="submit" style="padding: 8px 16px; background: #10b981; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer;">Create Allocation</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div style="display: grid; gap: 1.5rem;">
                ${appData.allocations.map(allocation => `
                    <div style="background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden;">
                        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 1.5rem;">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem;">
                                        ${allocation.department} - Year ${allocation.year}
                                    </h3>
                                    <p style="opacity: 0.9;">Semester ${allocation.semester}, Section ${allocation.section}</p>
                                </div>
                                <div style="display: flex; gap: 0.5rem; align-items: center;">
                                    <span style="padding: 4px 12px; background: rgba(255,255,255,0.2); border-radius: 20px; font-size: 0.75rem; font-weight: 600;">
                                        ${allocation.facultySubjects?.length || 0} mappings
                                    </span>
                                    <button onclick="toggleAllocationView(${allocation.id})" style="padding: 8px 16px; background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); border-radius: 6px; font-size: 0.875rem; cursor: pointer;">
                                        View Details
                                    </button>
                                    <button onclick="editAllocation(${allocation.id})" style="padding: 8px 16px; background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); border-radius: 6px; font-size: 0.875rem; cursor: pointer;">
                                        Edit
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div id="allocationDetails${allocation.id}" style="display: none; padding: 1.5rem;">
                            ${renderAllocationDetails(allocation)}
                        </div>
                    </div>
                `).join('')}
                
                ${appData.allocations.length === 0 ? `
                    <div style="background: white; border-radius: 8px; padding: 3rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center; color: #6b7280;">
                        <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">No Allocations Created</h3>
                        <p>Create faculty-subject allocations to enable timetable generation for different classes.</p>
                    </div>
                ` : ''}
            </div>
        `;
    }

    function renderTimetablesTab() {
        return `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Timetable Management</h2>
                <div style="display: flex; gap: 1rem;">
                    <button onclick="showAllocationSummary()" style="padding: 12px 24px; background: #6366f1; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">View Allocations</button>
                    <button onclick="showTimetableGenerator()" style="padding: 12px 24px; background: #2196F3; color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">Generate New Timetable</button>
                </div>
            </div>

            <!-- Allocation Summary Modal -->
            <div id="allocationSummaryModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000;">
                <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; border-radius: 12px; width: 90%; max-width: 1200px; max-height: 90%; overflow-y: auto;">
                    <div style="padding: 2rem; border-bottom: 1px solid #e5e7eb;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <h3 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Faculty-Subject Allocation Summary</h3>
                            <button onclick="closeAllocationSummary()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280;">&times;</button>
                        </div>
                    </div>
                    <div id="allocationSummaryContent" style="padding: 2rem;"></div>
                </div>
            </div>
            
            <div id="timetableGenerator" style="display: none; background: white; border-radius: 8px; padding: 2rem; margin-bottom: 2rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 1.5rem; color: #1f2937;">Generate Timetable</h3>
                <form onsubmit="handleGenerateTimetable(event)">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
                        <div>
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Department</label>
                            <select name="department" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                                <option value="">Select Department</option>
                                <option value="Computer Science">Computer Science</option>
                                <option value="Electronics">Electronics</option>
                                <option value="Mechanical">Mechanical</option>
                                <option value="Civil">Civil</option>
                                <option value="Electrical">Electrical</option>
                            </select>
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Year</label>
                            <select name="year" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                                <option value="">Select Year</option>
                                <option value="1">Year 1</option>
                                <option value="2">Year 2</option>
                                <option value="3">Year 3</option>
                                <option value="4">Year 4</option>
                            </select>
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Semester</label>
                            <select name="semester" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                                <option value="">Select Semester</option>
                                <option value="1">Semester 1</option>
                                <option value="2">Semester 2</option>
                            </select>
                        </div>
                        <div>
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Section</label>
                            <select name="section" required style="width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 6px;">
                                <option value="">Select Section</option>
                                <option value="A">Section A</option>
                                <option value="B">Section B</option>
                                <option value="C">Section C</option>
                            </select>
                        </div>
                    </div>
                    <div style="background: #f8fafc; padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem; font-size: 0.875rem; color: #6b7280;">
                        <strong>Timetable Generation Rules:</strong>
                        <ul style="margin: 0.5rem 0; padding-left: 1.5rem;">
                            <li>Weekly schedule: Monday to Saturday, 7 periods per day</li>
                            <li>Lab subjects require 3 consecutive periods</li>
                            <li>Theory subjects distributed across available slots</li>
                            <li>Lunch break randomly assigned to 4th or 5th period</li>
                            <li>Faculty workload and conflict validation</li>
                        </ul>
                    </div>
                    <button type="submit" style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer;">Generate Timetable</button>
                </form>
            </div>
            
            <div style="display: grid; gap: 1.5rem;">
                ${appData.timetables.map(timetable => `
                    <div style="background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden;">
                        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.5rem;">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div>
                                    <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 0.5rem;">${timetable.department} - Year ${timetable.year}</h3>
                                    <p style="opacity: 0.9;">Semester ${timetable.semester}, Section ${timetable.section}</p>
                                </div>
                                <div style="display: flex; gap: 0.5rem;">
                                    <button onclick="toggleTimetableView(${timetable.id})" style="padding: 8px 16px; background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); border-radius: 6px; font-size: 0.875rem; cursor: pointer;">
                                        View Details
                                    </button>
                                    <button onclick="exportTimetablePDF(${timetable.id})" style="padding: 8px 16px; background: rgba(255,255,255,0.2); color: white; border: 1px solid rgba(255,255,255,0.3); border-radius: 6px; font-size: 0.875rem; cursor: pointer;">
                                        Export PDF
                                    </button>
                                    ${auth.isAdmin() ? `
                                        <button onclick="deleteTimetable(${timetable.id})" style="padding: 8px 16px; background: rgba(239, 68, 68, 0.2); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 6px; font-size: 0.875rem; cursor: pointer;" onmouseover="this.style.background='rgba(239, 68, 68, 0.3)'" onmouseout="this.style.background='rgba(239, 68, 68, 0.2)'">
                                            Delete
                                        </button>
                                    ` : ''}
                                </div>
                            </div>
                        </div>
                        ${timetable.metadata ? `
                            <div style="background: #f8fafc; padding: 1rem 1.5rem; border-top: 1px solid #e5e7eb; font-size: 0.875rem; color: #6b7280;">
                                Generated: ${new Date(timetable.createdAt || Date.now()).toLocaleDateString()} | 
                                Total Periods: ${timetable.metadata.totalPeriods} | 
                                Theory: ${timetable.metadata.theoryPeriods} | 
                                Lab: ${timetable.metadata.labPeriods} | 
                                Free: ${timetable.metadata.freePeriods}
                            </div>
                        ` : ''}
                        <div id="timetableSchedule${timetable.id}" style="display: none; padding: 1.5rem;">
                            ${renderTimetableSchedule(timetable)}
                        </div>
                    </div>
                `).join('')}
                
                ${appData.timetables.length === 0 ? `
                    <div style="background: white; border-radius: 8px; padding: 3rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center; color: #6b7280;">
                        <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">No Timetables Generated</h3>
                        <p>Generate timetables to view automated schedules for your classes.</p>
                    </div>
                ` : ''}
            </div>
        `;
    }

    function showTimetableGenerator() {
        const generator = document.getElementById('timetableGenerator');
        generator.style.display = generator.style.display === 'none' ? 'block' : 'none';
    }

    // Allocation details functions
    function renderAllocationDetails(allocation) {
        if (!allocation.facultySubjects || allocation.facultySubjects.length === 0) {
            return `
                <div style="text-align: center; color: #6b7280; padding: 2rem;">
                    <h4 style="font-size: 1rem; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">No Faculty-Subject Mappings</h4>
                    <p>No faculty members have been assigned to subjects for this class.</p>
                </div>
            `;
        }

        return `
            <div style="margin-bottom: 1.5rem;">
                <h4 style="font-size: 1rem; font-weight: 600; margin-bottom: 1rem; color: #374151;">Faculty-Subject Assignments</h4>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; font-size: 0.875rem;">
                        <thead>
                            <tr style="background: #f8fafc;">
                                <th style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; text-align: left;">Faculty</th>
                                <th style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; text-align: left;">Subject</th>
                                <th style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; text-align: center;">Type</th>
                                <th style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; text-align: center;">Credits</th>
                                <th style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; text-align: center;">Periods/Week</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${allocation.facultySubjects.map(mapping => {
                                const faculty = appData.faculty.find(f => f.id === mapping.facultyId) || {};
                                const subject = appData.subjects.find(s => s.id === mapping.subjectId) || {};
                                return `
                                    <tr style="border-bottom: 1px solid #f3f4f6;">
                                        <td style="padding: 12px; border: 1px solid #e5e7eb;">
                                            <div style="font-weight: 600; color: #1f2937;">${faculty.name || 'Unknown Faculty'}</div>
                                            <div style="font-size: 0.75rem; color: #6b7280;">${faculty.employeeId || ''}</div>
                                        </td>
                                        <td style="padding: 12px; border: 1px solid #e5e7eb;">
                                            <div style="font-weight: 600; color: #1f2937;">${subject.name || 'Unknown Subject'}</div>
                                            <div style="font-size: 0.75rem; color: #6b7280;">${subject.code || ''}</div>
                                        </td>
                                        <td style="padding: 12px; border: 1px solid #e5e7eb; text-align: center;">
                                            <span style="padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; background: ${getTypeColor(subject.type || 'theory').bg}; color: ${getTypeColor(subject.type || 'theory').text};">
                                                ${subject.type || 'theory'}
                                            </span>
                                        </td>
                                        <td style="padding: 12px; border: 1px solid #e5e7eb; text-align: center; color: #6b7280;">
                                            ${subject.credits || 'N/A'}
                                        </td>
                                        <td style="padding: 12px; border: 1px solid #e5e7eb; text-align: center; color: #6b7280;">
                                            ${subject.periodsPerWeek || 'N/A'}
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
            <div style="background: #f8fafc; padding: 1rem; border-radius: 8px; font-size: 0.875rem; color: #6b7280;">
                <strong>Summary:</strong> ${allocation.facultySubjects.length} faculty-subject assignments for ${allocation.department} Year ${allocation.year}, Semester ${allocation.semester}, Section ${allocation.section}
            </div>
        `;
    }

    function toggleAllocationView(allocationId) {
        const detailsDiv = document.getElementById(`allocationDetails${allocationId}`);
        if (!detailsDiv) return;
        
        const button = event ? event.target : null;
        
        if (detailsDiv.style.display === 'none' || detailsDiv.style.display === '') {
            detailsDiv.style.display = 'block';
            if (button) button.textContent = 'Hide Details';
        } else {
            detailsDiv.style.display = 'none';
            if (button) button.textContent = 'View Details';
        }
    }

    // Enhanced timetable display functions
    function renderTimetableSchedule(timetable) {
        if (!timetable.schedule || !timetable.schedule.length) {
            return '<div style="text-align: center; color: #6b7280; padding: 2rem;">No schedule data available</div>';
        }

        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const periods = ['Period 1', 'Period 2', 'Period 3', 'Period 4', 'Period 5', 'Period 6', 'Period 7'];

        // Get allocation for this timetable to show detailed information
        const allocation = appData.allocations.find(a => 
            a.department === timetable.department && 
            a.year === timetable.year && 
            a.semester === timetable.semester && 
            a.section === timetable.section
        );

        return `
            <!-- Timetable Summary -->
            <div style="background: #f8fafc; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem;">
                <h4 style="font-size: 1.125rem; font-weight: 600; color: #1f2937; margin-bottom: 1rem;">Class Information</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; font-size: 0.875rem;">
                    <div>
                        <span style="font-weight: 600; color: #374151;">Department:</span>
                        <span style="color: #6b7280; margin-left: 0.5rem;">${timetable.department}</span>
                    </div>
                    <div>
                        <span style="font-weight: 600; color: #374151;">Year & Section:</span>
                        <span style="color: #6b7280; margin-left: 0.5rem;">Year ${timetable.year}, Section ${timetable.section}</span>
                    </div>
                    <div>
                        <span style="font-weight: 600; color: #374151;">Semester:</span>
                        <span style="color: #6b7280; margin-left: 0.5rem;">Semester ${timetable.semester}</span>
                    </div>
                    <div>
                        <span style="font-weight: 600; color: #374151;">Generated:</span>
                        <span style="color: #6b7280; margin-left: 0.5rem;">${new Date(timetable.createdAt || Date.now()).toLocaleDateString()}</span>
                    </div>
                </div>
                ${allocation && allocation.facultySubjects ? `
                    <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e5e7eb;">
                        <span style="font-weight: 600; color: #374151;">Faculty Assignments:</span>
                        <span style="color: #6b7280; margin-left: 0.5rem;">${allocation.facultySubjects.length} subject assignments</span>
                    </div>
                ` : ''}
            </div>

            <!-- Weekly Schedule Table (Days as Rows, Periods as Columns) -->
            <div style="overflow-x: auto; border-radius: 8px; border: 1px solid #e5e7eb;">
                <table style="width: 100%; border-collapse: collapse; font-size: 0.875rem; background: white;">
                    <thead>
                        <tr style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
                            <th style="padding: 16px; border: 1px solid rgba(255,255,255,0.2); font-weight: 600; text-align: center; min-width: 120px;">
                                <div>Day</div>
                                <div style="font-size: 0.75rem; opacity: 0.9; margin-top: 4px;">Schedule</div>
                            </th>
                            ${periods.map((period, periodIndex) => `
                                <th style="padding: 16px; border: 1px solid rgba(255,255,255,0.2); font-weight: 600; text-align: center; min-width: 140px;">
                                    <div>${period}</div>
                                    <div style="font-size: 0.75rem; opacity: 0.9; margin-top: 4px;">${getPeriodTime(periodIndex)}</div>
                                </th>
                            `).join('')}
                        </tr>
                    </thead>
                    <tbody>
                        ${days.map((day, dayIndex) => `
                            <tr style="${dayIndex % 2 === 0 ? 'background: #f9fafb;' : 'background: white;'}">
                                <td style="padding: 16px; border: 1px solid #e5e7eb; font-weight: 600; background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%); text-align: center;">
                                    <div style="color: #1f2937; font-size: 0.9rem; font-weight: 700;">${day}</div>
                                    <div style="font-size: 0.75rem; color: #6b7280; margin-top: 4px; font-weight: 500;">Daily Schedule</div>
                                </td>
                                ${periods.map((period, periodIndex) => {
                                    const slot = getScheduleSlot(timetable.schedule, dayIndex, periodIndex);
                                    return `<td style="padding: 12px; border: 1px solid #e5e7eb; text-align: center; vertical-align: middle; min-height: 70px;">
                                        ${slot ? renderScheduleSlot(slot) : '<span style="color: #9ca3af; font-style: italic; font-size: 0.8rem;">Free</span>'}
                                    </td>`;
                                }).join('')}
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>

            <!-- Schedule Legend -->
            <div style="margin-top: 1.5rem; background: #f8fafc; padding: 1rem; border-radius: 8px;">
                <h5 style="font-weight: 600; color: #374151; margin-bottom: 0.75rem;">Schedule Legend:</h5>
                <div style="display: flex; flex-wrap: wrap; gap: 1rem; font-size: 0.875rem;">
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <div style="width: 16px; height: 16px; background: #dbeafe; border-radius: 4px;"></div>
                        <span style="color: #6b7280;">Theory Subjects</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <div style="width: 16px; height: 16px; background: #dcfce7; border-radius: 4px;"></div>
                        <span style="color: #6b7280;">Lab Subjects</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <div style="width: 16px; height: 16px; background: #fce7f3; border-radius: 4px;"></div>
                        <span style="color: #6b7280;">Practical Subjects</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <div style="width: 16px; height: 16px; background: #fef3c7; border-radius: 4px;"></div>
                        <span style="color: #6b7280;">Lunch Break</span>
                    </div>
                </div>
            </div>
        `;
    }

    function getScheduleSlot(schedule, dayIndex, periodIndex) {
        if (!schedule || !schedule[dayIndex]) return null;
        return schedule[dayIndex][periodIndex] || null;
    }

    function renderScheduleSlot(slot) {
        if (!slot || slot.type === 'free') return '<span style="color: #9ca3af; font-style: italic;">Free Period</span>';
        
        if (slot.type === 'lunch') {
            return `
                <div style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); color: #d97706; padding: 12px 8px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; text-align: center; border: 2px solid #f59e0b;">
                    <div style="font-size: 0.875rem;">🍽️ LUNCH</div>
                    <div style="font-size: 0.625rem; margin-top: 2px; opacity: 0.8;">Break Time</div>
                </div>
            `;
        }

        const subjectColors = {
            'theory': { bg: 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)', text: '#1e40af', border: '#3b82f6' },
            'lab': { bg: 'linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%)', text: '#166534', border: '#10b981' },
            'practical': { bg: 'linear-gradient(135deg, #fce7f3 0%, #f9a8d4 100%)', text: '#be185d', border: '#ec4899' }
        };

        const color = subjectColors[slot.subjectType] || { 
            bg: 'linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%)', 
            text: '#374151', 
            border: '#9ca3af' 
        };

        // Get detailed subject and faculty information
        const subject = appData.subjects.find(s => s.code === slot.subjectCode || s.name === slot.subject) || {};
        const faculty = appData.faculty.find(f => f.name === slot.facultyName || f.employeeId === slot.faculty) || {};

        return `
            <div style="background: ${color.bg}; color: ${color.text}; padding: 10px; border-radius: 6px; font-size: 0.75rem; border: 2px solid ${color.border}; min-height: 70px; display: flex; flex-direction: column; justify-content: center;">
                <div style="font-weight: 700; margin-bottom: 4px; font-size: 0.8rem;">
                    ${slot.subjectCode || subject.code || 'N/A'}
                </div>
                <div style="font-weight: 500; margin-bottom: 4px; font-size: 0.7rem; opacity: 0.9;">
                    ${slot.subject || subject.name || 'Unknown Subject'}
                </div>
                <div style="font-weight: 500; margin-bottom: 2px; font-size: 0.7rem; opacity: 0.8;">
                    ${slot.facultyName || faculty.name || 'Unknown Faculty'}
                </div>
                ${faculty.employeeId ? `
                    <div style="font-size: 0.625rem; opacity: 0.7; margin-bottom: 2px;">
                        ID: ${faculty.employeeId}
                    </div>
                ` : ''}
                ${slot.room ? `
                    <div style="font-size: 0.625rem; opacity: 0.7; background: rgba(255,255,255,0.3); padding: 2px 4px; border-radius: 3px; margin-top: 2px;">
                        Room: ${slot.room}
                    </div>
                ` : ''}
                <div style="font-size: 0.625rem; opacity: 0.6; margin-top: 2px; text-transform: uppercase; font-weight: 600;">
                    ${slot.subjectType || subject.type || 'Theory'}
                </div>
            </div>
        `;
    }

    function getPeriodTime(periodIndex) {
        const times = [
            '9:00-10:00',
            '10:00-11:00', 
            '11:15-12:15',
            '12:15-1:15',  // Period 4 - Possible Lunch
            '1:15-2:15',   // Period 5 - Possible Lunch
            '2:30-3:30',
            '3:30-4:30'
        ];
        return times[periodIndex] || '';
    }

    function toggleTimetableView(timetableId) {
        const scheduleDiv = document.getElementById(`timetableSchedule${timetableId}`);
        if (!scheduleDiv) return;
        
        const button = event ? event.target : null;
        
        if (scheduleDiv.style.display === 'none' || scheduleDiv.style.display === '') {
            scheduleDiv.style.display = 'block';
            if (button) button.textContent = 'Hide Details';
        } else {
            scheduleDiv.style.display = 'none';
            if (button) button.textContent = 'View Details';
        }
    }

    async function exportTimetablePDF(timetableId, buttonElement = null) {
        const timetable = appData.timetables.find(t => t.id == timetableId);
        if (!timetable) {
            alert('Timetable not found');
            return;
        }

        let loadingBtn = null;
        try {
            console.log('Exporting PDF for timetable ID:', timetableId);
            
            // Find the button element
            loadingBtn = buttonElement || 
                        document.querySelector(`[onclick*="exportTimetablePDF(${timetableId})"]`) || 
                        document.querySelector(`button[data-export-id="${timetableId}"]`);
            if (loadingBtn) {
                loadingBtn.innerHTML = '<div class="loading-spinner small"></div> Exporting...';
                loadingBtn.disabled = true;
            }
            
            const authToken = localStorage.getItem('authToken');
            if (!authToken) {
                throw new Error('No authentication token found. Please log in again.');
            }

            const response = await fetch(`${API_BASE_URL}/api/timetables/${timetableId}/export`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Accept': 'application/pdf'
                }
            });

            console.log('PDF export response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('PDF export failed:', response.status, errorText);
                throw new Error(`Failed to generate PDF: ${response.status} - ${errorText}`);
            }

            const blob = await response.blob();
            console.log('PDF blob size:', blob.size);
            
            if (blob.size === 0) {
                throw new Error('Generated PDF is empty');
            }
            
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `SmartScheduler_${timetable.department || 'Unknown'}_Year${timetable.year || 'X'}_Sem${timetable.semester || 'X'}_Sec${timetable.section || 'A'}.pdf`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);
            
            alert('PDF exported successfully!');
            
            // Reset button on success
            if (loadingBtn) {
                loadingBtn.innerHTML = '<span style="color: #059669;">Export PDF</span>';
                loadingBtn.disabled = false;
            }
            
        } catch (error) {
            console.error('Export error:', error);
            alert('Failed to export PDF: ' + error.message);
            
            // Reset button on error
            if (loadingBtn) {
                loadingBtn.innerHTML = '<span style="color: #059669;">Export PDF</span>';
                loadingBtn.disabled = false;
            }
        }
    }

    async function deleteTimetable(timetableId, buttonElement) {
        if (!confirm('Are you sure you want to delete this timetable? This action cannot be undone.')) {
            return;
        }

        let loadingBtn = null;
        try {
            console.log('Deleting timetable with ID:', timetableId);
            
            // Find the button element
            loadingBtn = buttonElement || 
                        document.querySelector(`[onclick*="deleteTimetable(${timetableId})"]`) || 
                        document.querySelector(`button[data-timetable-id="${timetableId}"]`);
            
            if (loadingBtn) {
                loadingBtn.innerHTML = '<div class="loading-spinner small"></div> Deleting...';
                loadingBtn.disabled = true;
            }

            const authToken = localStorage.getItem('authToken');
            if (!authToken) {
                throw new Error('No authentication token found. Please log in again.');
            }

            const response = await fetch(`${API_BASE_URL}/api/timetables/${timetableId}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${authToken}`,
                    'Content-Type': 'application/json'
                }
            });

            console.log('Delete response status:', response.status);

            if (response.ok) {
                const result = await response.json();
                console.log('Delete successful:', result);
                
                // Remove timetable from local data
                appData.timetables = appData.timetables.filter(t => t.id != timetableId);
                
                // Reload data to ensure consistency
                await loadData();
                
                // Re-render the appropriate view
                if (currentView === 'admin') {
                    renderAdminDashboard();
                    setActiveTab('timetables');
                } else if (currentView === 'faculty') {
                    renderFacultyDashboard();
                    setFacultyActiveTab('timetables');
                }
                
                alert('Timetable deleted successfully!');
            } else {
                const errorData = await response.json().catch(() => ({ message: 'Delete failed' }));
                throw new Error(errorData.message || `Delete failed with status ${response.status}`);
            }
        } catch (error) {
            console.error('Delete error:', error);
            alert('Failed to delete timetable: ' + error.message);
            
            if (loadingBtn) {
                loadingBtn.innerHTML = '<span style="color: #dc2626;">Delete</span>';
                loadingBtn.disabled = false;
            }
        }
    }

    function generateSimplePDFContent(timetable) {
        const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const periods = ['Period 1', 'Period 2', 'Period 3', 'Period 4', 'Period 5', 'Period 6', 'Period 7'];
        
        let content = `SMARTSCHEDULER - CLASS TIMETABLE\n`;
        content += `=========================================\n\n`;
        content += `Department: ${timetable.department || 'N/A'}\n`;
        content += `Year: ${timetable.year || 'N/A'} | Semester: ${timetable.semester || 'N/A'} | Section: ${timetable.section || 'N/A'}\n`;
        content += `Generated: ${new Date(timetable.createdAt).toLocaleDateString()}\n\n`;
        
        content += `WEEKLY SCHEDULE\n`;
        content += `===============\n\n`;
        
        if (timetable.schedule && timetable.schedule.length > 0) {
            days.forEach((day, dayIndex) => {
                if (dayIndex < timetable.schedule.length) {
                    content += `${day.toUpperCase()}\n`;
                    content += `---------\n`;
                    
                    const daySchedule = timetable.schedule[dayIndex];
                    periods.forEach((period, periodIndex) => {
                        if (periodIndex < daySchedule.length) {
                            const slot = daySchedule[periodIndex];
                            if (slot && slot.type === 'lunch') {
                                content += `${period}: LUNCH BREAK\n`;
                            } else if (slot && slot.subject) {
                                content += `${period}: ${slot.subject}`;
                                if (slot.facultyName) {
                                    content += ` (${slot.facultyName})`;
                                }
                                if (slot.subjectType) {
                                    content += ` [${slot.subjectType.toUpperCase()}]`;
                                }
                                content += `\n`;
                            } else {
                                content += `${period}: FREE PERIOD\n`;
                            }
                        }
                    });
                    content += `\n`;
                }
            });
        }
        
        if (timetable.metadata) {
            content += `TIMETABLE STATISTICS\n`;
            content += `===================\n`;
            content += `Total Subjects: ${timetable.metadata.totalSubjects || 'N/A'}\n`;
            content += `Total Faculty: ${timetable.metadata.totalFaculty || 'N/A'}\n`;
            content += `Total Labs: ${timetable.metadata.totalLabs || 'N/A'}\n`;
            content += `Algorithm: ${timetable.metadata.generation?.algorithm || 'Standard'}\n`;
        }
        
        content += `\n\nGenerated by SmartScheduler\n`;
        content += `${new Date().toLocaleString()}\n`;
        
        return content;
    }

    // Faculty management helper functions
    function getDesignationColor(designation) {
        switch(designation) {
            case 'HOD':
                return { bg: '#fee2e2', text: '#dc2626' };
            case 'Professor':
                return { bg: '#dbeafe', text: '#2563eb' };
            case 'Associate Professor':
                return { bg: '#f0f9ff', text: '#0369a1' };
            case 'Assistant Professor':
                return { bg: '#f0fdf4', text: '#166534' };
            case 'Lecturer':
                return { bg: '#fef3c7', text: '#d97706' };
            default:
                return { bg: '#f3f4f6', text: '#374151' };
        }
    }

    function getFilteredFaculty() {
        const departmentFilter = document.getElementById('filterFacultyDepartment')?.value || '';
        const designationFilter = document.getElementById('filterFacultyDesignation')?.value || '';
        const nameFilter = document.getElementById('filterFacultyName')?.value.toLowerCase() || '';
        const idFilter = document.getElementById('filterFacultyId')?.value.toLowerCase() || '';

        return appData.faculty.filter(member => {
            return (!departmentFilter || member.department === departmentFilter) &&
                   (!designationFilter || member.designation === designationFilter) &&
                   (!nameFilter || member.name.toLowerCase().includes(nameFilter)) &&
                   (!idFilter || member.employeeId.toLowerCase().includes(idFilter));
        });
    }

    function filterFaculty() {
        document.getElementById('facultyTableBody').innerHTML = getFilteredFaculty().map(member => `
            <tr style="border-bottom: 1px solid #f3f4f6;">
                <td style="padding: 12px; color: #1f2937; font-weight: 600;">${member.employeeId}</td>
                <td style="padding: 12px; color: #1f2937;">${member.name}</td>
                <td style="padding: 12px; color: #6b7280;">${member.email}</td>
                <td style="padding: 12px; color: #6b7280;">${member.department}</td>
                <td style="padding: 12px;">
                    <span style="padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; background: ${getDesignationColor(member.designation).bg}; color: ${getDesignationColor(member.designation).text};">
                        ${member.designation || 'Professor'}
                    </span>
                </td>
                <td style="padding: 12px; color: #6b7280;">${member.phone || 'N/A'}</td>
                <td style="padding: 12px;">
                    <div style="display: flex; gap: 0.5rem;">
                        <button onclick="editFaculty(${member.id})" style="padding: 6px 12px; background: #f59e0b; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                            Edit
                        </button>
                        <button onclick="deleteFaculty(${member.id})" style="padding: 6px 12px; background: #ef4444; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                            Delete
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Subject management helper functions
    function getTypeColor(type) {
        switch(type) {
            case 'lab':
                return { bg: '#fee2e2', text: '#dc2626' };
            case 'practical':
                return { bg: '#fef3c7', text: '#d97706' };
            default:
                return { bg: '#dbeafe', text: '#2563eb' };
        }
    }

    function getFilteredSubjects() {
        const departmentFilter = document.getElementById('filterDepartment')?.value || '';
        const yearFilter = document.getElementById('filterYear')?.value || '';
        const semesterFilter = document.getElementById('filterSemester')?.value || '';
        const typeFilter = document.getElementById('filterType')?.value || '';

        return appData.subjects.filter(subject => {
            return (!departmentFilter || subject.department === departmentFilter) &&
                   (!yearFilter || subject.year.toString() === yearFilter) &&
                   (!semesterFilter || subject.semester.toString() === semesterFilter) &&
                   (!typeFilter || subject.type === typeFilter);
        });
    }

    function filterSubjects() {
        document.getElementById('subjectsTableBody').innerHTML = getFilteredSubjects().map(subject => `
            <tr style="border-bottom: 1px solid #f3f4f6;">
                <td style="padding: 12px; font-weight: 600; color: #1f2937;">${subject.code}</td>
                <td style="padding: 12px; color: #1f2937;">${subject.name}</td>
                <td style="padding: 12px;">
                    <span style="padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; background: ${getTypeColor(subject.type).bg}; color: ${getTypeColor(subject.type).text};">
                        ${subject.type}
                    </span>
                </td>
                <td style="padding: 12px; color: #6b7280;">${subject.credits}</td>
                <td style="padding: 12px; color: #6b7280;">${subject.periodsPerWeek || 'N/A'}</td>
                <td style="padding: 12px; color: #6b7280;">${subject.department}</td>
                <td style="padding: 12px; color: #6b7280;">${subject.year}</td>
                <td style="padding: 12px; color: #6b7280;">${subject.semester}</td>
                <td style="padding: 12px;">
                    <div style="display: flex; gap: 0.5rem;">
                        <button onclick="editSubject(${subject.id})" style="padding: 6px 12px; background: #f59e0b; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                            Edit
                        </button>
                        <button onclick="deleteSubject(${subject.id})" style="padding: 6px 12px; background: #ef4444; color: white; border: none; border-radius: 4px; font-size: 0.75rem; cursor: pointer;">
                            Delete
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    let currentEditingSubject = null;

    function showAddSubjectModal(subjectData = null) {
        currentEditingSubject = subjectData;
        const isEditing = !!subjectData;
        
        const modalHtml = `
            <div id="subjectModal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center; z-index: 1000;">
                <div style="background: white; border-radius: 12px; padding: 2rem; width: 90%; max-width: 600px; max-height: 90vh; overflow-y: auto;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                        <h3 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">${isEditing ? 'Edit Subject' : 'Add New Subject'}</h3>
                        <button onclick="closeSubjectModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280;">&times;</button>
                    </div>
                    
                    <form id="subjectForm" onsubmit="saveSubject(event)">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Subject Code *</label>
                                <input type="text" name="code" value="${subjectData?.code || ''}" required 
                                       style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;"
                                       placeholder="e.g., CS101">
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Subject Name *</label>
                                <input type="text" name="name" value="${subjectData?.name || ''}" required 
                                       style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;"
                                       placeholder="e.g., Programming Fundamentals">
                            </div>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Type *</label>
                                <select name="type" required onchange="updatePeriodsPerWeek(this.value)"
                                        style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                                    <option value="theory" ${subjectData?.type === 'theory' ? 'selected' : ''}>Theory</option>
                                    <option value="lab" ${subjectData?.type === 'lab' ? 'selected' : ''}>Lab</option>
                                    <option value="practical" ${subjectData?.type === 'practical' ? 'selected' : ''}>Practical</option>
                                </select>
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Credits *</label>
                                <input type="number" name="credits" value="${subjectData?.credits || ''}" required min="1" max="6"
                                       style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Periods/Week *</label>
                                <input type="number" name="periodsPerWeek" value="${subjectData?.periodsPerWeek || ''}" required min="1" max="6"
                                       style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                            </div>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Department *</label>
                                <select name="department" required 
                                        style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                                    <option value="">Select Department</option>
                                    <option value="Computer Science" ${subjectData?.department === 'Computer Science' ? 'selected' : ''}>Computer Science</option>
                                    <option value="Electronics" ${subjectData?.department === 'Electronics' ? 'selected' : ''}>Electronics</option>
                                    <option value="Mechanical" ${subjectData?.department === 'Mechanical' ? 'selected' : ''}>Mechanical</option>
                                    <option value="Civil" ${subjectData?.department === 'Civil' ? 'selected' : ''}>Civil</option>
                                    <option value="Information Technology" ${subjectData?.department === 'Information Technology' ? 'selected' : ''}>Information Technology</option>
                                </select>
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Year *</label>
                                <select name="year" required 
                                        style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                                    <option value="">Select Year</option>
                                    <option value="1" ${subjectData?.year === 1 ? 'selected' : ''}>Year 1</option>
                                    <option value="2" ${subjectData?.year === 2 ? 'selected' : ''}>Year 2</option>
                                    <option value="3" ${subjectData?.year === 3 ? 'selected' : ''}>Year 3</option>
                                    <option value="4" ${subjectData?.year === 4 ? 'selected' : ''}>Year 4</option>
                                </select>
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Semester *</label>
                                <select name="semester" required 
                                        style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem;">
                                    <option value="">Select Semester</option>
                                    <option value="1" ${subjectData?.semester === 1 ? 'selected' : ''}>Semester 1</option>
                                    <option value="2" ${subjectData?.semester === 2 ? 'selected' : ''}>Semester 2</option>
                                </select>
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 1.5rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Description</label>
                            <textarea name="description" placeholder="Optional subject description..."
                                      style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 1rem; min-height: 80px; resize: vertical;">${subjectData?.description || ''}</textarea>
                        </div>
                        
                        <div style="display: flex; justify-content: flex-end; gap: 1rem;">
                            <button type="button" onclick="closeSubjectModal()" 
                                    style="padding: 12px 24px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer;">
                                Cancel
                            </button>
                            <button type="submit" 
                                    style="padding: 12px 24px; background: #3b82f6; color: white; border: none; border-radius: 6px; cursor: pointer;">
                                ${isEditing ? 'Update Subject' : 'Add Subject'}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }

    function updatePeriodsPerWeek(type) {
        const periodsInput = document.querySelector('input[name="periodsPerWeek"]');
        if (periodsInput) {
            switch(type) {
                case 'lab':
                    periodsInput.value = 3;
                    break;
                case 'practical':
                    periodsInput.value = 2;
                    break;
                default:
                    periodsInput.value = 4;
            }
        }
    }

    function closeSubjectModal() {
        const modal = document.getElementById('subjectModal');
        if (modal) {
            modal.remove();
        }
        currentEditingSubject = null;
    }

    async function saveSubject(event) {
        event.preventDefault();
        
        const formData = new FormData(event.target);
        const subjectData = {
            code: formData.get('code'),
            name: formData.get('name'),
            type: formData.get('type'),
            credits: parseInt(formData.get('credits')),
            periodsPerWeek: parseInt(formData.get('periodsPerWeek')),
            department: formData.get('department'),
            year: parseInt(formData.get('year')),
            semester: parseInt(formData.get('semester')),
            description: formData.get('description')
        };

        try {
            let result;
            if (currentEditingSubject) {
                result = await api.updateSubject(currentEditingSubject.id, subjectData);
            } else {
                result = await api.createSubject(subjectData);
            }

            if (result.success) {
                closeSubjectModal();
                await loadData();
                renderApp();
                alert(`Subject ${currentEditingSubject ? 'updated' : 'added'} successfully!`);
            } else {
                alert(`Error: ${result.message}`);
            }
        } catch (error) {
            console.error('Save subject error:', error);
            alert('Failed to save subject. Please try again.');
        }
    }

    async function editSubject(id) {
        const subject = appData.subjects.find(s => s.id === id);
        if (subject) {
            showAddSubjectModal(subject);
        }
    }

    async function deleteSubject(id) {
        const subject = appData.subjects.find(s => s.id === id);
        if (subject && confirm(`Are you sure you want to delete "${subject.name}"?`)) {
            try {
                const result = await api.deleteSubject(id);
                if (result && result.success) {
                    await loadData();
                    renderApp();
                    alert('Subject deleted successfully!');
                } else {
                    alert(`Error: ${result?.message || 'Failed to delete subject'}`);
                }
            } catch (error) {
                console.error('Delete subject error:', error);
                alert('Failed to delete subject. Please try again.');
            }
        }
    }

    function showBulkUploadModal() {
        const modalHtml = `
            <div id="bulkUploadModal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center; z-index: 1000;">
                <div style="background: white; border-radius: 12px; padding: 2rem; width: 90%; max-width: 700px; max-height: 90vh; overflow-y: auto;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                        <h3 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Bulk Upload Subjects</h3>
                        <button onclick="closeBulkUploadModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280;">&times;</button>
                    </div>
                    
                    <div style="margin-bottom: 2rem; padding: 1rem; background: #f0f9ff; border-radius: 8px; border: 1px solid #0ea5e9;">
                        <h4 style="color: #0c4a6e; margin-bottom: 0.5rem;">CSV Format Instructions:</h4>
                        <p style="color: #075985; font-size: 0.875rem; margin-bottom: 0.5rem;">
                            Upload a CSV file with the following columns (in order):
                        </p>
                        <code style="background: white; padding: 0.5rem; border-radius: 4px; display: block; font-size: 0.75rem;">
                            code,name,type,credits,periodsPerWeek,department,year,semester,description
                        </code>
                        <p style="color: #075985; font-size: 0.875rem; margin-top: 0.5rem;">
                            Type should be: theory, lab, or practical
                        </p>
                        <div style="margin-top: 1rem;">
                            <button onclick="downloadSampleCSV()" style="padding: 8px 16px; background: #059669; color: white; border: none; border-radius: 4px; font-size: 0.875rem; cursor: pointer;">
                                📄 Download Sample CSV Template
                            </button>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 1.5rem;">
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Select CSV File</label>
                        <input type="file" id="csvFile" accept=".csv" 
                               style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px;">
                    </div>
                    
                    <div style="display: flex; justify-content: flex-end; gap: 1rem;">
                        <button onclick="closeBulkUploadModal()" 
                                style="padding: 12px 24px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer;">
                            Cancel
                        </button>
                        <button onclick="processBulkUpload()" 
                                style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 6px; cursor: pointer;">
                            Upload Subjects
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }

    function closeBulkUploadModal() {
        const modal = document.getElementById('bulkUploadModal');
        if (modal) {
            modal.remove();
        }
    }

    async function processBulkUpload() {
        const fileInput = document.getElementById('csvFile');
        const file = fileInput.files[0];
        
        if (!file) {
            alert('Please select a CSV file.');
            return;
        }
        
        if (!file.name.toLowerCase().endsWith('.csv')) {
            alert('Please select a CSV file.');
            return;
        }
        
        try {
            const text = await file.text();
            const lines = text.split('\n').filter(line => line.trim());
            const headers = lines[0].split(',').map(h => h.trim());
            
            // Validate headers
            const expectedHeaders = ['code', 'name', 'type', 'credits', 'periodsPerWeek', 'department', 'year', 'semester', 'description'];
            if (headers.length < 8 || !expectedHeaders.slice(0, 8).every((h, i) => headers[i] === h)) {
                alert('Invalid CSV format. Please check the column headers.');
                return;
            }
            
            const subjects = [];
            for (let i = 1; i < lines.length; i++) {
                const values = lines[i].split(',').map(v => v.trim());
                if (values.length >= 8) {
                    subjects.push({
                        code: values[0],
                        name: values[1],
                        type: values[2],
                        credits: parseInt(values[3]),
                        periodsPerWeek: parseInt(values[4]),
                        department: values[5],
                        year: parseInt(values[6]),
                        semester: parseInt(values[7]),
                        description: values[8] || ''
                    });
                }
            }
            
            if (subjects.length === 0) {
                alert('No valid subjects found in the CSV file.');
                return;
            }
            
            // Upload subjects one by one
            let successCount = 0;
            let errorCount = 0;
            
            for (const subject of subjects) {
                try {
                    const result = await api.createSubject(subject);
                    if (result.success) {
                        successCount++;
                    } else {
                        errorCount++;
                        console.error(`Failed to create subject ${subject.code}:`, result.message);
                    }
                } catch (error) {
                    errorCount++;
                    console.error(`Error creating subject ${subject.code}:`, error);
                }
            }
            
            closeBulkUploadModal();
            await loadData();
            renderApp();
            
            alert(`Bulk upload completed!\nSuccessfully added: ${successCount} subjects\nErrors: ${errorCount} subjects`);
            
        } catch (error) {
            console.error('Bulk upload error:', error);
            alert('Failed to process CSV file. Please check the format and try again.');
        }
    }

    function downloadSampleCSV() {
        const csvContent = `code,name,type,credits,periodsPerWeek,department,year,semester,description
CS101,Programming Fundamentals,theory,3,4,Computer Science,1,1,Introduction to programming concepts and basic algorithms
CS102,Programming Lab,lab,2,3,Computer Science,1,1,Hands-on programming practice and implementation
CS103,Computer Organization,theory,3,4,Computer Science,1,2,Computer architecture and organization principles
EC101,Circuit Analysis,theory,3,4,Electronics,1,1,Basic electrical circuit analysis and theorems
EC102,Electronics Lab,lab,2,3,Electronics,1,1,Basic electronics experiments and measurements
ME101,Engineering Mechanics,theory,3,4,Mechanical,1,1,Statics and dynamics of mechanical systems
CE101,Surveying,theory,3,4,Civil,1,1,Land surveying techniques and instruments
IT101,Information Technology Fundamentals,theory,3,4,Information Technology,1,1,Basics of IT and computer systems`;

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'sample-subjects.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

    function exportSubjects() {
        const filteredSubjects = getFilteredSubjects();
        
        if (filteredSubjects.length === 0) {
            alert('No subjects to export. Please add subjects or adjust your filters.');
            return;
        }

        const headers = ['code', 'name', 'type', 'credits', 'periodsPerWeek', 'department', 'year', 'semester', 'description'];
        const csvContent = [
            headers.join(','),
            ...filteredSubjects.map(subject => [
                subject.code,
                `"${subject.name}"`,
                subject.type,
                subject.credits,
                subject.periodsPerWeek || '',
                `"${subject.department}"`,
                subject.year,
                subject.semester,
                `"${subject.description || ''}"`
            ].join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            
            const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
            link.setAttribute('download', `subjects-export-${timestamp}.csv`);
            
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            alert(`Successfully exported ${filteredSubjects.length} subjects to CSV file.`);
        }
    }

    function showSubjectStatistics() {
        const stats = {
            total: appData.subjects.length,
            byType: {},
            byDepartment: {},
            byYear: {},
            totalCredits: 0
        };

        appData.subjects.forEach(subject => {
            // Count by type
            stats.byType[subject.type] = (stats.byType[subject.type] || 0) + 1;
            
            // Count by department
            stats.byDepartment[subject.department] = (stats.byDepartment[subject.department] || 0) + 1;
            
            // Count by year
            stats.byYear[subject.year] = (stats.byYear[subject.year] || 0) + 1;
            
            // Sum credits
            stats.totalCredits += subject.credits || 0;
        });

        const modalHtml = `
            <div id="statsModal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center; z-index: 1000;">
                <div style="background: white; border-radius: 12px; padding: 2rem; width: 90%; max-width: 600px; max-height: 90vh; overflow-y: auto;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                        <h3 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Subject Statistics</h3>
                        <button onclick="closeStatsModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280;">&times;</button>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                        <div style="background: #f8fafc; padding: 1.5rem; border-radius: 8px;">
                            <h4 style="color: #1f2937; margin-bottom: 1rem; font-weight: 600;">Overall Statistics</h4>
                            <div style="margin-bottom: 0.5rem;"><strong>Total Subjects:</strong> ${stats.total}</div>
                            <div style="margin-bottom: 0.5rem;"><strong>Total Credits:</strong> ${stats.totalCredits}</div>
                            <div><strong>Average Credits/Subject:</strong> ${stats.total > 0 ? (stats.totalCredits / stats.total).toFixed(2) : 0}</div>
                        </div>
                        
                        <div style="background: #f0f9ff; padding: 1.5rem; border-radius: 8px;">
                            <h4 style="color: #1f2937; margin-bottom: 1rem; font-weight: 600;">By Type</h4>
                            ${Object.entries(stats.byType).map(([type, count]) => 
                                `<div style="margin-bottom: 0.5rem;"><strong>${type}:</strong> ${count}</div>`
                            ).join('')}
                        </div>
                        
                        <div style="background: #f0fdf4; padding: 1.5rem; border-radius: 8px;">
                            <h4 style="color: #1f2937; margin-bottom: 1rem; font-weight: 600;">By Department</h4>
                            ${Object.entries(stats.byDepartment).map(([dept, count]) => 
                                `<div style="margin-bottom: 0.5rem; font-size: 0.875rem;"><strong>${dept}:</strong> ${count}</div>`
                            ).join('')}
                        </div>
                        
                        <div style="background: #fef7ff; padding: 1.5rem; border-radius: 8px;">
                            <h4 style="color: #1f2937; margin-bottom: 1rem; font-weight: 600;">By Year</h4>
                            ${Object.entries(stats.byYear).map(([year, count]) => 
                                `<div style="margin-bottom: 0.5rem;"><strong>Year ${year}:</strong> ${count}</div>`
                            ).join('')}
                        </div>
                    </div>
                    
                    <div style="margin-top: 2rem; text-align: center;">
                        <button onclick="closeStatsModal()" style="padding: 12px 24px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer;">
                            Close
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }

    function closeStatsModal() {
        const modal = document.getElementById('statsModal');
        if (modal) {
            modal.remove();
        }
    }

    // Enhanced Faculty Management Functions
    let currentEditingFaculty = null;

    async function editFaculty(id) {
        const faculty = appData.faculty.find(f => f.id === id);
        if (faculty) {
            showAddFacultyModal(faculty);
        }
    }

    async function deleteFaculty(id) {
        const faculty = appData.faculty.find(f => f.id === id);
        if (faculty && confirm(`Are you sure you want to delete "${faculty.name}"?`)) {
            try {
                const result = await api.deleteFaculty(id);
                if (result && result.success) {
                    await loadData();
                    renderApp();
                    alert('Faculty member deleted successfully!');
                } else {
                    alert(`Error: ${result?.message || 'Failed to delete faculty member'}`);
                }
            } catch (error) {
                console.error('Delete error:', error);
                alert('Failed to delete faculty member. Please try again.');
            }
        }
    }

    function exportFaculty() {
        const filteredFaculty = getFilteredFaculty();
        
        if (filteredFaculty.length === 0) {
            alert('No faculty to export. Please add faculty or adjust your filters.');
            return;
        }

        const headers = ['employeeId', 'name', 'email', 'department', 'designation', 'phone', 'maxLecturesPerDay', 'specialization'];
        const csvContent = [
            headers.join(','),
            ...filteredFaculty.map(faculty => [
                faculty.employeeId,
                `"${faculty.name}"`,
                faculty.email,
                `"${faculty.department}"`,
                `"${faculty.designation || 'Professor'}"`,
                faculty.phone || '',
                faculty.maxLecturesPerDay || 6,
                `"${faculty.specialization || ''}"`
            ].join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            
            const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
            link.setAttribute('download', `faculty-export-${timestamp}.csv`);
            
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            alert(`Successfully exported ${filteredFaculty.length} faculty members to CSV file.`);
        }
    }

    function showFacultyStatistics() {
        const stats = {
            total: appData.faculty.length,
            byDepartment: {},
            byDesignation: {},
            totalMaxLectures: 0,
            avgMaxLectures: 0
        };

        appData.faculty.forEach(faculty => {
            // Count by department
            stats.byDepartment[faculty.department] = (stats.byDepartment[faculty.department] || 0) + 1;
            
            // Count by designation
            const designation = faculty.designation || 'Professor';
            stats.byDesignation[designation] = (stats.byDesignation[designation] || 0) + 1;
            
            // Sum max lectures
            stats.totalMaxLectures += faculty.maxLecturesPerDay || 6;
        });

        stats.avgMaxLectures = stats.total > 0 ? (stats.totalMaxLectures / stats.total).toFixed(1) : 0;

        const modalHtml = `
            <div id="facultyStatsModal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center; z-index: 1000;">
                <div style="background: white; border-radius: 12px; padding: 2rem; width: 90%; max-width: 700px; max-height: 90vh; overflow-y: auto;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                        <h3 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Faculty Statistics</h3>
                        <button onclick="closeFacultyStatsModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280;">&times;</button>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem;">
                        <div style="background: #f8fafc; padding: 1.5rem; border-radius: 8px;">
                            <h4 style="color: #1f2937; margin-bottom: 1rem; font-weight: 600;">Overall Statistics</h4>
                            <div style="margin-bottom: 0.5rem;"><strong>Total Faculty:</strong> ${stats.total}</div>
                            <div style="margin-bottom: 0.5rem;"><strong>Total Teaching Capacity:</strong> ${stats.totalMaxLectures} lectures/day</div>
                            <div><strong>Average Capacity:</strong> ${stats.avgMaxLectures} lectures/faculty/day</div>
                        </div>
                        
                        <div style="background: #f0f9ff; padding: 1.5rem; border-radius: 8px;">
                            <h4 style="color: #1f2937; margin-bottom: 1rem; font-weight: 600;">By Designation</h4>
                            ${Object.entries(stats.byDesignation).map(([designation, count]) => 
                                `<div style="margin-bottom: 0.5rem;"><strong>${designation}:</strong> ${count}</div>`
                            ).join('')}
                        </div>
                        
                        <div style="background: #f0fdf4; padding: 1.5rem; border-radius: 8px;">
                            <h4 style="color: #1f2937; margin-bottom: 1rem; font-weight: 600;">By Department</h4>
                            ${Object.entries(stats.byDepartment).map(([dept, count]) => 
                                `<div style="margin-bottom: 0.5rem; font-size: 0.875rem;"><strong>${dept}:</strong> ${count}</div>`
                            ).join('')}
                        </div>
                    </div>
                    
                    <div style="margin-top: 2rem; text-align: center;">
                        <button onclick="closeFacultyStatsModal()" style="padding: 12px 24px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer;">
                            Close
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }

    function closeFacultyStatsModal() {
        const modal = document.getElementById('facultyStatsModal');
        if (modal) {
            modal.remove();
        }
    }

    function showFacultyBulkUpload() {
        const modalHtml = `
            <div id="facultyBulkUploadModal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center; z-index: 1000;">
                <div style="background: white; border-radius: 12px; padding: 2rem; width: 90%; max-width: 700px; max-height: 90vh; overflow-y: auto;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                        <h3 style="font-size: 1.5rem; font-weight: 600; color: #1f2937;">Bulk Upload Faculty</h3>
                        <button onclick="closeFacultyBulkUpload()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #6b7280;">&times;</button>
                    </div>
                    
                    <div style="margin-bottom: 2rem; padding: 1rem; background: #f0f9ff; border-radius: 8px; border: 1px solid #0ea5e9;">
                        <h4 style="color: #0c4a6e; margin-bottom: 0.5rem;">CSV Format Instructions:</h4>
                        <p style="color: #075985; font-size: 0.875rem; margin-bottom: 0.5rem;">
                            Upload a CSV file with the following columns (in order):
                        </p>
                        <code style="background: white; padding: 0.5rem; border-radius: 4px; display: block; font-size: 0.75rem;">
                            employeeId,name,email,department,designation,phone,maxLecturesPerDay,specialization
                        </code>
                        <p style="color: #075985; font-size: 0.875rem; margin-top: 0.5rem;">
                            Designation options: Professor, Associate Professor, Assistant Professor, Lecturer, HOD
                        </p>
                        <div style="margin-top: 1rem;">
                            <button onclick="downloadFacultySampleCSV()" style="padding: 8px 16px; background: #059669; color: white; border: none; border-radius: 4px; font-size: 0.875rem; cursor: pointer;">
                                📄 Download Sample CSV Template
                            </button>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 1.5rem;">
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500; color: #374151;">Select CSV File</label>
                        <input type="file" id="facultyCsvFile" accept=".csv" 
                               style="width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 6px;">
                    </div>
                    
                    <div style="display: flex; justify-content: flex-end; gap: 1rem;">
                        <button onclick="closeFacultyBulkUpload()" 
                                style="padding: 12px 24px; background: #6b7280; color: white; border: none; border-radius: 6px; cursor: pointer;">
                            Cancel
                        </button>
                        <button onclick="processFacultyBulkUpload()" 
                                style="padding: 12px 24px; background: #10b981; color: white; border: none; border-radius: 6px; cursor: pointer;">
                            Upload Faculty
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }

    function closeFacultyBulkUpload() {
        const modal = document.getElementById('facultyBulkUploadModal');
        if (modal) {
            modal.remove();
        }
    }

    function downloadFacultySampleCSV() {
        const csvContent = `employeeId,name,email,department,designation,phone,maxLecturesPerDay,specialization
FAC001,Dr. John Smith,john.smith@college.edu,Computer Science,Professor,9876543210,6,Data Structures and Algorithms
FAC002,Prof. Sarah Johnson,sarah.johnson@college.edu,Electronics,Associate Professor,9876543211,5,Digital Signal Processing
FAC003,Dr. Michael Brown,michael.brown@college.edu,Mechanical,Assistant Professor,9876543212,6,Thermodynamics
FAC004,Prof. Emily Davis,emily.davis@college.edu,Civil,Professor,9876543213,5,Structural Engineering
FAC005,Dr. David Wilson,david.wilson@college.edu,Information Technology,HOD,9876543214,4,Network Security
FAC006,Prof. Lisa Anderson,lisa.anderson@college.edu,Computer Science,Lecturer,9876543215,7,Web Development
FAC007,Dr. Robert Taylor,robert.taylor@college.edu,Electronics,Professor,9876543216,6,VLSI Design
FAC008,Prof. Jennifer Martinez,jennifer.martinez@college.edu,Mechanical,Associate Professor,9876543217,5,Manufacturing Processes`;

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'sample-faculty.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

    async function processFacultyBulkUpload() {
        const fileInput = document.getElementById('facultyCsvFile');
        const file = fileInput.files[0];
        
        if (!file) {
            alert('Please select a CSV file.');
            return;
        }
        
        if (!file.name.toLowerCase().endsWith('.csv')) {
            alert('Please select a CSV file.');
            return;
        }
        
        try {
            const text = await file.text();
            const lines = text.split('\n').filter(line => line.trim());
            const headers = lines[0].split(',').map(h => h.trim());
            
            // Validate headers
            const expectedHeaders = ['employeeId', 'name', 'email', 'department', 'designation', 'phone', 'maxLecturesPerDay', 'specialization'];
            if (headers.length < 7 || !expectedHeaders.slice(0, 7).every((h, i) => headers[i] === h)) {
                alert('Invalid CSV format. Please check the column headers.');
                return;
            }
            
            const facultyMembers = [];
            for (let i = 1; i < lines.length; i++) {
                const values = lines[i].split(',').map(v => v.trim());
                if (values.length >= 7) {
                    facultyMembers.push({
                        employeeId: values[0],
                        name: values[1],
                        email: values[2],
                        department: values[3],
                        designation: values[4],
                        phone: values[5],
                        maxLecturesPerDay: parseInt(values[6]) || 6,
                        specialization: values[7] || ''
                    });
                }
            }
            
            if (facultyMembers.length === 0) {
                alert('No valid faculty records found in the CSV file.');
                return;
            }
            
            // Upload faculty members one by one
            let successCount = 0;
            let errorCount = 0;
            
            for (const faculty of facultyMembers) {
                try {
                    const result = await api.createFaculty(faculty);
                    if (result.success) {
                        successCount++;
                    } else {
                        errorCount++;
                        console.error(`Failed to create faculty ${faculty.employeeId}:`, result.message);
                    }
                } catch (error) {
                    errorCount++;
                    console.error(`Error creating faculty ${faculty.employeeId}:`, error);
                }
            }
            
            closeFacultyBulkUpload();
            await loadData();
            renderApp();
            
            alert(`Bulk upload completed!\nSuccessfully added: ${successCount} faculty members\nErrors: ${errorCount} faculty members`);
            
        } catch (error) {
            console.error('Faculty bulk upload error:', error);
            alert('Failed to process CSV file. Please check the format and try again.');
        }
    }

    // Allocation Summary Functions
    function showAllocationSummary() {
        const modal = document.getElementById('allocationSummaryModal');
        const content = document.getElementById('allocationSummaryContent');
        
        // Generate comprehensive allocation summary
        content.innerHTML = generateAllocationSummaryContent();
        modal.style.display = 'block';
    }

    function closeAllocationSummary() {
        document.getElementById('allocationSummaryModal').style.display = 'none';
    }

    function generateAllocationSummaryContent() {
        if (!appData.allocations || appData.allocations.length === 0) {
            return `
                <div style="text-align: center; padding: 3rem; color: #6b7280;">
                    <h4 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 1rem; color: #374151;">No Allocations Found</h4>
                    <p>Create faculty-subject allocations to view detailed assignment information.</p>
                </div>
            `;
        }

        // Group allocations by department and class
        const groupedAllocations = {};
        appData.allocations.forEach(allocation => {
            const key = `${allocation.department}_${allocation.year}_${allocation.semester}`;
            if (!groupedAllocations[key]) {
                groupedAllocations[key] = [];
            }
            groupedAllocations[key].push(allocation);
        });

        let summaryHTML = '';
        
        // Generate summary statistics
        const totalAllocations = appData.allocations.length;
        const totalAssignments = appData.allocations.reduce((sum, alloc) => 
            sum + (alloc.facultySubjects ? alloc.facultySubjects.length : 0), 0);
        const uniqueFaculty = new Set();
        const uniqueSubjects = new Set();
        
        appData.allocations.forEach(alloc => {
            if (alloc.facultySubjects) {
                alloc.facultySubjects.forEach(fs => {
                    uniqueFaculty.add(fs.facultyId);
                    uniqueSubjects.add(fs.subjectId);
                });
            }
        });

        summaryHTML += `
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 2rem; border-radius: 8px; margin-bottom: 2rem;">
                <h4 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 1rem;">Allocation Overview</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem;">
                    <div style="text-align: center;">
                        <div style="font-size: 2rem; font-weight: 700;">${totalAllocations}</div>
                        <div style="font-size: 0.875rem; opacity: 0.9;">Total Classes</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 2rem; font-weight: 700;">${totalAssignments}</div>
                        <div style="font-size: 0.875rem; opacity: 0.9;">Assignments</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 2rem; font-weight: 700;">${uniqueFaculty.size}</div>
                        <div style="font-size: 0.875rem; opacity: 0.9;">Faculty Involved</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 2rem; font-weight: 700;">${uniqueSubjects.size}</div>
                        <div style="font-size: 0.875rem; opacity: 0.9;">Subjects Assigned</div>
                    </div>
                </div>
            </div>
        `;

        // Generate detailed allocations by department
        Object.keys(groupedAllocations).forEach(key => {
            const [department, year, semester] = key.split('_');
            const allocations = groupedAllocations[key];
            
            summaryHTML += `
                <div style="background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 1.5rem; overflow: hidden;">
                    <div style="background: #f8fafc; padding: 1.5rem; border-bottom: 1px solid #e5e7eb;">
                        <h5 style="font-size: 1.125rem; font-weight: 600; color: #1f2937; margin-bottom: 0.5rem;">
                            ${department} - Year ${year}, Semester ${semester}
                        </h5>
                        <p style="color: #6b7280; font-size: 0.875rem;">
                            ${allocations.length} section(s) with allocations
                        </p>
                    </div>
                    <div style="padding: 1.5rem;">
                        ${allocations.map(allocation => `
                            <div style="margin-bottom: 2rem; padding-bottom: 1.5rem; border-bottom: 1px solid #f3f4f6;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                                    <h6 style="font-weight: 600; color: #374151;">Section ${allocation.section}</h6>
                                    <span style="background: #dbeafe; color: #1e40af; padding: 4px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600;">
                                        ${allocation.facultySubjects ? allocation.facultySubjects.length : 0} assignments
                                    </span>
                                </div>
                                
                                ${allocation.facultySubjects && allocation.facultySubjects.length > 0 ? `
                                    <div style="overflow-x: auto;">
                                        <table style="width: 100%; border-collapse: collapse; font-size: 0.875rem;">
                                            <thead>
                                                <tr style="background: #f9fafb;">
                                                    <th style="padding: 8px; border: 1px solid #e5e7eb; text-align: left; font-weight: 600;">Faculty</th>
                                                    <th style="padding: 8px; border: 1px solid #e5e7eb; text-align: left; font-weight: 600;">Subject</th>
                                                    <th style="padding: 8px; border: 1px solid #e5e7eb; text-align: center; font-weight: 600;">Type</th>
                                                    <th style="padding: 8px; border: 1px solid #e5e7eb; text-align: center; font-weight: 600;">Credits</th>
                                                    <th style="padding: 8px; border: 1px solid #e5e7eb; text-align: center; font-weight: 600;">Periods/Week</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                ${allocation.facultySubjects.map(fs => {
                                                    const faculty = appData.faculty.find(f => f.id === fs.facultyId) || {};
                                                    const subject = appData.subjects.find(s => s.id === fs.subjectId) || {};
                                                    return `
                                                        <tr>
                                                            <td style="padding: 8px; border: 1px solid #e5e7eb;">
                                                                <div style="font-weight: 600; color: #1f2937;">${faculty.name || 'Unknown Faculty'}</div>
                                                                <div style="font-size: 0.75rem; color: #6b7280;">${faculty.employeeId || 'N/A'}</div>
                                                                <div style="font-size: 0.75rem; color: #6b7280;">${faculty.designation || 'Faculty'}</div>
                                                            </td>
                                                            <td style="padding: 8px; border: 1px solid #e5e7eb;">
                                                                <div style="font-weight: 600; color: #1f2937;">${subject.name || 'Unknown Subject'}</div>
                                                                <div style="font-size: 0.75rem; color: #6b7280;">${subject.code || 'N/A'}</div>
                                                            </td>
                                                            <td style="padding: 8px; border: 1px solid #e5e7eb; text-align: center;">
                                                                <span style="padding: 2px 6px; border-radius: 3px; font-size: 0.75rem; font-weight: 600; background: ${getTypeColor(subject.type || 'theory').bg}; color: ${getTypeColor(subject.type || 'theory').text};">
                                                                    ${subject.type || 'Theory'}
                                                                </span>
                                                            </td>
                                                            <td style="padding: 8px; border: 1px solid #e5e7eb; text-align: center; color: #6b7280;">
                                                                ${subject.credits || 'N/A'}
                                                            </td>
                                                            <td style="padding: 8px; border: 1px solid #e5e7eb; text-align: center; color: #6b7280;">
                                                                ${subject.periodsPerWeek || 'N/A'}
                                                            </td>
                                                        </tr>
                                                    `;
                                                }).join('')}
                                            </tbody>
                                        </table>
                                    </div>
                                ` : `
                                    <div style="text-align: center; color: #6b7280; padding: 1rem; background: #f9fafb; border-radius: 6px;">
                                        No faculty-subject assignments for this section
                                    </div>
                                `}
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        });

        return summaryHTML;
    }

    // Event listeners
    function attachEventListeners() {
        // Keyboard shortcuts for desktop app
        document.addEventListener('keydown', (event) => {
            // Ctrl/Cmd + N: Add new item (subject or faculty)
            if ((event.ctrlKey || event.metaKey) && event.key === 'n') {
                event.preventDefault();
                const activeTab = document.querySelector('.nav-tab[style*="color: rgb(33, 150, 243)"]');
                if (activeTab?.dataset.tab === 'subjects') {
                    showAddSubjectModal();
                } else if (activeTab?.dataset.tab === 'faculty') {
                    showAddFacultyModal();
                }
            }
            
            // Ctrl/Cmd + E: Export data
            if ((event.ctrlKey || event.metaKey) && event.key === 'e') {
                event.preventDefault();
                const activeTab = document.querySelector('.nav-tab[style*="color: rgb(33, 150, 243)"]');
                if (activeTab?.dataset.tab === 'subjects') {
                    exportSubjects();
                } else if (activeTab?.dataset.tab === 'faculty') {
                    exportFaculty();
                }
            }
            
            // Ctrl/Cmd + I: Import data
            if ((event.ctrlKey || event.metaKey) && event.key === 'i') {
                event.preventDefault();
                const activeTab = document.querySelector('.nav-tab[style*="color: rgb(33, 150, 243)"]');
                if (activeTab?.dataset.tab === 'subjects') {
                    showBulkUploadModal();
                } else if (activeTab?.dataset.tab === 'faculty') {
                    showFacultyBulkUpload();
                }
            }
            
            // Ctrl/Cmd + S: Show statistics
            if ((event.ctrlKey || event.metaKey) && event.key === 's') {
                event.preventDefault();
                const activeTab = document.querySelector('.nav-tab[style*="color: rgb(33, 150, 243)"]');
                if (activeTab?.dataset.tab === 'subjects') {
                    showSubjectStatistics();
                } else if (activeTab?.dataset.tab === 'faculty') {
                    showFacultyStatistics();
                }
            }
            
            // Escape: Close modals
            if (event.key === 'Escape') {
                closeSubjectModal();
                closeBulkUploadModal();
                closeStatsModal();
                closeFacultyModal();
                closeFacultyStatsModal();
                closeFacultyBulkUpload();
            }
        });
    }

    // Make functions globally available
    window.handleLogin = handleLogin;
    window.handleLogout = handleLogout;
    window.handleGenerateTimetable = handleGenerateTimetable;
    window.setActiveTab = setActiveTab;
    window.showAddFacultyModal = showAddFacultyModal;
    window.closeFacultyModal = closeFacultyModal;
    window.saveFaculty = saveFaculty;
    window.showTimetableGenerator = showTimetableGenerator;
    window.showAddSubjectModal = showAddSubjectModal;
    window.closeSubjectModal = closeSubjectModal;
    window.saveSubject = saveSubject;
    window.editSubject = editSubject;
    window.deleteSubject = deleteSubject;
    window.filterSubjects = filterSubjects;
    window.updatePeriodsPerWeek = updatePeriodsPerWeek;
    window.showBulkUploadModal = showBulkUploadModal;
    window.closeBulkUploadModal = closeBulkUploadModal;
    window.processBulkUpload = processBulkUpload;
    window.downloadSampleCSV = downloadSampleCSV;
    window.exportSubjects = exportSubjects;
    window.showSubjectStatistics = showSubjectStatistics;
    window.closeStatsModal = closeStatsModal;
    window.filterFaculty = filterFaculty;
    window.editFaculty = editFaculty;
    window.deleteFaculty = deleteFaculty;
    window.exportFaculty = exportFaculty;
    window.showFacultyStatistics = showFacultyStatistics;
    window.closeFacultyStatsModal = closeFacultyStatsModal;
    window.showFacultyBulkUpload = showFacultyBulkUpload;
    window.closeFacultyBulkUpload = closeFacultyBulkUpload;
    window.downloadFacultySampleCSV = downloadFacultySampleCSV;
    window.processFacultyBulkUpload = processFacultyBulkUpload;
    window.setFacultyActiveTab = setFacultyActiveTab;
    window.toggleAllocationView = toggleAllocationView;
    window.toggleTimetableView = toggleTimetableView;
    window.exportTimetablePDF = exportTimetablePDF;
    // Ensure deleteTimetable is globally accessible
    window.deleteTimetable = deleteTimetable;
    window.showAllocationSummary = showAllocationSummary;
    window.closeAllocationSummary = closeAllocationSummary;
    
    // Load faculty-specific timetables
    async function loadFacultyTimetables() {
        try {
            if (!auth.isAuthenticated() || auth.currentUser.role !== 'faculty') {
                return;
            }
            
            const response = await fetch(`${API_BASE_URL}/api/timetables/faculty/${auth.currentUser.employeeId}`, {
                headers: {
                    'Authorization': `Bearer ${auth.getToken()}`
                }
            });
            
            const data = await response.json();
            if (data.success) {
                appData.facultyTimetables = data.data || [];
                console.log('Faculty timetables loaded:', appData.facultyTimetables.length);
            } else {
                console.warn('Failed to load faculty timetables:', data.message);
                appData.facultyTimetables = [];
            }
        } catch (error) {
            console.error('Error loading faculty timetables:', error);
            appData.facultyTimetables = [];
        }
    }
    
    // Refresh faculty timetable
    async function refreshFacultyTimetable() {
        await loadFacultyTimetables();
        if (currentView === 'faculty') {
            renderFacultyDashboard();
            setFacultyActiveTab('timetables');
        }
    }
    
    // Export faculty timetable as PDF
    async function exportFacultyTimetable() {
        try {
            if (!auth.isAuthenticated() || auth.currentUser.role !== 'faculty') {
                alert('Faculty authentication required');
                return;
            }
            
            const response = await fetch(`${API_BASE_URL}/api/timetables/faculty/${auth.currentUser.employeeId}/export`, {
                headers: {
                    'Authorization': `Bearer ${auth.getToken()}`
                }
            });
            
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `faculty_schedule_${auth.currentUser.employeeId}.pdf`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
            } else {
                const data = await response.json();
                alert(data.message || 'Failed to export timetable');
            }
        } catch (error) {
            console.error('Export faculty timetable error:', error);
            alert('Failed to export timetable. Please try again.');
        }
    }
    
    // Make functions globally available
    window.loadData = loadData;
    window.renderApp = renderApp;
    window.handleLogin = handleLogin;
    window.toggleLoginFields = toggleLoginFields;
    window.loadFacultyTimetables = loadFacultyTimetables;
    window.refreshFacultyTimetable = refreshFacultyTimetable;
    window.exportFacultyTimetable = exportFacultyTimetable;
    
    // Initialize app when DOM is loaded
    document.addEventListener('DOMContentLoaded', () => {
        console.log('DOM loaded, initializing SmartScheduler...');
        try {
            initApp();
        } catch (error) {
            console.error('Error initializing app:', error);
            document.getElementById('root').innerHTML = `
                <div style="text-align: center; padding: 2rem; color: #dc2626;">
                    <h2>Application Error</h2>
                    <p>Failed to initialize SmartScheduler. Please refresh the page.</p>
                    <p style="font-family: monospace; font-size: 0.875rem; margin-top: 1rem;">${error.message}</p>
                </div>
            `;
        }
    });
    
    // Fallback initialization if DOMContentLoaded already fired
    if (document.readyState === 'loading') {
        // DOM hasn't loaded yet
    } else {
        // DOM has already loaded
        console.log('DOM already loaded, initializing SmartScheduler...');
        try {
            initApp();
        } catch (error) {
            console.error('Error initializing app:', error);
            document.getElementById('root').innerHTML = `
                <div style="text-align: center; padding: 2rem; color: #dc2626;">
                    <h2>Application Error</h2>
                    <p>Failed to initialize SmartScheduler. Please refresh the page.</p>
                    <p style="font-family: monospace; font-size: 0.875rem; margin-top: 1rem;">${error.message}</p>
                </div>
            `;
        }
    }
    
})(); // End of IIFE