// Authentication utility functions

// Token management
export const getToken = () => {
  return localStorage.getItem('token');
};

export const setToken = (token) => {
  localStorage.setItem('token', token);
};

export const removeToken = () => {
  localStorage.removeItem('token');
};

export const isTokenExpired = (token) => {
  if (!token) return true;
  
  try {
    // Simple JWT expiration check (basic implementation)
    const payload = JSON.parse(atob(token.split('.')[1]));
    const currentTime = Date.now() / 1000;
    return payload.exp < currentTime;
  } catch (error) {
    // If token is malformed, consider it expired
    return true;
  }
};

export const isAuthenticated = () => {
  const token = getToken();
  return token && !isTokenExpired(token);
};

// User data management
export const getCurrentUserFromToken = (token) => {
  if (!token) return null;
  
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return {
      userId: payload.userId,
      exp: payload.exp,
      iat: payload.iat
    };
  } catch (error) {
    console.error('Error parsing token:', error);
    return null;
  }
};

// Role-based access control
export const hasRole = (user, role) => {
  return user && user.role === role;
};

export const isAdmin = (user) => {
  return hasRole(user, 'admin');
};

export const isFaculty = (user) => {
  return hasRole(user, 'faculty');
};

export const canAccessAdminFeatures = (user) => {
  return isAdmin(user);
};

export const canAccessFacultyFeatures = (user) => {
  return isFaculty(user) || isAdmin(user);
};

// Permission checks for specific actions
export const canCreateFaculty = (user) => {
  return isAdmin(user);
};

export const canCreateSubject = (user) => {
  return isAdmin(user);
};

export const canCreateAllocation = (user) => {
  return isAdmin(user);
};

export const canGenerateTimetable = (user) => {
  return isAdmin(user);
};

export const canViewAllTimetables = (user) => {
  return isAdmin(user);
};

export const canViewFacultyTimetable = (user, facultyId) => {
  if (isAdmin(user)) return true;
  if (isFaculty(user)) {
    // Faculty can only view their own timetable
    return user.facultyDetails && user.facultyDetails._id === facultyId;
  }
  return false;
};

export const canEditFaculty = (user, facultyId) => {
  if (isAdmin(user)) return true;
  if (isFaculty(user)) {
    // Faculty can only edit their own profile
    return user.facultyDetails && user.facultyDetails._id === facultyId;
  }
  return false;
};

// Session management
export const getCurrentUser = async () => {
  try {
    const token = getToken();
    if (!token || isTokenExpired(token)) {
      removeToken();
      return null;
    }

    // Import the API function here to avoid circular dependency
    const { getCurrentUser: fetchCurrentUser } = await import('../services/api');
    const response = await fetchCurrentUser();
    
    if (response.success) {
      return response.data;
    }
    
    return null;
  } catch (error) {
    console.error('Error getting current user:', error);
    removeToken();
    return null;
  }
};

export const login = async (credentials) => {
  try {
    // Import the API function here to avoid circular dependency
    const { login: apiLogin } = await import('../services/api');
    const response = await apiLogin(credentials);
    
    if (response.success && response.data.token) {
      setToken(response.data.token);
      return {
        success: true,
        user: response.data.user,
        token: response.data.token
      };
    }
    
    return {
      success: false,
      message: response.message || 'Login failed'
    };
  } catch (error) {
    console.error('Login error:', error);
    return {
      success: false,
      message: error.message || 'Login failed'
    };
  }
};

export const logout = () => {
  removeToken();
  // Clear any other stored user data
  localStorage.removeItem('user');
  
  // Redirect to login page
  window.location.href = '/';
};

// Auto-logout on token expiration
export const setupAutoLogout = () => {
  const checkTokenExpiration = () => {
    const token = getToken();
    if (token && isTokenExpired(token)) {
      logout();
    }
  };

  // Check every minute
  const interval = setInterval(checkTokenExpiration, 60000);
  
  // Also check when the page becomes visible
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
      checkTokenExpiration();
    }
  });

  return () => {
    clearInterval(interval);
  };
};

// Password validation
export const validatePassword = (password) => {
  const errors = [];
  
  if (!password) {
    errors.push('Password is required');
    return { isValid: false, errors };
  }
  
  if (password.length < 6) {
    errors.push('Password must be at least 6 characters long');
  }
  
  if (!/(?=.*[a-z])/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }
  
  if (!/(?=.*[A-Z])/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }
  
  if (!/(?=.*\d)/.test(password)) {
    errors.push('Password must contain at least one number');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

// Email validation
export const validateEmail = (email) => {
  if (!email) {
    return { isValid: false, errors: ['Email is required'] };
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { isValid: false, errors: ['Invalid email format'] };
  }
  
  return { isValid: true, errors: [] };
};

// Employee ID validation
export const validateEmployeeId = (employeeId) => {
  if (!employeeId) {
    return { isValid: false, errors: ['Employee ID is required'] };
  }
  
  if (employeeId.length < 3) {
    return { isValid: false, errors: ['Employee ID must be at least 3 characters'] };
  }
  
  return { isValid: true, errors: [] };
};

// Form validation helpers
export const validateLoginForm = (formData) => {
  const errors = {};
  
  if (formData.loginType === 'email') {
    const emailValidation = validateEmail(formData.email);
    if (!emailValidation.isValid) {
      errors.email = emailValidation.errors[0];
    }
  } else {
    const employeeIdValidation = validateEmployeeId(formData.employeeId);
    if (!employeeIdValidation.isValid) {
      errors.employeeId = employeeIdValidation.errors[0];
    }
  }
  
  if (!formData.password) {
    errors.password = 'Password is required';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

export const validateRegistrationForm = (formData) => {
  const errors = {};
  
  const emailValidation = validateEmail(formData.email);
  if (!emailValidation.isValid) {
    errors.email = emailValidation.errors[0];
  }
  
  const passwordValidation = validatePassword(formData.password);
  if (!passwordValidation.isValid) {
    errors.password = passwordValidation.errors[0];
  }
  
  if (!formData.name || formData.name.trim().length < 2) {
    errors.name = 'Name must be at least 2 characters long';
  }
  
  if (!formData.role) {
    errors.role = 'Role is required';
  }
  
  if (formData.role === 'faculty') {
    const employeeIdValidation = validateEmployeeId(formData.employeeId);
    if (!employeeIdValidation.isValid) {
      errors.employeeId = employeeIdValidation.errors[0];
    }
    
    if (!formData.department) {
      errors.department = 'Department is required for faculty';
    }
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Local storage helpers
export const saveUserData = (userData) => {
  localStorage.setItem('user', JSON.stringify(userData));
};

export const getUserData = () => {
  try {
    const userData = localStorage.getItem('user');
    return userData ? JSON.parse(userData) : null;
  } catch (error) {
    console.error('Error parsing user data:', error);
    return null;
  }
};

export const clearUserData = () => {
  localStorage.removeItem('user');
};

// Authentication state hooks (for React components)
export const useAuthState = () => {
  const [isLoggedIn, setIsLoggedIn] = React.useState(isAuthenticated());
  const [user, setUser] = React.useState(getUserData());
  
  React.useEffect(() => {
    const checkAuth = async () => {
      if (isAuthenticated()) {
        const currentUser = await getCurrentUser();
        if (currentUser) {
          setUser(currentUser);
          saveUserData(currentUser);
          setIsLoggedIn(true);
        } else {
          setUser(null);
          clearUserData();
          setIsLoggedIn(false);
        }
      } else {
        setUser(null);
        clearUserData();
        setIsLoggedIn(false);
      }
    };
    
    checkAuth();
  }, []);
  
  return { isLoggedIn, user, setUser, setIsLoggedIn };
};

// Route protection helper
export const requireAuth = (WrappedComponent, requiredRole = null) => {
  return function AuthenticatedComponent(props) {
    const { isLoggedIn, user } = useAuthState();
    
    if (!isLoggedIn) {
      return <div>Redirecting to login...</div>;
    }
    
    if (requiredRole && !hasRole(user, requiredRole)) {
      return <div>Access denied. Insufficient permissions.</div>;
    }
    
    return <WrappedComponent {...props} user={user} />;
  };
};

// Error handling for authentication
export const handleAuthError = (error) => {
  if (error.message.includes('401') || error.message.includes('Unauthorized')) {
    logout();
    return 'Session expired. Please login again.';
  }
  
  if (error.message.includes('403') || error.message.includes('Forbidden')) {
    return 'Access denied. You do not have permission to perform this action.';
  }
  
  return error.message || 'Authentication error occurred.';
};

// Constants
export const ROLES = {
  ADMIN: 'admin',
  FACULTY: 'faculty'
};

export const PERMISSIONS = {
  CREATE_FACULTY: 'create_faculty',
  EDIT_FACULTY: 'edit_faculty',
  DELETE_FACULTY: 'delete_faculty',
  CREATE_SUBJECT: 'create_subject',
  EDIT_SUBJECT: 'edit_subject',
  DELETE_SUBJECT: 'delete_subject',
  CREATE_ALLOCATION: 'create_allocation',
  EDIT_ALLOCATION: 'edit_allocation',
  DELETE_ALLOCATION: 'delete_allocation',
  GENERATE_TIMETABLE: 'generate_timetable',
  VIEW_ALL_TIMETABLES: 'view_all_timetables',
  EXPORT_TIMETABLES: 'export_timetables'
};

// Permission mapping
export const ROLE_PERMISSIONS = {
  [ROLES.ADMIN]: [
    PERMISSIONS.CREATE_FACULTY,
    PERMISSIONS.EDIT_FACULTY,
    PERMISSIONS.DELETE_FACULTY,
    PERMISSIONS.CREATE_SUBJECT,
    PERMISSIONS.EDIT_SUBJECT,
    PERMISSIONS.DELETE_SUBJECT,
    PERMISSIONS.CREATE_ALLOCATION,
    PERMISSIONS.EDIT_ALLOCATION,
    PERMISSIONS.DELETE_ALLOCATION,
    PERMISSIONS.GENERATE_TIMETABLE,
    PERMISSIONS.VIEW_ALL_TIMETABLES,
    PERMISSIONS.EXPORT_TIMETABLES
  ],
  [ROLES.FACULTY]: [
    PERMISSIONS.EXPORT_TIMETABLES // Faculty can export their own timetables
  ]
};

export const hasPermission = (user, permission) => {
  if (!user || !user.role) return false;
  
  const rolePermissions = ROLE_PERMISSIONS[user.role] || [];
  return rolePermissions.includes(permission);
};

// Default export
export default {
  // Token management
  getToken,
  setToken,
  removeToken,
  isTokenExpired,
  isAuthenticated,
  
  // User management
  getCurrentUser,
  login,
  logout,
  
  // Role and permission checks
  hasRole,
  isAdmin,
  isFaculty,
  hasPermission,
  canAccessAdminFeatures,
  canAccessFacultyFeatures,
  
  // Validation
  validatePassword,
  validateEmail,
  validateEmployeeId,
  validateLoginForm,
  validateRegistrationForm,
  
  // Session management
  setupAutoLogout,
  saveUserData,
  getUserData,
  clearUserData,
  
  // Error handling
  handleAuthError,
  
  // Constants
  ROLES,
  PERMISSIONS
};
