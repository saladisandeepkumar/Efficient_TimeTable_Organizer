import React, { useState, useEffect } from 'react';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import FacultyDashboard from './components/FacultyDashboard';
import { getCurrentUser } from './utils/auth';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      const currentUser = await getCurrentUser();
      setUser(currentUser);
    } catch (error) {
      console.log('Not authenticated');
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = (userData) => {
    setUser(userData);
    setError(null);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
    setError(null);
  };

  if (loading) {
    return (
      <div className="app-loading">
        <div className="loading-spinner"></div>
        <p>Loading SmartScheduler...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="app-error">
        <div className="error-content">
          <i className="fas fa-exclamation-triangle"></i>
          <h2>Something went wrong</h2>
          <p>{error}</p>
          <button 
            className="btn btn-primary"
            onClick={() => window.location.reload()}
          >
            Reload Page
          </button>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={handleLogin} setError={setError} />;
  }

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-content">
          <div className="logo-section">
            <i className="fas fa-calendar-alt"></i>
            <h1>SmartScheduler</h1>
          </div>
          
          <div className="user-section">
            <div className="user-info">
              <span className="user-name">{user.name}</span>
              <span className="user-role">{user.role}</span>
            </div>
            <button 
              className="btn btn-outline"
              onClick={handleLogout}
              title="Logout"
            >
              <i className="fas fa-sign-out-alt"></i>
            </button>
          </div>
        </div>
      </header>

      <main className="app-main">
        {user.role === 'admin' ? (
          <AdminDashboard user={user} />
        ) : (
          <FacultyDashboard user={user} />
        )}
      </main>

      <footer className="app-footer">
        <div className="footer-content">
          <p>&copy; 2024 SmartScheduler. All rights reserved.</p>
          <p>College Timetable Generator with Automated Scheduling</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
