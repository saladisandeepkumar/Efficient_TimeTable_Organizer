import React, { useState, useEffect } from 'react';
import { 
  getFaculty, 
  getSubjects, 
  createFaculty, 
  createSubject, 
  getAllocations,
  createAllocation,
  updateAllocation,
  addFacultySubject,
  removeFacultySubject
} from '../services/api';

const FacultyAllocation = ({ onUpdate }) => {
  const [activeSection, setActiveSection] = useState('view');
  const [faculty, setFaculty] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [allocations, setAllocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Form states
  const [facultyForm, setFacultyForm] = useState({
    employeeId: '',
    name: '',
    email: '',
    department: '',
    designation: 'Assistant Professor',
    maxLecturesPerDay: 4
  });

  const [subjectForm, setSubjectForm] = useState({
    code: '',
    name: '',
    department: '',
    year: 1,
    semester: 1,
    credits: 3,
    type: 'theory',
    periodsPerWeek: 4
  });

  const [allocationForm, setAllocationForm] = useState({
    department: '',
    year: 1,
    semester: 1,
    section: '',
    facultySubjects: []
  });

  const [selectedAllocation, setSelectedAllocation] = useState(null);

  const departments = ['CSE', 'ECE', 'EEE', 'MECH', 'CIVIL', 'IT'];
  const years = [1, 2, 3, 4];
  const semesters = [1, 2];
  const sections = ['A', 'B', 'C', 'D'];

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [facultyRes, subjectsRes, allocationsRes] = await Promise.all([
        getFaculty(),
        getSubjects(),
        getAllocations()
      ]);

      setFaculty(facultyRes.data || []);
      setSubjects(subjectsRes.data || []);
      setAllocations(allocationsRes.data || []);
      setError('');
    } catch (error) {
      console.error('Data load error:', error);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleFacultySubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await createFaculty(facultyForm);
      if (response.success) {
        setSuccess('Faculty created successfully');
        setFacultyForm({
          employeeId: '',
          name: '',
          email: '',
          department: '',
          designation: 'Assistant Professor',
          maxLecturesPerDay: 4
        });
        loadData();
        if (onUpdate) onUpdate();
      }
    } catch (error) {
      setError(error.message || 'Failed to create faculty');
    }
  };

  const handleSubjectSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await createSubject(subjectForm);
      if (response.success) {
        setSuccess('Subject created successfully');
        setSubjectForm({
          code: '',
          name: '',
          department: '',
          year: 1,
          semester: 1,
          credits: 3,
          type: 'theory',
          periodsPerWeek: 4
        });
        loadData();
        if (onUpdate) onUpdate();
      }
    } catch (error) {
      setError(error.message || 'Failed to create subject');
    }
  };

  const handleAllocationSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedAllocation) {
        // Update existing allocation
        const response = await updateAllocation(selectedAllocation._id, allocationForm);
        if (response.success) {
          setSuccess('Allocation updated successfully');
        }
      } else {
        // Create new allocation
        const response = await createAllocation(allocationForm);
        if (response.success) {
          setSuccess('Allocation created successfully');
        }
      }

      setAllocationForm({
        department: '',
        year: 1,
        semester: 1,
        section: '',
        facultySubjects: []
      });
      setSelectedAllocation(null);
      loadData();
      if (onUpdate) onUpdate();
    } catch (error) {
      setError(error.message || 'Failed to save allocation');
    }
  };

  const addFacultySubjectPair = () => {
    setAllocationForm(prev => ({
      ...prev,
      facultySubjects: [...prev.facultySubjects, { facultyId: '', subjectId: '' }]
    }));
  };

  const removeFacultySubjectPair = (index) => {
    setAllocationForm(prev => ({
      ...prev,
      facultySubjects: prev.facultySubjects.filter((_, i) => i !== index)
    }));
  };

  const updateFacultySubjectPair = (index, field, value) => {
    setAllocationForm(prev => ({
      ...prev,
      facultySubjects: prev.facultySubjects.map((pair, i) => 
        i === index ? { ...pair, [field]: value } : pair
      )
    }));
  };

  const getFilteredSubjects = (department, year, semester) => {
    return subjects.filter(subject => 
      subject.department === department && 
      subject.year === year && 
      subject.semester === semester
    );
  };

  const getFilteredFaculty = (department) => {
    return faculty.filter(f => f.department === department);
  };

  const editAllocation = (allocation) => {
    setSelectedAllocation(allocation);
    setAllocationForm({
      department: allocation.department,
      year: allocation.year,
      semester: allocation.semester,
      section: allocation.section,
      facultySubjects: allocation.facultySubjects || []
    });
    setActiveSection('allocate');
  };

  const cancelEdit = () => {
    setSelectedAllocation(null);
    setAllocationForm({
      department: '',
      year: 1,
      semester: 1,
      section: '',
      facultySubjects: []
    });
  };

  const clearMessages = () => {
    setError('');
    setSuccess('');
  };

  if (loading) {
    return (
      <div className="allocation-loading">
        <div className="loading-spinner"></div>
        <p>Loading faculty allocation data...</p>
      </div>
    );
  }

  return (
    <div className="faculty-allocation">
      {/* Section Navigation */}
      <div className="section-nav">
        <button
          className={`nav-btn ${activeSection === 'view' ? 'active' : ''}`}
          onClick={() => { setActiveSection('view'); clearMessages(); }}
        >
          <i className="fas fa-list"></i>
          View Allocations
        </button>
        <button
          className={`nav-btn ${activeSection === 'allocate' ? 'active' : ''}`}
          onClick={() => { setActiveSection('allocate'); clearMessages(); }}
        >
          <i className="fas fa-tasks"></i>
          Create Allocation
        </button>
        <button
          className={`nav-btn ${activeSection === 'faculty' ? 'active' : ''}`}
          onClick={() => { setActiveSection('faculty'); clearMessages(); }}
        >
          <i className="fas fa-user-plus"></i>
          Add Faculty
        </button>
        <button
          className={`nav-btn ${activeSection === 'subject' ? 'active' : ''}`}
          onClick={() => { setActiveSection('subject'); clearMessages(); }}
        >
          <i className="fas fa-book"></i>
          Add Subject
        </button>
      </div>

      {/* Alerts */}
      {error && (
        <div className="alert alert-error">
          <i className="fas fa-exclamation-triangle"></i>
          {error}
          <button onClick={clearMessages} className="alert-close">×</button>
        </div>
      )}

      {success && (
        <div className="alert alert-success">
          <i className="fas fa-check-circle"></i>
          {success}
          <button onClick={clearMessages} className="alert-close">×</button>
        </div>
      )}

      {/* View Allocations */}
      {activeSection === 'view' && (
        <div className="allocations-view fade-in">
          <div className="section-header">
            <h3>Faculty Allocations</h3>
            <p>Manage faculty-subject assignments for different classes</p>
          </div>

          {allocations.length === 0 ? (
            <div className="empty-state">
              <i className="fas fa-tasks"></i>
              <h4>No Allocations Found</h4>
              <p>Start by creating your first faculty-subject allocation</p>
              <button 
                className="btn btn-primary"
                onClick={() => setActiveSection('allocate')}
              >
                Create Allocation
              </button>
            </div>
          ) : (
            <div className="allocations-grid">
              {allocations.map(allocation => (
                <div key={allocation._id} className="allocation-card">
                  <div className="allocation-header">
                    <h4>
                      {allocation.department} {allocation.year}-{allocation.section}
                    </h4>
                    <span className="semester-badge">
                      Semester {allocation.semester}
                    </span>
                  </div>

                  <div className="allocation-content">
                    <div className="faculty-subjects">
                      {allocation.facultySubjects && allocation.facultySubjects.length > 0 ? (
                        allocation.facultySubjects.map((fs, index) => {
                          const facultyMember = faculty.find(f => f._id === fs.facultyId);
                          const subject = subjects.find(s => s._id === fs.subjectId);
                          
                          return (
                            <div key={index} className="faculty-subject-item">
                              <div className="faculty-info">
                                <i className="fas fa-user"></i>
                                <span>{facultyMember?.name || 'Unknown Faculty'}</span>
                              </div>
                              <div className="subject-info">
                                <i className="fas fa-book"></i>
                                <span>{subject?.name || 'Unknown Subject'}</span>
                                <span className="subject-type">{subject?.type}</span>
                              </div>
                            </div>
                          );
                        })
                      ) : (
                        <p className="no-assignments">No faculty-subject assignments</p>
                      )}
                    </div>
                  </div>

                  <div className="allocation-actions">
                    <button 
                      className="btn btn-sm btn-outline"
                      onClick={() => editAllocation(allocation)}
                    >
                      <i className="fas fa-edit"></i>
                      Edit
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Create/Edit Allocation */}
      {activeSection === 'allocate' && (
        <div className="allocation-form-section fade-in">
          <div className="section-header">
            <h3>
              {selectedAllocation ? 'Edit Allocation' : 'Create New Allocation'}
            </h3>
            <p>Assign faculty members to subjects for a specific class</p>
          </div>

          <form onSubmit={handleAllocationSubmit} className="allocation-form">
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Department</label>
                <select
                  value={allocationForm.department}
                  onChange={(e) => setAllocationForm(prev => ({ 
                    ...prev, 
                    department: e.target.value,
                    facultySubjects: [] // Reset when department changes
                  }))}
                  className="form-select"
                  required
                >
                  <option value="">Select Department</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Year</label>
                <select
                  value={allocationForm.year}
                  onChange={(e) => setAllocationForm(prev => ({ 
                    ...prev, 
                    year: parseInt(e.target.value),
                    facultySubjects: [] // Reset when year changes
                  }))}
                  className="form-select"
                  required
                >
                  {years.map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Semester</label>
                <select
                  value={allocationForm.semester}
                  onChange={(e) => setAllocationForm(prev => ({ 
                    ...prev, 
                    semester: parseInt(e.target.value),
                    facultySubjects: [] // Reset when semester changes
                  }))}
                  className="form-select"
                  required
                >
                  {semesters.map(semester => (
                    <option key={semester} value={semester}>{semester}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Section</label>
                <select
                  value={allocationForm.section}
                  onChange={(e) => setAllocationForm(prev => ({ ...prev, section: e.target.value }))}
                  className="form-select"
                  required
                >
                  <option value="">Select Section</option>
                  {sections.map(section => (
                    <option key={section} value={section}>{section}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Faculty-Subject Assignments */}
            <div className="faculty-subjects-section">
              <div className="section-header">
                <h4>Faculty-Subject Assignments</h4>
                <button
                  type="button"
                  className="btn btn-sm btn-primary"
                  onClick={addFacultySubjectPair}
                  disabled={!allocationForm.department}
                >
                  <i className="fas fa-plus"></i>
                  Add Assignment
                </button>
              </div>

              {allocationForm.facultySubjects.map((pair, index) => (
                <div key={index} className="faculty-subject-pair">
                  <div className="pair-row">
                    <div className="form-group">
                      <label className="form-label">Faculty</label>
                      <select
                        value={pair.facultyId}
                        onChange={(e) => updateFacultySubjectPair(index, 'facultyId', e.target.value)}
                        className="form-select"
                        required
                      >
                        <option value="">Select Faculty</option>
                        {getFilteredFaculty(allocationForm.department).map(f => (
                          <option key={f._id} value={f._id}>
                            {f.name} ({f.employeeId})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Subject</label>
                      <select
                        value={pair.subjectId}
                        onChange={(e) => updateFacultySubjectPair(index, 'subjectId', e.target.value)}
                        className="form-select"
                        required
                      >
                        <option value="">Select Subject</option>
                        {getFilteredSubjects(allocationForm.department, allocationForm.year, allocationForm.semester).map(s => (
                          <option key={s._id} value={s._id}>
                            {s.name} ({s.code}) - {s.type}
                          </option>
                        ))}
                      </select>
                    </div>

                    <button
                      type="button"
                      className="btn btn-sm btn-danger remove-btn"
                      onClick={() => removeFacultySubjectPair(index)}
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </div>
              ))}

              {allocationForm.facultySubjects.length === 0 && (
                <div className="no-assignments-placeholder">
                  <i className="fas fa-info-circle"></i>
                  <p>No faculty-subject assignments added yet. Click "Add Assignment" to start.</p>
                </div>
              )}
            </div>

            <div className="form-actions">
              {selectedAllocation && (
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={cancelEdit}
                >
                  Cancel
                </button>
              )}
              <button
                type="submit"
                className="btn btn-primary"
                disabled={allocationForm.facultySubjects.length === 0}
              >
                <i className="fas fa-save"></i>
                {selectedAllocation ? 'Update Allocation' : 'Create Allocation'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Faculty */}
      {activeSection === 'faculty' && (
        <div className="faculty-form-section fade-in">
          <div className="section-header">
            <h3>Add New Faculty</h3>
            <p>Register a new faculty member in the system</p>
          </div>

          <form onSubmit={handleFacultySubmit} className="faculty-form">
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Employee ID</label>
                <input
                  type="text"
                  value={facultyForm.employeeId}
                  onChange={(e) => setFacultyForm(prev => ({ ...prev, employeeId: e.target.value }))}
                  className="form-input"
                  placeholder="Enter employee ID"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Full Name</label>
                <input
                  type="text"
                  value={facultyForm.name}
                  onChange={(e) => setFacultyForm(prev => ({ ...prev, name: e.target.value }))}
                  className="form-input"
                  placeholder="Enter full name"
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Email</label>
                <input
                  type="email"
                  value={facultyForm.email}
                  onChange={(e) => setFacultyForm(prev => ({ ...prev, email: e.target.value }))}
                  className="form-input"
                  placeholder="Enter email address"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Department</label>
                <select
                  value={facultyForm.department}
                  onChange={(e) => setFacultyForm(prev => ({ ...prev, department: e.target.value }))}
                  className="form-select"
                  required
                >
                  <option value="">Select Department</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Designation</label>
                <select
                  value={facultyForm.designation}
                  onChange={(e) => setFacultyForm(prev => ({ ...prev, designation: e.target.value }))}
                  className="form-select"
                  required
                >
                  <option value="Assistant Professor">Assistant Professor</option>
                  <option value="Associate Professor">Associate Professor</option>
                  <option value="Professor">Professor</option>
                  <option value="HOD">Head of Department</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Max Lectures Per Day</label>
                <select
                  value={facultyForm.maxLecturesPerDay}
                  onChange={(e) => setFacultyForm(prev => ({ ...prev, maxLecturesPerDay: parseInt(e.target.value) }))}
                  className="form-select"
                  required
                >
                  <option value={3}>3 lectures</option>
                  <option value={4}>4 lectures</option>
                  <option value={5}>5 lectures</option>
                  <option value={6}>6 lectures</option>
                </select>
              </div>
            </div>

            <div className="form-actions">
              <button type="submit" className="btn btn-primary">
                <i className="fas fa-user-plus"></i>
                Add Faculty
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Subject */}
      {activeSection === 'subject' && (
        <div className="subject-form-section fade-in">
          <div className="section-header">
            <h3>Add New Subject</h3>
            <p>Create a new subject in the system</p>
          </div>

          <form onSubmit={handleSubjectSubmit} className="subject-form">
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Subject Code</label>
                <input
                  type="text"
                  value={subjectForm.code}
                  onChange={(e) => setSubjectForm(prev => ({ ...prev, code: e.target.value.toUpperCase() }))}
                  className="form-input"
                  placeholder="e.g., CSE101"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Subject Name</label>
                <input
                  type="text"
                  value={subjectForm.name}
                  onChange={(e) => setSubjectForm(prev => ({ ...prev, name: e.target.value }))}
                  className="form-input"
                  placeholder="Enter subject name"
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Department</label>
                <select
                  value={subjectForm.department}
                  onChange={(e) => setSubjectForm(prev => ({ ...prev, department: e.target.value }))}
                  className="form-select"
                  required
                >
                  <option value="">Select Department</option>
                  {departments.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Year</label>
                <select
                  value={subjectForm.year}
                  onChange={(e) => setSubjectForm(prev => ({ ...prev, year: parseInt(e.target.value) }))}
                  className="form-select"
                  required
                >
                  {years.map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Semester</label>
                <select
                  value={subjectForm.semester}
                  onChange={(e) => setSubjectForm(prev => ({ ...prev, semester: parseInt(e.target.value) }))}
                  className="form-select"
                  required
                >
                  {semesters.map(semester => (
                    <option key={semester} value={semester}>{semester}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Subject Type</label>
                <select
                  value={subjectForm.type}
                  onChange={(e) => setSubjectForm(prev => ({ 
                    ...prev, 
                    type: e.target.value,
                    periodsPerWeek: e.target.value === 'lab' ? 3 : 4 // Auto-adjust periods for labs
                  }))}
                  className="form-select"
                  required
                >
                  <option value="theory">Theory</option>
                  <option value="lab">Lab</option>
                  <option value="practical">Practical</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Credits</label>
                <input
                  type="number"
                  value={subjectForm.credits}
                  onChange={(e) => setSubjectForm(prev => ({ ...prev, credits: parseInt(e.target.value) }))}
                  className="form-input"
                  min="1"
                  max="6"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Periods Per Week</label>
                <input
                  type="number"
                  value={subjectForm.periodsPerWeek}
                  onChange={(e) => setSubjectForm(prev => ({ ...prev, periodsPerWeek: parseInt(e.target.value) }))}
                  className="form-input"
                  min="1"
                  max="8"
                  required
                />
              </div>
            </div>

            <div className="form-actions">
              <button type="submit" className="btn btn-primary">
                <i className="fas fa-book"></i>
                Add Subject
              </button>
            </div>
          </form>
        </div>
      )}

      <style jsx>{`
        .faculty-allocation {
          background: white;
          border-radius: 12px;
          overflow: hidden;
        }

        .section-nav {
          display: flex;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
        }

        .nav-btn {
          flex: 1;
          padding: 1rem;
          border: none;
          background: transparent;
          cursor: pointer;
          transition: all 0.2s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          font-weight: 500;
          color: #64748b;
        }

        .nav-btn:hover {
          background: #e2e8f0;
          color: #334155;
        }

        .nav-btn.active {
          background: var(--primary-color);
          color: white;
        }

        .section-header {
          padding: 2rem 2rem 1rem;
          border-bottom: 1px solid #e5e7eb;
          margin-bottom: 2rem;
        }

        .section-header h3 {
          font-size: 1.5rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 0.5rem;
        }

        .section-header p {
          color: #6b7280;
        }

        .allocations-view,
        .allocation-form-section,
        .faculty-form-section,
        .subject-form-section {
          padding: 0 2rem 2rem;
        }

        .empty-state {
          text-align: center;
          padding: 4rem 2rem;
          color: #6b7280;
        }

        .empty-state i {
          font-size: 4rem;
          margin-bottom: 1rem;
          color: #d1d5db;
        }

        .empty-state h4 {
          font-size: 1.25rem;
          font-weight: 600;
          margin-bottom: 0.5rem;
          color: #374151;
        }

        .allocations-grid {
          display: grid;
          gap: 1.5rem;
        }

        .allocation-card {
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          overflow: hidden;
        }

        .allocation-header {
          background: #f8fafc;
          padding: 1rem 1.5rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 1px solid #e5e7eb;
        }

        .allocation-header h4 {
          font-size: 1.1rem;
          font-weight: 600;
          color: #1f2937;
        }

        .semester-badge {
          background: var(--primary-color);
          color: white;
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 500;
        }

        .allocation-content {
          padding: 1.5rem;
        }

        .faculty-subjects {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }

        .faculty-subject-item {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 6px;
          padding: 1rem;
        }

        .faculty-info,
        .subject-info {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          margin-bottom: 0.5rem;
        }

        .faculty-info:last-child,
        .subject-info:last-child {
          margin-bottom: 0;
        }

        .faculty-info i,
        .subject-info i {
          color: var(--primary-color);
          width: 16px;
        }

        .subject-type {
          background: #e0f2fe;
          color: #0277bd;
          padding: 0.125rem 0.5rem;
          border-radius: 12px;
          font-size: 0.75rem;
          font-weight: 500;
          margin-left: auto;
        }

        .no-assignments {
          color: #9ca3af;
          font-style: italic;
          text-align: center;
        }

        .allocation-actions {
          padding: 1rem 1.5rem;
          background: #f8fafc;
          border-top: 1px solid #e5e7eb;
        }

        .form-row {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .faculty-subjects-section {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          padding: 1.5rem;
          margin-bottom: 2rem;
        }

        .faculty-subjects-section .section-header {
          padding: 0;
          border: none;
          margin-bottom: 1.5rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .faculty-subjects-section h4 {
          font-size: 1.1rem;
          font-weight: 600;
          color: #1f2937;
        }

        .faculty-subject-pair {
          background: white;
          border: 1px solid #d1d5db;
          border-radius: 6px;
          padding: 1rem;
          margin-bottom: 1rem;
        }

        .pair-row {
          display: grid;
          grid-template-columns: 1fr 1fr auto;
          gap: 1rem;
          align-items: end;
        }

        .remove-btn {
          height: 40px;
          width: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .no-assignments-placeholder {
          text-align: center;
          padding: 2rem;
          color: #6b7280;
        }

        .no-assignments-placeholder i {
          font-size: 2rem;
          margin-bottom: 0.5rem;
          color: #9ca3af;
        }

        .form-actions {
          display: flex;
          gap: 1rem;
          justify-content: flex-end;
          padding-top: 1.5rem;
          border-top: 1px solid #e5e7eb;
        }

        .alert {
          margin: 1rem 2rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          position: relative;
        }

        .alert-close {
          background: none;
          border: none;
          font-size: 1.25rem;
          cursor: pointer;
          margin-left: auto;
          opacity: 0.7;
        }

        .alert-close:hover {
          opacity: 1;
        }

        .allocation-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          min-height: 400px;
          text-align: center;
        }

        @media (max-width: 768px) {
          .section-nav {
            flex-direction: column;
          }

          .form-row {
            grid-template-columns: 1fr;
          }

          .pair-row {
            grid-template-columns: 1fr;
          }

          .remove-btn {
            width: 100%;
          }

          .allocations-view,
          .allocation-form-section,
          .faculty-form-section,
          .subject-form-section {
            padding: 0 1rem 2rem;
          }

          .section-header {
            padding: 2rem 1rem 1rem;
          }

          .faculty-subjects-section .section-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
          }
        }
      `}</style>
    </div>
  );
};

export default FacultyAllocation;
