import React, { useState, useEffect } from 'react';
import FacultyAllocation from './FacultyAllocation';
import TimetableGeneration from './TimetableGeneration';
import TimetableDisplay from './TimetableDisplay';
import { getFaculty, getSubjects, getAllocations, getTimetables } from '../services/api';

const AdminDashboard = ({ user }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState({
    totalFaculty: 0,
    totalSubjects: 0,
    totalAllocations: 0,
    totalTimetables: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [facultyResponse, subjectsResponse, allocationsResponse, timetablesResponse] = await Promise.all([
        getFaculty(),
        getSubjects(),
        getAllocations(),
        getTimetables()
      ]);

      setStats({
        totalFaculty: facultyResponse.data?.length || 0,
        totalSubjects: subjectsResponse.data?.length || 0,
        totalAllocations: allocationsResponse.data?.length || 0,
        totalTimetables: timetablesResponse.data?.length || 0
      });
    } catch (error) {
      console.error('Dashboard load error:', error);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'fas fa-chart-line' },
    { id: 'allocation', label: 'Faculty Allocation', icon: 'fas fa-users' },
    { id: 'generation', label: 'Generate Timetable', icon: 'fas fa-calendar-plus' },
    { id: 'timetables', label: 'View Timetables', icon: 'fas fa-calendar-alt' }
  ];

  const quickActions = [
    {
      title: 'Add Faculty',
      description: 'Register new faculty members',
      icon: 'fas fa-user-plus',
      color: 'primary',
      action: () => setActiveTab('allocation')
    },
    {
      title: 'Create Allocation',
      description: 'Assign subjects to faculty',
      icon: 'fas fa-tasks',
      color: 'secondary',
      action: () => setActiveTab('allocation')
    },
    {
      title: 'Generate Timetable',
      description: 'Create new class schedules',
      icon: 'fas fa-calendar-plus',
      color: 'success',
      action: () => setActiveTab('generation')
    },
    {
      title: 'View Reports',
      description: 'Export and analyze timetables',
      icon: 'fas fa-file-export',
      color: 'warning',
      action: () => setActiveTab('timetables')
    }
  ];

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="loading-spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div className="admin-dashboard">
      {/* Navigation Tabs */}
      <div className="dashboard-nav">
        <div className="nav-tabs">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`nav-tab ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <i className={tab.icon}></i>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="dashboard-content">
        {error && (
          <div className="alert alert-error">
            <i className="fas fa-exclamation-triangle"></i>
            {error}
            <button onClick={loadDashboardData} className="btn btn-sm btn-outline ml-2">
              Retry
            </button>
          </div>
        )}

        {activeTab === 'overview' && (
          <div className="overview-content fade-in">
            {/* Welcome Section */}
            <div className="welcome-section">
              <h2>Welcome back, {user.name}!</h2>
              <p>Manage your college timetable system from this dashboard.</p>
            </div>

            {/* Stats Cards */}
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-icon primary">
                  <i className="fas fa-chalkboard-teacher"></i>
                </div>
                <div className="stat-content">
                  <h3>{stats.totalFaculty}</h3>
                  <p>Total Faculty</p>
                </div>
              </div>

              <div className="stat-card">
                <div className="stat-icon secondary">
                  <i className="fas fa-book"></i>
                </div>
                <div className="stat-content">
                  <h3>{stats.totalSubjects}</h3>
                  <p>Total Subjects</p>
                </div>
              </div>

              <div className="stat-card">
                <div className="stat-icon success">
                  <i className="fas fa-tasks"></i>
                </div>
                <div className="stat-content">
                  <h3>{stats.totalAllocations}</h3>
                  <p>Active Allocations</p>
                </div>
              </div>

              <div className="stat-card">
                <div className="stat-icon warning">
                  <i className="fas fa-calendar-alt"></i>
                </div>
                <div className="stat-content">
                  <h3>{stats.totalTimetables}</h3>
                  <p>Generated Timetables</p>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="quick-actions-section">
              <h3>Quick Actions</h3>
              <div className="quick-actions-grid">
                {quickActions.map((action, index) => (
                  <div key={index} className="quick-action-card" onClick={action.action}>
                    <div className={`action-icon ${action.color}`}>
                      <i className={action.icon}></i>
                    </div>
                    <div className="action-content">
                      <h4>{action.title}</h4>
                      <p>{action.description}</p>
                    </div>
                    <div className="action-arrow">
                      <i className="fas fa-chevron-right"></i>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="recent-activity-section">
              <h3>System Overview</h3>
              <div className="activity-cards">
                <div className="activity-card">
                  <h4><i className="fas fa-info-circle"></i> Timetable Constraints</h4>
                  <ul>
                    <li>Labs require 3 consecutive periods</li>
                    <li>Dynamic lunch breaks (4th or 5th period)</li>
                    <li>Faculty teaching load: 3-4 lectures/day max</li>
                    <li>No faculty double-booking across departments</li>
                    <li>Saturday included in weekly schedule</li>
                  </ul>
                </div>

                <div className="activity-card">
                  <h4><i className="fas fa-cog"></i> System Features</h4>
                  <ul>
                    <li>Automated conflict detection</li>
                    <li>Period distribution shuffling</li>
                    <li>Real-time validation engine</li>
                    <li>PDF export capabilities</li>
                    <li>Faculty-wise timetable views</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'allocation' && (
          <div className="fade-in">
            <FacultyAllocation onUpdate={loadDashboardData} />
          </div>
        )}

        {activeTab === 'generation' && (
          <div className="fade-in">
            <TimetableGeneration onUpdate={loadDashboardData} />
          </div>
        )}

        {activeTab === 'timetables' && (
          <div className="fade-in">
            <TimetableDisplay />
          </div>
        )}
      </div>

      <style jsx>{`
        .admin-dashboard {
          min-height: 100vh;
        }

        .dashboard-nav {
          background: white;
          border-radius: 12px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          margin-bottom: 2rem;
          padding: 1rem;
        }

        .nav-tabs {
          display: flex;
          gap: 0.5rem;
          overflow-x: auto;
        }

        .nav-tab {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.75rem 1.5rem;
          border: none;
          background: transparent;
          border-radius: 8px;
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
          color: #6b7280;
        }

        .nav-tab:hover {
          background: #f3f4f6;
          color: #374151;
        }

        .nav-tab.active {
          background: var(--primary-color);
          color: white;
        }

        .nav-tab i {
          font-size: 1rem;
        }

        .dashboard-content {
          background: white;
          border-radius: 12px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          padding: 2rem;
        }

        .welcome-section {
          margin-bottom: 2rem;
          text-align: center;
        }

        .welcome-section h2 {
          font-size: 2rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 0.5rem;
        }

        .welcome-section p {
          color: #6b7280;
          font-size: 1.1rem;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1.5rem;
          margin-bottom: 3rem;
        }

        .stat-card {
          background: white;
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          padding: 1.5rem;
          display: flex;
          align-items: center;
          gap: 1rem;
          transition: all 0.2s ease;
        }

        .stat-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
          width: 60px;
          height: 60px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.5rem;
          color: white;
        }

        .stat-icon.primary { background: var(--primary-color); }
        .stat-icon.secondary { background: var(--secondary-color); }
        .stat-icon.success { background: var(--success-color); }
        .stat-icon.warning { background: var(--warning-color); }

        .stat-content h3 {
          font-size: 2rem;
          font-weight: 700;
          color: #1f2937;
          margin-bottom: 0.25rem;
        }

        .stat-content p {
          color: #6b7280;
          font-size: 0.875rem;
          font-weight: 500;
        }

        .quick-actions-section {
          margin-bottom: 3rem;
        }

        .quick-actions-section h3 {
          font-size: 1.5rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1.5rem;
        }

        .quick-actions-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 1rem;
        }

        .quick-action-card {
          background: white;
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          padding: 1.5rem;
          display: flex;
          align-items: center;
          gap: 1rem;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .quick-action-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
          border-color: var(--primary-color);
        }

        .action-icon {
          width: 50px;
          height: 50px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.25rem;
          color: white;
        }

        .action-icon.primary { background: var(--primary-color); }
        .action-icon.secondary { background: var(--secondary-color); }
        .action-icon.success { background: var(--success-color); }
        .action-icon.warning { background: var(--warning-color); }

        .action-content {
          flex: 1;
        }

        .action-content h4 {
          font-size: 1rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 0.25rem;
        }

        .action-content p {
          color: #6b7280;
          font-size: 0.875rem;
        }

        .action-arrow {
          color: #9ca3af;
          font-size: 0.875rem;
        }

        .recent-activity-section h3 {
          font-size: 1.5rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1.5rem;
        }

        .activity-cards {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 1.5rem;
        }

        .activity-card {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          padding: 1.5rem;
        }

        .activity-card h4 {
          font-size: 1.1rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .activity-card h4 i {
          color: var(--primary-color);
        }

        .activity-card ul {
          list-style: none;
          margin: 0;
          padding: 0;
        }

        .activity-card li {
          padding: 0.5rem 0;
          color: #4b5563;
          font-size: 0.875rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .activity-card li::before {
          content: "•";
          color: var(--primary-color);
          font-weight: bold;
          font-size: 1rem;
        }

        .dashboard-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          min-height: 400px;
          text-align: center;
        }

        @media (max-width: 768px) {
          .dashboard-content {
            padding: 1rem;
          }

          .stats-grid {
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          }

          .quick-actions-grid {
            grid-template-columns: 1fr;
          }

          .nav-tabs {
            flex-direction: column;
          }

          .nav-tab {
            justify-content: center;
          }
        }
      `}</style>
    </div>
  );
};

export default AdminDashboard;
