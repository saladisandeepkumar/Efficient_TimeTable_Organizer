import React, { useState, useEffect } from 'react';
import { getAllocations, generateTimetable, getTimetables } from '../services/api';

const TimetableGeneration = ({ onUpdate }) => {
  const [allocations, setAllocations] = useState([]);
  const [selectedAllocation, setSelectedAllocation] = useState(null);
  const [generatedTimetables, setGeneratedTimetables] = useState([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const departments = ['CSE', 'ECE', 'EEE', 'MECH', 'CIVIL', 'IT'];
  const years = [1, 2, 3, 4];
  const semesters = [1, 2];
  const sections = ['A', 'B', 'C', 'D'];

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [allocationsRes, timetablesRes] = await Promise.all([
        getAllocations(),
        getTimetables()
      ]);

      setAllocations(allocationsRes.data || []);
      setGeneratedTimetables(timetablesRes.data || []);
      setError('');
    } catch (error) {
      console.error('Data load error:', error);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateTimetable = async (allocationData) => {
    if (!allocationData) {
      setError('Please select an allocation to generate timetable');
      return;
    }

    if (!window.confirm(`Generate timetable for ${allocationData.department} ${allocationData.year}-${allocationData.section} (Semester ${allocationData.semester})?\n\nThis may take a few moments.`)) {
      return;
    }

    try {
      setGenerating(true);
      setError('');
      setSuccess('');

      const response = await generateTimetable({
        department: allocationData.department,
        year: allocationData.year,
        semester: allocationData.semester,
        section: allocationData.section
      });

      if (response.success) {
        setSuccess(`Timetable generated successfully for ${allocationData.department} ${allocationData.year}-${allocationData.section}`);
        await loadData();
        if (onUpdate) onUpdate();
      } else {
        setError(response.message || 'Failed to generate timetable');
      }
    } catch (error) {
      console.error('Timetable generation error:', error);
      setError(error.message || 'Failed to generate timetable');
    } finally {
      setGenerating(false);
    }
  };

  const getAllocationKey = (allocation) => {
    return `${allocation.department}-${allocation.year}-${allocation.semester}-${allocation.section}`;
  };

  const getTimetableKey = (timetable) => {
    return `${timetable.department}-${timetable.year}-${timetable.semester}-${timetable.section}`;
  };

  const hasExistingTimetable = (allocation) => {
    const allocationKey = getAllocationKey(allocation);
    return generatedTimetables.some(tt => getTimetableKey(tt) === allocationKey);
  };

  const getExistingTimetable = (allocation) => {
    const allocationKey = getAllocationKey(allocation);
    return generatedTimetables.find(tt => getTimetableKey(tt) === allocationKey);
  };

  const clearMessages = () => {
    setError('');
    setSuccess('');
  };

  const groupAllocationsByClass = () => {
    const grouped = {};
    
    allocations.forEach(allocation => {
      const key = getAllocationKey(allocation);
      if (!grouped[key]) {
        grouped[key] = allocation;
      }
    });
    
    return Object.values(grouped);
  };

  const groupedAllocations = groupAllocationsByClass();

  if (loading) {
    return (
      <div className="generation-loading">
        <div className="loading-spinner"></div>
        <p>Loading allocation data...</p>
      </div>
    );
  }

  return (
    <div className="timetable-generation">
      <div className="generation-header">
        <div className="header-content">
          <h3>Timetable Generation</h3>
          <p>Generate automated timetables for classes with faculty allocations</p>
        </div>
      </div>

      {/* Alerts */}
      {error && (
        <div className="alert alert-error">
          <i className="fas fa-exclamation-triangle"></i>
          {error}
          <button onClick={clearMessages} className="alert-close">×</button>
        </div>
      )}

      {success && (
        <div className="alert alert-success">
          <i className="fas fa-check-circle"></i>
          {success}
          <button onClick={clearMessages} className="alert-close">×</button>
        </div>
      )}

      {generating && (
        <div className="alert alert-info">
          <div className="loading-spinner small"></div>
          Generating timetable... This may take a few moments.
        </div>
      )}

      {/* Generation Guidelines */}
      <div className="guidelines-section">
        <h4><i className="fas fa-info-circle"></i> Timetable Generation Guidelines</h4>
        <div className="guidelines-grid">
          <div className="guideline-card">
            <h5>Lab Scheduling</h5>
            <ul>
              <li>Labs require 3 consecutive periods</li>
              <li>Can be scheduled before or after lunch</li>
              <li>Minimum 3 periods after lunch required</li>
            </ul>
          </div>
          <div className="guideline-card">
            <h5>Lunch Breaks</h5>
            <ul>
              <li>Randomly placed at 4th or 5th period</li>
              <li>Different timing each day</li>
              <li>Labs cannot overlap with lunch</li>
            </ul>
          </div>
          <div className="guideline-card">
            <h5>Faculty Constraints</h5>
            <ul>
              <li>Maximum 3-4 lectures per day</li>
              <li>No double-booking across departments</li>
              <li>Period distribution across week</li>
            </ul>
          </div>
          <div className="guideline-card">
            <h5>Schedule Features</h5>
            <ul>
              <li>Monday to Saturday schedule</li>
              <li>7 periods per day (50 minutes each)</li>
              <li>Automatic conflict detection</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Available Allocations */}
      <div className="allocations-section">
        <h4>Available Class Allocations</h4>
        
        {groupedAllocations.length === 0 ? (
          <div className="empty-allocations">
            <i className="fas fa-tasks"></i>
            <h5>No Allocations Found</h5>
            <p>Please create faculty-subject allocations before generating timetables.</p>
          </div>
        ) : (
          <div className="allocations-grid">
            {groupedAllocations.map(allocation => {
              const hasExisting = hasExistingTimetable(allocation);
              const existingTimetable = hasExisting ? getExistingTimetable(allocation) : null;
              
              return (
                <div key={getAllocationKey(allocation)} className="allocation-card">
                  <div className="allocation-header">
                    <div className="allocation-info">
                      <h5>
                        {allocation.department} {allocation.year}-{allocation.section}
                      </h5>
                      <span className="semester-badge">
                        Semester {allocation.semester}
                      </span>
                    </div>
                    
                    {hasExisting && (
                      <div className="status-badge generated">
                        <i className="fas fa-check-circle"></i>
                        Generated
                      </div>
                    )}
                  </div>

                  <div className="allocation-content">
                    <div className="allocation-stats">
                      <div className="stat-item">
                        <i className="fas fa-users"></i>
                        <span>{allocation.facultySubjects?.length || 0} Assignments</span>
                      </div>
                      
                      {existingTimetable && (
                        <>
                          <div className="stat-item">
                            <i className="fas fa-clock"></i>
                            <span>
                              Generated on {new Date(existingTimetable.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          {existingTimetable.metadata && (
                            <div className="stat-item">
                              <i className="fas fa-calendar-alt"></i>
                              <span>
                                {existingTimetable.metadata.totalPeriods} periods/week
                              </span>
                            </div>
                          )}
                        </>
                      )}
                    </div>

                    {allocation.facultySubjects && allocation.facultySubjects.length > 0 ? (
                      <div className="faculty-subjects-preview">
                        <h6>Faculty Assignments:</h6>
                        <div className="assignments-list">
                          {allocation.facultySubjects.slice(0, 3).map((fs, index) => (
                            <div key={index} className="assignment-item">
                              <span className="faculty-name">
                                {fs.faculty?.name || 'Faculty'}
                              </span>
                              <span className="subject-name">
                                {fs.subject?.name || 'Subject'}
                              </span>
                            </div>
                          ))}
                          {allocation.facultySubjects.length > 3 && (
                            <div className="more-assignments">
                              +{allocation.facultySubjects.length - 3} more
                            </div>
                          )}
                        </div>
                      </div>
                    ) : (
                      <div className="no-assignments">
                        <i className="fas fa-exclamation-triangle"></i>
                        No faculty-subject assignments found
                      </div>
                    )}
                  </div>

                  <div className="allocation-actions">
                    <button
                      className={`btn ${hasExisting ? 'btn-secondary' : 'btn-primary'}`}
                      onClick={() => handleGenerateTimetable(allocation)}
                      disabled={generating || !allocation.facultySubjects || allocation.facultySubjects.length === 0}
                    >
                      {generating ? (
                        <>
                          <div className="loading-spinner small"></div>
                          Generating...
                        </>
                      ) : (
                        <>
                          <i className={`fas ${hasExisting ? 'fa-sync-alt' : 'fa-calendar-plus'}`}></i>
                          {hasExisting ? 'Regenerate' : 'Generate'} Timetable
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Generated Timetables Summary */}
      {generatedTimetables.length > 0 && (
        <div className="summary-section">
          <h4>Generated Timetables Summary</h4>
          <div className="summary-stats">
            <div className="summary-card">
              <div className="summary-icon primary">
                <i className="fas fa-calendar-alt"></i>
              </div>
              <div className="summary-content">
                <h5>{generatedTimetables.length}</h5>
                <p>Total Timetables</p>
              </div>
            </div>

            <div className="summary-card">
              <div className="summary-icon secondary">
                <i className="fas fa-building"></i>
              </div>
              <div className="summary-content">
                <h5>{new Set(generatedTimetables.map(t => t.department)).size}</h5>
                <p>Departments</p>
              </div>
            </div>

            <div className="summary-card">
              <div className="summary-icon success">
                <i className="fas fa-users"></i>
              </div>
              <div className="summary-content">
                <h5>{new Set(generatedTimetables.map(t => `${t.department}-${t.year}-${t.section}`)).size}</h5>
                <p>Class Sections</p>
              </div>
            </div>
          </div>

          <div className="recent-generations">
            <h5>Recently Generated</h5>
            <div className="recent-list">
              {generatedTimetables
                .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
                .slice(0, 5)
                .map(timetable => (
                  <div key={timetable._id} className="recent-item">
                    <div className="recent-info">
                      <span className="recent-class">
                        {timetable.department} {timetable.year}-{timetable.section}
                      </span>
                      <span className="recent-semester">
                        Semester {timetable.semester}
                      </span>
                    </div>
                    <div className="recent-date">
                      {new Date(timetable.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .timetable-generation {
          background: white;
          border-radius: 12px;
          overflow: hidden;
        }

        .generation-header {
          background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-dark) 100%);
          color: white;
          padding: 2rem;
        }

        .header-content h3 {
          font-size: 1.75rem;
          font-weight: 600;
          margin-bottom: 0.5rem;
        }

        .header-content p {
          opacity: 0.9;
          font-size: 1.1rem;
        }

        .guidelines-section {
          padding: 2rem;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
        }

        .guidelines-section h4 {
          font-size: 1.25rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1.5rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .guidelines-section h4 i {
          color: var(--primary-color);
        }

        .guidelines-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 1rem;
        }

        .guideline-card {
          background: white;
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          padding: 1.5rem;
        }

        .guideline-card h5 {
          font-size: 1rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1rem;
        }

        .guideline-card ul {
          list-style: none;
          margin: 0;
          padding: 0;
        }

        .guideline-card li {
          padding: 0.25rem 0;
          color: #4b5563;
          font-size: 0.875rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .guideline-card li::before {
          content: "•";
          color: var(--primary-color);
          font-weight: bold;
        }

        .allocations-section {
          padding: 2rem;
        }

        .allocations-section h4 {
          font-size: 1.25rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1.5rem;
        }

        .empty-allocations {
          text-align: center;
          padding: 4rem 2rem;
          color: #6b7280;
        }

        .empty-allocations i {
          font-size: 4rem;
          margin-bottom: 1rem;
          color: #d1d5db;
        }

        .empty-allocations h5 {
          font-size: 1.25rem;
          font-weight: 600;
          margin-bottom: 0.5rem;
          color: #374151;
        }

        .allocations-grid {
          display: grid;
          gap: 1.5rem;
        }

        .allocation-card {
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          overflow: hidden;
          transition: all 0.2s ease;
        }

        .allocation-card:hover {
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .allocation-header {
          background: #f8fafc;
          padding: 1.5rem;
          border-bottom: 1px solid #e5e7eb;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .allocation-info h5 {
          font-size: 1.2rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 0.5rem;
        }

        .semester-badge {
          background: var(--primary-color);
          color: white;
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 500;
        }

        .status-badge {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          border-radius: 20px;
          font-size: 0.8rem;
          font-weight: 500;
        }

        .status-badge.generated {
          background: #dcfce7;
          color: #166534;
        }

        .allocation-content {
          padding: 1.5rem;
        }

        .allocation-stats {
          display: flex;
          flex-wrap: wrap;
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .stat-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: #6b7280;
          font-size: 0.875rem;
        }

        .stat-item i {
          color: var(--primary-color);
        }

        .faculty-subjects-preview h6 {
          font-size: 0.875rem;
          font-weight: 600;
          color: #374151;
          margin-bottom: 0.75rem;
        }

        .assignments-list {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .assignment-item {
          background: #f1f5f9;
          border: 1px solid #e2e8f0;
          border-radius: 6px;
          padding: 0.75rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .faculty-name {
          font-weight: 500;
          color: #1f2937;
          font-size: 0.875rem;
        }

        .subject-name {
          color: #6b7280;
          font-size: 0.8rem;
        }

        .more-assignments {
          text-align: center;
          color: #6b7280;
          font-size: 0.8rem;
          font-style: italic;
          padding: 0.5rem;
        }

        .no-assignments {
          text-align: center;
          color: #ef4444;
          font-size: 0.875rem;
          padding: 1rem;
          background: #fef2f2;
          border: 1px solid #fecaca;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
        }

        .allocation-actions {
          padding: 1.5rem;
          background: #f8fafc;
          border-top: 1px solid #e5e7eb;
        }

        .summary-section {
          padding: 2rem;
          background: #f8fafc;
          border-top: 1px solid #e2e8f0;
        }

        .summary-section h4 {
          font-size: 1.25rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1.5rem;
        }

        .summary-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
          margin-bottom: 2rem;
        }

        .summary-card {
          background: white;
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          padding: 1.5rem;
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .summary-icon {
          width: 50px;
          height: 50px;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.25rem;
          color: white;
        }

        .summary-icon.primary { background: var(--primary-color); }
        .summary-icon.secondary { background: var(--secondary-color); }
        .summary-icon.success { background: var(--success-color); }

        .summary-content h5 {
          font-size: 1.5rem;
          font-weight: 700;
          color: #1f2937;
          margin-bottom: 0.25rem;
        }

        .summary-content p {
          color: #6b7280;
          font-size: 0.875rem;
        }

        .recent-generations h5 {
          font-size: 1rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1rem;
        }

        .recent-list {
          background: white;
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          overflow: hidden;
        }

        .recent-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem 1.5rem;
          border-bottom: 1px solid #e2e8f0;
        }

        .recent-item:last-child {
          border-bottom: none;
        }

        .recent-info {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
        }

        .recent-class {
          font-weight: 500;
          color: #1f2937;
        }

        .recent-semester {
          font-size: 0.8rem;
          color: #6b7280;
        }

        .recent-date {
          color: #6b7280;
          font-size: 0.875rem;
        }

        .generation-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          min-height: 400px;
          text-align: center;
        }

        .alert {
          margin: 1rem 2rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          position: relative;
        }

        .alert-close {
          background: none;
          border: none;
          font-size: 1.25rem;
          cursor: pointer;
          margin-left: auto;
          opacity: 0.7;
        }

        .alert-close:hover {
          opacity: 1;
        }

        .loading-spinner.small {
          width: 16px;
          height: 16px;
          border-width: 2px;
        }

        @media (max-width: 768px) {
          .generation-header {
            padding: 1.5rem;
          }

          .guidelines-section,
          .allocations-section,
          .summary-section {
            padding: 1.5rem;
          }

          .guidelines-grid {
            grid-template-columns: 1fr;
          }

          .allocation-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
          }

          .allocation-stats {
            flex-direction: column;
            align-items: flex-start;
          }

          .summary-stats {
            grid-template-columns: 1fr;
          }

          .recent-item {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.5rem;
          }
        }
      `}</style>
    </div>
  );
};

export default TimetableGeneration;
