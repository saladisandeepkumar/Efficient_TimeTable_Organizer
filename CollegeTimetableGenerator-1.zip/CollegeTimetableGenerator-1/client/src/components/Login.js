import React, { useState } from 'react';
import { login } from '../services/api';

const Login = ({ onLogin, setError }) => {
  const [formData, setFormData] = useState({
    email: '',
    employeeId: '',
    password: '',
    loginType: 'email' // 'email' or 'employeeId'
  });
  const [loading, setLoading] = useState(false);
  const [localError, setLocalError] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear errors when user starts typing
    if (localError) setLocalError('');
    if (setError) setError('');
  };

  const handleLoginTypeChange = (type) => {
    setFormData(prev => ({
      ...prev,
      loginType: type,
      email: '',
      employeeId: ''
    }));
    setLocalError('');
  };

  const validateForm = () => {
    if (!formData.password) {
      setLocalError('Password is required');
      return false;
    }

    if (formData.loginType === 'email') {
      if (!formData.email) {
        setLocalError('Email is required');
        return false;
      }
      if (!/\S+@\S+\.\S+/.test(formData.email)) {
        setLocalError('Please enter a valid email address');
        return false;
      }
    } else {
      if (!formData.employeeId) {
        setLocalError('Employee ID is required');
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    setLocalError('');

    try {
      const loginData = {
        password: formData.password,
        ...(formData.loginType === 'email' 
          ? { email: formData.email }
          : { employeeId: formData.employeeId }
        )
      };

      const response = await login(loginData);
      
      if (response.success) {
        // Store token in localStorage
        localStorage.setItem('token', response.data.token);
        onLogin(response.data.user);
      } else {
        setLocalError(response.message || 'Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
      setLocalError(error.message || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <div className="logo-section">
            <i className="fas fa-calendar-alt"></i>
            <h1>SmartScheduler</h1>
          </div>
          <p className="login-subtitle">College Timetable Generator</p>
        </div>

        <form onSubmit={handleSubmit} className="login-form">
          {/* Login Type Toggle */}
          <div className="login-type-toggle">
            <button
              type="button"
              className={`toggle-btn ${formData.loginType === 'email' ? 'active' : ''}`}
              onClick={() => handleLoginTypeChange('email')}
            >
              <i className="fas fa-envelope"></i>
              Email
            </button>
            <button
              type="button"
              className={`toggle-btn ${formData.loginType === 'employeeId' ? 'active' : ''}`}
              onClick={() => handleLoginTypeChange('employeeId')}
            >
              <i className="fas fa-id-badge"></i>
              Employee ID
            </button>
          </div>

          {/* Email Input */}
          {formData.loginType === 'email' && (
            <div className="form-group">
              <label htmlFor="email" className="form-label">
                <i className="fas fa-envelope"></i>
                Email Address
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter your email address"
                autoComplete="email"
                disabled={loading}
              />
            </div>
          )}

          {/* Employee ID Input */}
          {formData.loginType === 'employeeId' && (
            <div className="form-group">
              <label htmlFor="employeeId" className="form-label">
                <i className="fas fa-id-badge"></i>
                Employee ID
              </label>
              <input
                type="text"
                id="employeeId"
                name="employeeId"
                value={formData.employeeId}
                onChange={handleInputChange}
                className="form-input"
                placeholder="Enter your employee ID"
                autoComplete="username"
                disabled={loading}
              />
            </div>
          )}

          {/* Password Input */}
          <div className="form-group">
            <label htmlFor="password" className="form-label">
              <i className="fas fa-lock"></i>
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              className="form-input"
              placeholder="Enter your password"
              autoComplete="current-password"
              disabled={loading}
            />
          </div>

          {/* Error Message */}
          {localError && (
            <div className="alert alert-error">
              <i className="fas fa-exclamation-triangle"></i>
              {localError}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            className="btn btn-primary btn-lg w-full"
            disabled={loading}
          >
            {loading ? (
              <>
                <div className="loading-spinner"></div>
                Signing In...
              </>
            ) : (
              <>
                <i className="fas fa-sign-in-alt"></i>
                Sign In
              </>
            )}
          </button>
        </form>

        <div className="login-footer">
          <div className="info-section">
            <h3>Welcome to SmartScheduler</h3>
            <ul>
              <li><i className="fas fa-check"></i> Automated timetable generation</li>
              <li><i className="fas fa-check"></i> Lab constraint management</li>
              <li><i className="fas fa-check"></i> Faculty workload optimization</li>
              <li><i className="fas fa-check"></i> Conflict-free scheduling</li>
            </ul>
          </div>

          <div className="access-info">
            <div className="access-card">
              <h4><i className="fas fa-user-shield"></i> Admin Access</h4>
              <p>Full system control, faculty management, and timetable generation</p>
            </div>
            <div className="access-card">
              <h4><i className="fas fa-chalkboard-teacher"></i> Faculty Access</h4>
              <p>View personal schedules and timetable information</p>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .login-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 2rem;
        }

        .login-card {
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
          overflow: hidden;
          max-width: 800px;
          width: 100%;
          display: grid;
          grid-template-columns: 1fr 1fr;
          min-height: 600px;
        }

        .login-header {
          background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
          color: white;
          padding: 3rem 2rem;
          display: flex;
          flex-direction: column;
          justify-content: center;
          text-align: center;
        }

        .login-header .logo-section {
          margin-bottom: 1rem;
        }

        .login-header i {
          font-size: 3rem;
          margin-bottom: 1rem;
          display: block;
        }

        .login-header h1 {
          font-size: 2rem;
          font-weight: 700;
          margin-bottom: 0.5rem;
        }

        .login-subtitle {
          font-size: 1.1rem;
          opacity: 0.9;
          font-weight: 300;
        }

        .login-form {
          padding: 3rem 2rem;
          display: flex;
          flex-direction: column;
          justify-content: center;
        }

        .login-type-toggle {
          display: flex;
          background: #f5f5f5;
          border-radius: 8px;
          padding: 4px;
          margin-bottom: 2rem;
        }

        .toggle-btn {
          flex: 1;
          padding: 0.75rem;
          border: none;
          background: transparent;
          border-radius: 6px;
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
        }

        .toggle-btn.active {
          background: var(--primary-color);
          color: white;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-label {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          margin-bottom: 0.5rem;
          font-weight: 500;
          color: #374151;
        }

        .form-label i {
          color: var(--primary-color);
          width: 16px;
        }

        .login-footer {
          grid-column: 1 / -1;
          background: #f8fafc;
          padding: 2rem;
        }

        .info-section {
          text-align: center;
          margin-bottom: 2rem;
        }

        .info-section h3 {
          color: #374151;
          margin-bottom: 1rem;
          font-size: 1.25rem;
        }

        .info-section ul {
          list-style: none;
          display: inline-flex;
          flex-wrap: wrap;
          gap: 1rem;
          justify-content: center;
        }

        .info-section li {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: #6b7280;
          font-size: 0.875rem;
        }

        .info-section li i {
          color: var(--success-color);
        }

        .access-info {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 1rem;
        }

        .access-card {
          background: white;
          padding: 1.5rem;
          border-radius: 8px;
          text-align: center;
          border: 1px solid #e5e7eb;
        }

        .access-card h4 {
          color: #374151;
          margin-bottom: 0.5rem;
          font-size: 1rem;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
        }

        .access-card h4 i {
          color: var(--primary-color);
        }

        .access-card p {
          color: #6b7280;
          font-size: 0.875rem;
          line-height: 1.5;
        }

        @media (max-width: 768px) {
          .login-card {
            grid-template-columns: 1fr;
            max-width: 400px;
            min-height: auto;
          }

          .login-header {
            padding: 2rem 1rem;
          }

          .login-form {
            padding: 2rem 1rem;
          }

          .access-info {
            grid-template-columns: 1fr;
          }

          .info-section ul {
            flex-direction: column;
            align-items: center;
          }
        }
      `}</style>
    </div>
  );
};

export default Login;
