import React, { useState, useEffect } from 'react';
import { getTimetables, exportTimetable, regenerateTimetable } from '../services/api';

const TimetableDisplay = ({ facultySchedule = null, isFacultyView = false }) => {
  const [timetables, setTimetables] = useState([]);
  const [selectedTimetable, setSelectedTimetable] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState({
    department: '',
    year: '',
    semester: '',
    section: ''
  });

  const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const PERIOD_TIMES = [
    '9:00-9:50',
    '9:50-10:40',
    '10:40-11:30',
    '11:30-12:20',
    '12:20-1:10',
    '1:10-2:00',
    '2:00-2:50'
  ];

  const departments = ['CSE', 'ECE', 'EEE', 'MECH', 'CIVIL', 'IT'];
  const years = [1, 2, 3, 4];
  const semesters = [1, 2];
  const sections = ['A', 'B', 'C', 'D'];

  useEffect(() => {
    if (!isFacultyView) {
      loadTimetables();
    }
  }, [isFacultyView]);

  const loadTimetables = async () => {
    try {
      setLoading(true);
      setError('');
      
      const response = await getTimetables(filters);
      
      if (response.success) {
        setTimetables(response.data || []);
        if (response.data && response.data.length > 0) {
          setSelectedTimetable(response.data[0]);
        }
      } else {
        setError(response.message || 'Failed to load timetables');
      }
    } catch (error) {
      console.error('Timetables load error:', error);
      setError(error.message || 'Failed to load timetables');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (field, value) => {
    setFilters(prev => ({ ...prev, [field]: value }));
  };

  const applyFilters = () => {
    loadTimetables();
  };

  const clearFilters = () => {
    setFilters({
      department: '',
      year: '',
      semester: '',
      section: ''
    });
  };

  const handleExport = async (timetableId) => {
    try {
      const response = await exportTimetable(timetableId);
      
      // Create blob and download
      const blob = new Blob([response], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      
      const timetable = timetables.find(t => t._id === timetableId);
      const filename = timetable 
        ? `timetable_${timetable.department}_${timetable.year}_${timetable.semester}_${timetable.section}.pdf`
        : 'timetable.pdf';
      
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export error:', error);
      setError('Failed to export timetable');
    }
  };

  const handleRegenerate = async (timetableId) => {
    if (!window.confirm('Are you sure you want to regenerate this timetable? This will overwrite the existing schedule.')) {
      return;
    }

    try {
      setLoading(true);
      const response = await regenerateTimetable(timetableId);
      
      if (response.success) {
        await loadTimetables();
        setError('');
      } else {
        setError(response.message || 'Failed to regenerate timetable');
      }
    } catch (error) {
      console.error('Regenerate error:', error);
      setError(error.message || 'Failed to regenerate timetable');
    } finally {
      setLoading(false);
    }
  };

  const getPeriodContent = (day, periodIndex, schedule) => {
    if (isFacultyView && facultySchedule) {
      // Faculty view - show class information
      const daySchedule = facultySchedule.filter(item => item.day === day);
      const period = daySchedule.find(item => item.period.periodNumber === periodIndex + 1);
      
      if (period) {
        return {
          type: period.period.type,
          subject: period.period.subject,
          subjectCode: period.period.subjectCode,
          class: `${period.department} ${period.year}-${period.section}`,
          faculty: period.period.faculty
        };
      }
      return null;
    } else {
      // Class view - show subject and faculty
      const daySchedule = schedule.find(d => d.day === day);
      if (daySchedule && daySchedule.periods[periodIndex]) {
        return daySchedule.periods[periodIndex];
      }
      return null;
    }
  };

  const getCellColor = (period) => {
    if (!period || period.type === 'free') return 'cell-free';
    
    switch (period.type) {
      case 'lab':
        return 'cell-lab';
      case 'theory':
        return 'cell-theory';
      case 'lunch':
        return 'cell-lunch';
      default:
        return 'cell-free';
    }
  };

  const renderFacultyTimetable = () => {
    if (!facultySchedule || facultySchedule.length === 0) {
      return (
        <div className="empty-timetable">
          <i className="fas fa-calendar-times"></i>
          <h3>No Schedule Available</h3>
          <p>You don't have any teaching assignments yet.</p>
        </div>
      );
    }

    return (
      <div className="timetable-container">
        <div className="timetable-header">
          <h3>My Teaching Schedule</h3>
          <div className="timetable-stats">
            <span>Total Periods: {facultySchedule.length}</span>
          </div>
        </div>

        <div className="timetable-wrapper">
          <table className="timetable-table">
            <thead>
              <tr>
                <th className="time-header">Time / Day</th>
                {DAYS.map(day => (
                  <th key={day} className="day-header">{day}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PERIOD_TIMES.map((time, periodIndex) => (
                <tr key={periodIndex}>
                  <td className="time-cell">{time}</td>
                  {DAYS.map(day => {
                    const period = getPeriodContent(day, periodIndex, null);
                    return (
                      <td key={day} className={`period-cell ${getCellColor(period)}`}>
                        {period ? (
                          <div className="period-content">
                            <div className="class-info">{period.class}</div>
                            <div className="subject-info">{period.subject}</div>
                            {period.type === 'lab' && (
                              <div className="period-type">Lab</div>
                            )}
                          </div>
                        ) : (
                          <div className="period-content">
                            <div className="free-period">Free</div>
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="timetable-legend">
          <h4>Legend</h4>
          <div className="legend-items">
            <div className="legend-item">
              <div className="legend-color cell-theory"></div>
              <span>Theory Classes</span>
            </div>
            <div className="legend-item">
              <div className="legend-color cell-lab"></div>
              <span>Lab Sessions</span>
            </div>
            <div className="legend-item">
              <div className="legend-color cell-lunch"></div>
              <span>Lunch Break</span>
            </div>
            <div className="legend-item">
              <div className="legend-color cell-free"></div>
              <span>Free Period</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderClassTimetable = () => {
    if (!selectedTimetable) {
      return (
        <div className="empty-timetable">
          <i className="fas fa-calendar-times"></i>
          <h3>No Timetable Selected</h3>
          <p>Please select a timetable to view or apply filters to load timetables.</p>
        </div>
      );
    }

    return (
      <div className="timetable-container">
        <div className="timetable-header">
          <div className="timetable-info">
            <h3>
              {selectedTimetable.department} {selectedTimetable.year}-{selectedTimetable.section}
            </h3>
            <p>Semester {selectedTimetable.semester}</p>
          </div>
          <div className="timetable-actions">
            <button 
              className="btn btn-sm btn-primary"
              onClick={() => handleExport(selectedTimetable._id)}
            >
              <i className="fas fa-download"></i>
              Export PDF
            </button>
            <button 
              className="btn btn-sm btn-secondary"
              onClick={() => handleRegenerate(selectedTimetable._id)}
            >
              <i className="fas fa-sync-alt"></i>
              Regenerate
            </button>
          </div>
        </div>

        <div className="timetable-wrapper">
          <table className="timetable-table">
            <thead>
              <tr>
                <th className="time-header">Time / Day</th>
                {DAYS.map(day => (
                  <th key={day} className="day-header">{day}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {PERIOD_TIMES.map((time, periodIndex) => (
                <tr key={periodIndex}>
                  <td className="time-cell">{time}</td>
                  {DAYS.map(day => {
                    const period = getPeriodContent(day, periodIndex, selectedTimetable.schedule);
                    return (
                      <td key={day} className={`period-cell ${getCellColor(period)}`}>
                        {period && period.type !== 'free' ? (
                          <div className="period-content">
                            {period.type === 'lunch' ? (
                              <div className="lunch-break">LUNCH</div>
                            ) : (
                              <>
                                <div className="subject-code">{period.subjectCode}</div>
                                <div className="subject-name">{period.subject}</div>
                                <div className="faculty-name">{period.faculty}</div>
                                {period.type === 'lab' && (
                                  <div className="period-type">Lab</div>
                                )}
                              </>
                            )}
                          </div>
                        ) : (
                          <div className="period-content">
                            <div className="free-period">Free</div>
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {selectedTimetable.metadata && (
          <div className="timetable-metadata">
            <h4>Timetable Statistics</h4>
            <div className="metadata-grid">
              <div className="metadata-item">
                <span className="metadata-label">Total Periods:</span>
                <span className="metadata-value">{selectedTimetable.metadata.totalPeriods}</span>
              </div>
              <div className="metadata-item">
                <span className="metadata-label">Theory Periods:</span>
                <span className="metadata-value">{selectedTimetable.metadata.theoryPeriods}</span>
              </div>
              <div className="metadata-item">
                <span className="metadata-label">Lab Periods:</span>
                <span className="metadata-value">{selectedTimetable.metadata.labPeriods}</span>
              </div>
              <div className="metadata-item">
                <span className="metadata-label">Free Periods:</span>
                <span className="metadata-value">{selectedTimetable.metadata.freePeriods}</span>
              </div>
            </div>
          </div>
        )}

        <div className="timetable-legend">
          <h4>Legend</h4>
          <div className="legend-items">
            <div className="legend-item">
              <div className="legend-color cell-theory"></div>
              <span>Theory Classes</span>
            </div>
            <div className="legend-item">
              <div className="legend-color cell-lab"></div>
              <span>Lab Sessions</span>
            </div>
            <div className="legend-item">
              <div className="legend-color cell-lunch"></div>
              <span>Lunch Break</span>
            </div>
            <div className="legend-item">
              <div className="legend-color cell-free"></div>
              <span>Free Period</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="timetable-loading">
        <div className="loading-spinner"></div>
        <p>Loading timetables...</p>
      </div>
    );
  }

  // Render faculty view if specified
  if (isFacultyView) {
    return renderFacultyTimetable();
  }

  return (
    <div className="timetable-display">
      {/* Filters Section */}
      <div className="filters-section">
        <div className="filters-header">
          <h3>View Timetables</h3>
          <p>Filter and view generated class timetables</p>
        </div>

        <div className="filters-form">
          <div className="filter-row">
            <div className="filter-group">
              <label className="filter-label">Department</label>
              <select
                value={filters.department}
                onChange={(e) => handleFilterChange('department', e.target.value)}
                className="filter-select"
              >
                <option value="">All Departments</option>
                {departments.map(dept => (
                  <option key={dept} value={dept}>{dept}</option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label className="filter-label">Year</label>
              <select
                value={filters.year}
                onChange={(e) => handleFilterChange('year', e.target.value)}
                className="filter-select"
              >
                <option value="">All Years</option>
                {years.map(year => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label className="filter-label">Semester</label>
              <select
                value={filters.semester}
                onChange={(e) => handleFilterChange('semester', e.target.value)}
                className="filter-select"
              >
                <option value="">All Semesters</option>
                {semesters.map(semester => (
                  <option key={semester} value={semester}>{semester}</option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label className="filter-label">Section</label>
              <select
                value={filters.section}
                onChange={(e) => handleFilterChange('section', e.target.value)}
                className="filter-select"
              >
                <option value="">All Sections</option>
                {sections.map(section => (
                  <option key={section} value={section}>{section}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="filter-actions">
            <button 
              className="btn btn-primary"
              onClick={applyFilters}
            >
              <i className="fas fa-search"></i>
              Apply Filters
            </button>
            <button 
              className="btn btn-outline"
              onClick={clearFilters}
            >
              <i className="fas fa-times"></i>
              Clear
            </button>
          </div>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="alert alert-error">
          <i className="fas fa-exclamation-triangle"></i>
          {error}
          <button onClick={() => setError('')} className="alert-close">×</button>
        </div>
      )}

      {/* Timetable Selection */}
      {timetables.length > 0 && (
        <div className="timetable-selection">
          <div className="selection-header">
            <h4>Available Timetables ({timetables.length})</h4>
          </div>
          <div className="timetable-tabs">
            {timetables.map(timetable => (
              <button
                key={timetable._id}
                className={`timetable-tab ${selectedTimetable && selectedTimetable._id === timetable._id ? 'active' : ''}`}
                onClick={() => setSelectedTimetable(timetable)}
              >
                <div className="tab-info">
                  <span className="tab-title">
                    {timetable.department} {timetable.year}-{timetable.section}
                  </span>
                  <span className="tab-subtitle">
                    Semester {timetable.semester}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Timetable Display */}
      {renderClassTimetable()}

      <style jsx>{`
        .timetable-display {
          background: white;
          border-radius: 12px;
          overflow: hidden;
        }

        .filters-section {
          background: #f8fafc;
          padding: 2rem;
          border-bottom: 1px solid #e2e8f0;
        }

        .filters-header {
          margin-bottom: 1.5rem;
        }

        .filters-header h3 {
          font-size: 1.5rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 0.5rem;
        }

        .filters-header p {
          color: #6b7280;
        }

        .filter-row {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .filter-group {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .filter-label {
          font-size: 0.875rem;
          font-weight: 500;
          color: #374151;
        }

        .filter-select {
          padding: 0.75rem;
          border: 1px solid #d1d5db;
          border-radius: 8px;
          font-size: 0.875rem;
          background: white;
        }

        .filter-select:focus {
          outline: none;
          border-color: var(--primary-color);
          box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
        }

        .filter-actions {
          display: flex;
          gap: 1rem;
        }

        .timetable-selection {
          padding: 1.5rem 2rem;
          border-bottom: 1px solid #e2e8f0;
        }

        .selection-header h4 {
          font-size: 1.1rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1rem;
        }

        .timetable-tabs {
          display: flex;
          gap: 0.5rem;
          overflow-x: auto;
          padding-bottom: 0.5rem;
        }

        .timetable-tab {
          background: white;
          border: 1px solid #d1d5db;
          border-radius: 8px;
          padding: 1rem;
          cursor: pointer;
          transition: all 0.2s ease;
          min-width: 200px;
          text-align: left;
        }

        .timetable-tab:hover {
          border-color: var(--primary-color);
          background: #f8fafc;
        }

        .timetable-tab.active {
          border-color: var(--primary-color);
          background: var(--primary-light);
        }

        .tab-info {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
        }

        .tab-title {
          font-weight: 600;
          color: #1f2937;
        }

        .tab-subtitle {
          font-size: 0.8rem;
          color: #6b7280;
        }

        .timetable-container {
          padding: 2rem;
        }

        .timetable-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid #e5e7eb;
        }

        .timetable-info h3 {
          font-size: 1.5rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 0.25rem;
        }

        .timetable-info p {
          color: #6b7280;
        }

        .timetable-actions {
          display: flex;
          gap: 0.5rem;
        }

        .timetable-wrapper {
          overflow-x: auto;
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          margin-bottom: 2rem;
        }

        .timetable-table {
          width: 100%;
          border-collapse: collapse;
          min-width: 800px;
        }

        .time-header,
        .day-header {
          background: var(--primary-color);
          color: white;
          padding: 1rem 0.75rem;
          text-align: center;
          font-weight: 600;
          font-size: 0.875rem;
        }

        .time-cell {
          background: #f8fafc;
          padding: 1rem 0.75rem;
          text-align: center;
          font-weight: 500;
          color: #374151;
          border-right: 1px solid #e2e8f0;
          white-space: nowrap;
          min-width: 120px;
        }

        .period-cell {
          border: 1px solid #e2e8f0;
          padding: 0.75rem;
          text-align: center;
          vertical-align: middle;
          height: 80px;
          min-width: 140px;
        }

        .cell-theory {
          background: #e3f2fd;
        }

        .cell-lab {
          background: #ffebee;
        }

        .cell-lunch {
          background: #fff3e0;
        }

        .cell-free {
          background: #f5f5f5;
        }

        .period-content {
          display: flex;
          flex-direction: column;
          justify-content: center;
          height: 100%;
          gap: 0.25rem;
        }

        .subject-code {
          font-weight: 600;
          font-size: 0.875rem;
          color: #1f2937;
        }

        .subject-name {
          font-size: 0.75rem;
          color: #4b5563;
          line-height: 1.2;
        }

        .faculty-name {
          font-size: 0.7rem;
          color: #6b7280;
          font-style: italic;
        }

        .class-info {
          font-weight: 600;
          font-size: 0.8rem;
          color: #1f2937;
        }

        .subject-info {
          font-size: 0.75rem;
          color: #4b5563;
        }

        .lunch-break {
          font-weight: 600;
          color: #ea580c;
          font-size: 0.875rem;
        }

        .free-period {
          color: #9ca3af;
          font-size: 0.75rem;
          font-style: italic;
        }

        .period-type {
          background: #dc2626;
          color: white;
          padding: 0.125rem 0.375rem;
          border-radius: 12px;
          font-size: 0.6rem;
          font-weight: 500;
          align-self: center;
        }

        .timetable-metadata {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          padding: 1.5rem;
          margin-bottom: 2rem;
        }

        .timetable-metadata h4 {
          font-size: 1.1rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1rem;
        }

        .metadata-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 1rem;
        }

        .metadata-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .metadata-label {
          font-size: 0.875rem;
          color: #6b7280;
        }

        .metadata-value {
          font-weight: 600;
          color: #1f2937;
        }

        .timetable-legend {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          padding: 1.5rem;
        }

        .timetable-legend h4 {
          font-size: 1rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1rem;
        }

        .legend-items {
          display: flex;
          flex-wrap: wrap;
          gap: 1rem;
        }

        .legend-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .legend-color {
          width: 20px;
          height: 20px;
          border-radius: 4px;
          border: 1px solid #d1d5db;
        }

        .empty-timetable {
          text-align: center;
          padding: 4rem 2rem;
          color: #6b7280;
        }

        .empty-timetable i {
          font-size: 4rem;
          margin-bottom: 1rem;
          color: #d1d5db;
        }

        .empty-timetable h3 {
          font-size: 1.5rem;
          font-weight: 600;
          margin-bottom: 0.5rem;
          color: #374151;
        }

        .timetable-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          min-height: 400px;
          text-align: center;
        }

        .alert {
          margin: 1rem 2rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          position: relative;
        }

        .alert-close {
          background: none;
          border: none;
          font-size: 1.25rem;
          cursor: pointer;
          margin-left: auto;
          opacity: 0.7;
        }

        .alert-close:hover {
          opacity: 1;
        }

        @media (max-width: 768px) {
          .timetable-container {
            padding: 1rem;
          }

          .timetable-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
          }

          .filter-row {
            grid-template-columns: 1fr;
          }

          .filter-actions {
            flex-direction: column;
          }

          .timetable-tabs {
            flex-direction: column;
          }

          .timetable-tab {
            min-width: auto;
          }

          .metadata-grid {
            grid-template-columns: 1fr;
          }

          .legend-items {
            flex-direction: column;
            align-items: flex-start;
          }

          .period-cell {
            min-width: 100px;
            height: 60px;
          }

          .subject-code {
            font-size: 0.75rem;
          }

          .subject-name {
            font-size: 0.7rem;
          }

          .faculty-name {
            font-size: 0.65rem;
          }
        }
      `}</style>
    </div>
  );
};

export default TimetableDisplay;
