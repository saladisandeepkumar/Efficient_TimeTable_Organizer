import React, { useState, useEffect } from 'react';
import TimetableDisplay from './TimetableDisplay';
import { getFacultyTimetable, exportFacultyTimetable } from '../services/api';

const FacultyDashboard = ({ user }) => {
  const [activeTab, setActiveTab] = useState('schedule');
  const [facultySchedule, setFacultySchedule] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (user.employeeId) {
      loadFacultySchedule();
    }
  }, [user.employeeId]);

  const loadFacultySchedule = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Get faculty details from facultyDetails if available
      const facultyId = user.facultyDetails?._id || user._id;
      
      if (!facultyId) {
        setError('Faculty information not found');
        return;
      }

      const response = await getFacultyTimetable(facultyId);
      
      if (response.success) {
        setFacultySchedule(response.data || []);
      } else {
        setError(response.message || 'Failed to load schedule');
      }
    } catch (error) {
      console.error('Faculty schedule load error:', error);
      setError(error.message || 'Failed to load schedule');
    } finally {
      setLoading(false);
    }
  };

  const handleExportSchedule = async () => {
    try {
      const facultyId = user.facultyDetails?._id || user._id;
      
      if (!facultyId) {
        setError('Faculty information not found');
        return;
      }

      const response = await exportFacultyTimetable(facultyId);
      
      // Create blob and download
      const blob = new Blob([response], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `faculty_timetable_${user.employeeId || 'schedule'}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export error:', error);
      setError('Failed to export schedule');
    }
  };

  const tabs = [
    { id: 'schedule', label: 'My Schedule', icon: 'fas fa-calendar-alt' },
    { id: 'profile', label: 'Profile', icon: 'fas fa-user' }
  ];

  const getScheduleStats = () => {
    if (!facultySchedule || facultySchedule.length === 0) {
      return { totalPeriods: 0, departments: 0, sections: 0 };
    }

    const departments = new Set();
    const sections = new Set();
    
    facultySchedule.forEach(item => {
      departments.add(item.department);
      sections.add(`${item.department}-${item.year}-${item.section}`);
    });

    return {
      totalPeriods: facultySchedule.length,
      departments: departments.size,
      sections: sections.size
    };
  };

  const stats = getScheduleStats();

  if (loading) {
    return (
      <div className="faculty-loading">
        <div className="loading-spinner"></div>
        <p>Loading your schedule...</p>
      </div>
    );
  }

  return (
    <div className="faculty-dashboard">
      {/* Navigation Tabs */}
      <div className="dashboard-nav">
        <div className="nav-tabs">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`nav-tab ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <i className={tab.icon}></i>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Dashboard Content */}
      <div className="dashboard-content">
        {error && (
          <div className="alert alert-error">
            <i className="fas fa-exclamation-triangle"></i>
            {error}
            <button onClick={loadFacultySchedule} className="btn btn-sm btn-outline ml-2">
              Retry
            </button>
          </div>
        )}

        {activeTab === 'schedule' && (
          <div className="schedule-content fade-in">
            {/* Header Section */}
            <div className="schedule-header">
              <div className="header-info">
                <h2>
                  <i className="fas fa-calendar-alt"></i>
                  My Teaching Schedule
                </h2>
                <p>View your weekly timetable and teaching assignments</p>
              </div>
              
              {facultySchedule.length > 0 && (
                <button 
                  className="btn btn-primary"
                  onClick={handleExportSchedule}
                >
                  <i className="fas fa-download"></i>
                  Export PDF
                </button>
              )}
            </div>

            {/* Stats Cards */}
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-icon primary">
                  <i className="fas fa-clock"></i>
                </div>
                <div className="stat-content">
                  <h3>{stats.totalPeriods}</h3>
                  <p>Total Periods/Week</p>
                </div>
              </div>

              <div className="stat-card">
                <div className="stat-icon secondary">
                  <i className="fas fa-building"></i>
                </div>
                <div className="stat-content">
                  <h3>{stats.departments}</h3>
                  <p>Departments</p>
                </div>
              </div>

              <div className="stat-card">
                <div className="stat-icon success">
                  <i className="fas fa-users"></i>
                </div>
                <div className="stat-content">
                  <h3>{stats.sections}</h3>
                  <p>Class Sections</p>
                </div>
              </div>
            </div>

            {/* Schedule Display */}
            {facultySchedule.length > 0 ? (
              <div className="schedule-display">
                <TimetableDisplay 
                  facultySchedule={facultySchedule}
                  isFacultyView={true}
                />
              </div>
            ) : (
              <div className="empty-schedule">
                <i className="fas fa-calendar-times"></i>
                <h3>No Schedule Available</h3>
                <p>You don't have any teaching assignments yet. Please contact your administrator.</p>
              </div>
            )}

            {/* Teaching Assignments Summary */}
            {facultySchedule.length > 0 && (
              <div className="assignments-summary">
                <h3>Teaching Assignments</h3>
                <div className="assignments-grid">
                  {Array.from(new Set(facultySchedule.map(item => 
                    `${item.department}-${item.year}-${item.section}`
                  ))).map(classKey => {
                    const [department, year, section] = classKey.split('-');
                    const classSchedule = facultySchedule.filter(item => 
                      item.department === department && 
                      item.year.toString() === year && 
                      item.section === section
                    );
                    
                    const subjects = new Set(classSchedule.map(item => item.period.subject));
                    
                    return (
                      <div key={classKey} className="assignment-card">
                        <div className="assignment-header">
                          <h4>{department} {year}-{section}</h4>
                          <span className="period-count">{classSchedule.length} periods</span>
                        </div>
                        <div className="subjects-list">
                          {Array.from(subjects).map(subject => (
                            <span key={subject} className="subject-tag">
                              {subject}
                            </span>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="profile-content fade-in">
            <div className="profile-header">
              <h2>
                <i className="fas fa-user"></i>
                Faculty Profile
              </h2>
              <p>Your personal and professional information</p>
            </div>

            <div className="profile-cards">
              <div className="profile-card">
                <h3>Personal Information</h3>
                <div className="info-grid">
                  <div className="info-item">
                    <label>Name</label>
                    <span>{user.name}</span>
                  </div>
                  <div className="info-item">
                    <label>Email</label>
                    <span>{user.email}</span>
                  </div>
                  <div className="info-item">
                    <label>Employee ID</label>
                    <span>{user.employeeId}</span>
                  </div>
                  <div className="info-item">
                    <label>Role</label>
                    <span className="role-badge">{user.role}</span>
                  </div>
                </div>
              </div>

              {user.facultyDetails && (
                <div className="profile-card">
                  <h3>Faculty Details</h3>
                  <div className="info-grid">
                    <div className="info-item">
                      <label>Department</label>
                      <span>{user.facultyDetails.department || user.department}</span>
                    </div>
                    <div className="info-item">
                      <label>Designation</label>
                      <span>{user.facultyDetails.designation || 'Not specified'}</span>
                    </div>
                    <div className="info-item">
                      <label>Max Lectures/Day</label>
                      <span>{user.facultyDetails.maxLecturesPerDay || 4}</span>
                    </div>
                    <div className="info-item">
                      <label>Status</label>
                      <span className="status-badge active">Active</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        .faculty-dashboard {
          min-height: 100vh;
        }

        .dashboard-nav {
          background: white;
          border-radius: 12px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          margin-bottom: 2rem;
          padding: 1rem;
        }

        .nav-tabs {
          display: flex;
          gap: 0.5rem;
        }

        .nav-tab {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.75rem 1.5rem;
          border: none;
          background: transparent;
          border-radius: 8px;
          font-size: 0.875rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
          white-space: nowrap;
          color: #6b7280;
        }

        .nav-tab:hover {
          background: #f3f4f6;
          color: #374151;
        }

        .nav-tab.active {
          background: var(--primary-color);
          color: white;
        }

        .dashboard-content {
          background: white;
          border-radius: 12px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
          padding: 2rem;
        }

        .schedule-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid #e5e7eb;
        }

        .header-info h2 {
          font-size: 1.75rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 0.5rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .header-info p {
          color: #6b7280;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }

        .stat-card {
          background: white;
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          padding: 1.5rem;
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .stat-icon {
          width: 60px;
          height: 60px;
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.5rem;
          color: white;
        }

        .stat-icon.primary { background: var(--primary-color); }
        .stat-icon.secondary { background: var(--secondary-color); }
        .stat-icon.success { background: var(--success-color); }

        .stat-content h3 {
          font-size: 1.75rem;
          font-weight: 700;
          color: #1f2937;
          margin-bottom: 0.25rem;
        }

        .stat-content p {
          color: #6b7280;
          font-size: 0.875rem;
          font-weight: 500;
        }

        .empty-schedule {
          text-align: center;
          padding: 4rem 2rem;
          color: #6b7280;
        }

        .empty-schedule i {
          font-size: 4rem;
          margin-bottom: 1rem;
          color: #d1d5db;
        }

        .empty-schedule h3 {
          font-size: 1.5rem;
          font-weight: 600;
          margin-bottom: 0.5rem;
          color: #374151;
        }

        .assignments-summary {
          margin-top: 3rem;
        }

        .assignments-summary h3 {
          font-size: 1.25rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1.5rem;
        }

        .assignments-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 1rem;
        }

        .assignment-card {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 8px;
          padding: 1.5rem;
        }

        .assignment-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
        }

        .assignment-header h4 {
          font-size: 1.1rem;
          font-weight: 600;
          color: #1f2937;
        }

        .period-count {
          background: var(--primary-light);
          color: var(--primary-color);
          padding: 0.25rem 0.5rem;
          border-radius: 4px;
          font-size: 0.75rem;
          font-weight: 500;
        }

        .subjects-list {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
        }

        .subject-tag {
          background: white;
          border: 1px solid #d1d5db;
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem;
          color: #374151;
        }

        .profile-header {
          margin-bottom: 2rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid #e5e7eb;
        }

        .profile-header h2 {
          font-size: 1.75rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 0.5rem;
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .profile-cards {
          display: grid;
          gap: 1.5rem;
        }

        .profile-card {
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 12px;
          padding: 1.5rem;
        }

        .profile-card h3 {
          font-size: 1.25rem;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 1.5rem;
        }

        .info-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
        }

        .info-item {
          display: flex;
          flex-direction: column;
          gap: 0.25rem;
        }

        .info-item label {
          font-size: 0.8rem;
          font-weight: 500;
          color: #6b7280;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }

        .info-item span {
          font-size: 0.95rem;
          color: #1f2937;
          font-weight: 500;
        }

        .role-badge {
          background: var(--primary-color);
          color: white;
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem !important;
          text-transform: capitalize;
          display: inline-block;
          width: fit-content;
        }

        .status-badge {
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem !important;
          font-weight: 500;
          display: inline-block;
          width: fit-content;
        }

        .status-badge.active {
          background: #dcfce7;
          color: #166534;
        }

        .faculty-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          min-height: 400px;
          text-align: center;
        }

        @media (max-width: 768px) {
          .dashboard-content {
            padding: 1rem;
          }

          .schedule-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
          }

          .stats-grid {
            grid-template-columns: 1fr;
          }

          .assignments-grid {
            grid-template-columns: 1fr;
          }

          .info-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
};

export default FacultyDashboard;
