// API Base URL
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

// Helper function to get auth token
const getAuthToken = () => {
  return localStorage.getItem('token');
};

// Helper function to make API requests
const apiRequest = async (endpoint, options = {}) => {
  const url = `${API_BASE_URL}${endpoint}`;
  const token = getAuthToken();

  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
      ...options.headers,
    },
    ...options,
  };

  try {
    const response = await fetch(url, config);
    
    // Handle non-JSON responses (like PDF downloads)
    if (options.responseType === 'blob') {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return await response.blob();
    }

    // Handle JSON responses
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || `HTTP error! status: ${response.status}`);
    }

    return data;
  } catch (error) {
    console.error('API request failed:', error);
    throw error;
  }
};

// Authentication APIs
export const login = async (credentials) => {
  return await apiRequest('/auth/login', {
    method: 'POST',
    body: JSON.stringify(credentials),
  });
};

export const register = async (userData) => {
  return await apiRequest('/auth/register', {
    method: 'POST',
    body: JSON.stringify(userData),
  });
};

export const getCurrentUser = async () => {
  return await apiRequest('/auth/profile');
};

export const updateProfile = async (userData) => {
  return await apiRequest('/auth/profile', {
    method: 'PUT',
    body: JSON.stringify(userData),
  });
};

export const changePassword = async (passwordData) => {
  return await apiRequest('/auth/change-password', {
    method: 'PUT',
    body: JSON.stringify(passwordData),
  });
};

// Faculty APIs
export const getFaculty = async (params = {}) => {
  const queryString = new URLSearchParams(params).toString();
  const endpoint = queryString ? `/faculty?${queryString}` : '/faculty';
  return await apiRequest(endpoint);
};

export const getFacultyById = async (id) => {
  return await apiRequest(`/faculty/${id}`);
};

export const createFaculty = async (facultyData) => {
  return await apiRequest('/faculty', {
    method: 'POST',
    body: JSON.stringify(facultyData),
  });
};

export const updateFaculty = async (id, facultyData) => {
  return await apiRequest(`/faculty/${id}`, {
    method: 'PUT',
    body: JSON.stringify(facultyData),
  });
};

export const deleteFaculty = async (id) => {
  return await apiRequest(`/faculty/${id}`, {
    method: 'DELETE',
  });
};

export const getFacultyByEmployeeId = async (employeeId) => {
  return await apiRequest(`/faculty/employee/${employeeId}`);
};

export const getFacultyByDepartment = async (department) => {
  return await apiRequest(`/faculty/department/${department}`);
};

// Subject APIs
export const getSubjects = async (params = {}) => {
  const queryString = new URLSearchParams(params).toString();
  const endpoint = queryString ? `/subjects?${queryString}` : '/subjects';
  return await apiRequest(endpoint);
};

export const getSubjectById = async (id) => {
  return await apiRequest(`/subjects/${id}`);
};

export const createSubject = async (subjectData) => {
  return await apiRequest('/subjects', {
    method: 'POST',
    body: JSON.stringify(subjectData),
  });
};

export const updateSubject = async (id, subjectData) => {
  return await apiRequest(`/subjects/${id}`, {
    method: 'PUT',
    body: JSON.stringify(subjectData),
  });
};

export const deleteSubject = async (id) => {
  return await apiRequest(`/subjects/${id}`, {
    method: 'DELETE',
  });
};

export const getLabSubjects = async (department, year, semester) => {
  return await apiRequest(`/subjects/type/lab?department=${department}&year=${year}&semester=${semester}`);
};

export const getTheorySubjects = async (department, year, semester) => {
  return await apiRequest(`/subjects/type/theory?department=${department}&year=${year}&semester=${semester}`);
};

// Allocation APIs
export const getAllocations = async (params = {}) => {
  const queryString = new URLSearchParams(params).toString();
  const endpoint = queryString ? `/allocations?${queryString}` : '/allocations';
  return await apiRequest(endpoint);
};

export const getAllocationById = async (id) => {
  return await apiRequest(`/allocations/${id}`);
};

export const createAllocation = async (allocationData) => {
  return await apiRequest('/allocations', {
    method: 'POST',
    body: JSON.stringify(allocationData),
  });
};

export const updateAllocation = async (id, allocationData) => {
  return await apiRequest(`/allocations/${id}`, {
    method: 'PUT',
    body: JSON.stringify(allocationData),
  });
};

export const deleteAllocation = async (id) => {
  return await apiRequest(`/allocations/${id}`, {
    method: 'DELETE',
  });
};

export const addFacultySubject = async (allocationId, facultyId, subjectId) => {
  return await apiRequest(`/allocations/${allocationId}/faculty-subject`, {
    method: 'POST',
    body: JSON.stringify({ facultyId, subjectId }),
  });
};

export const removeFacultySubject = async (allocationId, facultyId, subjectId) => {
  return await apiRequest(`/allocations/${allocationId}/faculty-subject`, {
    method: 'DELETE',
    body: JSON.stringify({ facultyId, subjectId }),
  });
};

export const getAllocationsByFaculty = async (facultyId) => {
  return await apiRequest(`/allocations/faculty/${facultyId}`);
};

// Timetable APIs
export const getTimetables = async (params = {}) => {
  const queryString = new URLSearchParams(params).toString();
  const endpoint = queryString ? `/timetables?${queryString}` : '/timetables';
  return await apiRequest(endpoint);
};

export const getTimetableById = async (id) => {
  return await apiRequest(`/timetables/${id}`);
};

export const generateTimetable = async (timetableData) => {
  return await apiRequest('/timetables/generate', {
    method: 'POST',
    body: JSON.stringify(timetableData),
  });
};

export const updateTimetable = async (id, timetableData) => {
  return await apiRequest(`/timetables/${id}`, {
    method: 'PUT',
    body: JSON.stringify(timetableData),
  });
};

export const deleteTimetable = async (id) => {
  return await apiRequest(`/timetables/${id}`, {
    method: 'DELETE',
  });
};

export const getFacultyTimetable = async (facultyId) => {
  return await apiRequest(`/timetables/faculty/${facultyId}`);
};

export const exportTimetable = async (timetableId) => {
  return await apiRequest(`/timetables/${timetableId}/export`, {
    responseType: 'blob',
  });
};

export const exportFacultyTimetable = async (facultyId) => {
  return await apiRequest(`/timetables/faculty/${facultyId}/export`, {
    responseType: 'blob',
  });
};

export const regenerateTimetable = async (timetableId) => {
  return await apiRequest(`/timetables/${timetableId}/regenerate`, {
    method: 'POST',
  });
};

// Health check API
export const checkHealth = async () => {
  return await apiRequest('/health');
};

// Error handling utility
export const handleApiError = (error) => {
  if (error.message.includes('401')) {
    // Unauthorized - redirect to login
    localStorage.removeItem('token');
    window.location.href = '/login';
    return 'Session expired. Please login again.';
  } else if (error.message.includes('403')) {
    return 'You do not have permission to perform this action.';
  } else if (error.message.includes('404')) {
    return 'The requested resource was not found.';
  } else if (error.message.includes('500')) {
    return 'Server error. Please try again later.';
  } else if (error.message.includes('Network')) {
    return 'Network error. Please check your internet connection.';
  }
  return error.message || 'An unexpected error occurred.';
};

// Request interceptor for handling common errors
const originalApiRequest = apiRequest;
export { originalApiRequest };

// Export a wrapped version that handles common errors
export const safeApiRequest = async (endpoint, options = {}) => {
  try {
    return await apiRequest(endpoint, options);
  } catch (error) {
    const handledError = new Error(handleApiError(error));
    handledError.originalError = error;
    throw handledError;
  }
};

// Utility functions for common operations
export const validateToken = async () => {
  try {
    await getCurrentUser();
    return true;
  } catch (error) {
    return false;
  }
};

export const logout = () => {
  localStorage.removeItem('token');
  window.location.href = '/';
};

// Batch operations
export const batchCreateFaculty = async (facultyList) => {
  const results = [];
  for (const faculty of facultyList) {
    try {
      const result = await createFaculty(faculty);
      results.push({ success: true, data: result, faculty });
    } catch (error) {
      results.push({ success: false, error: error.message, faculty });
    }
  }
  return results;
};

export const batchCreateSubjects = async (subjectList) => {
  const results = [];
  for (const subject of subjectList) {
    try {
      const result = await createSubject(subject);
      results.push({ success: true, data: result, subject });
    } catch (error) {
      results.push({ success: false, error: error.message, subject });
    }
  }
  return results;
};

// Data validation helpers
export const validateFacultyData = (facultyData) => {
  const errors = [];
  
  if (!facultyData.employeeId) errors.push('Employee ID is required');
  if (!facultyData.name) errors.push('Name is required');
  if (!facultyData.email) errors.push('Email is required');
  if (!facultyData.department) errors.push('Department is required');
  
  if (facultyData.email && !/\S+@\S+\.\S+/.test(facultyData.email)) {
    errors.push('Invalid email format');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

export const validateSubjectData = (subjectData) => {
  const errors = [];
  
  if (!subjectData.code) errors.push('Subject code is required');
  if (!subjectData.name) errors.push('Subject name is required');
  if (!subjectData.department) errors.push('Department is required');
  if (!subjectData.type) errors.push('Subject type is required');
  if (!subjectData.periodsPerWeek || subjectData.periodsPerWeek < 1) {
    errors.push('Periods per week must be at least 1');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

export const validateAllocationData = (allocationData) => {
  const errors = [];
  
  if (!allocationData.department) errors.push('Department is required');
  if (!allocationData.year) errors.push('Year is required');
  if (!allocationData.semester) errors.push('Semester is required');
  if (!allocationData.section) errors.push('Section is required');
  
  if (!allocationData.facultySubjects || allocationData.facultySubjects.length === 0) {
    errors.push('At least one faculty-subject assignment is required');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

// Default export with commonly used functions
export default {
  // Auth
  login,
  getCurrentUser,
  logout,
  
  // Faculty
  getFaculty,
  createFaculty,
  updateFaculty,
  deleteFaculty,
  
  // Subjects
  getSubjects,
  createSubject,
  updateSubject,
  deleteSubject,
  
  // Allocations
  getAllocations,
  createAllocation,
  updateAllocation,
  deleteAllocation,
  
  // Timetables
  getTimetables,
  generateTimetable,
  exportTimetable,
  getFacultyTimetable,
  exportFacultyTimetable,
  
  // Utilities
  validateToken,
  handleApiError,
};
